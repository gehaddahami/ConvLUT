// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vlogicnet.h for the primary calling header

#include "Vlogicnet.h"
#include "Vlogicnet__Syms.h"

//==========

void Vlogicnet::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vlogicnet::eval\n"); );
    Vlogicnet__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        vlSymsp->__Vm_activity = true;
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/student/CNN_LogicNets/jet_substructure/jsc_s/3_bits_all/logicnet.v", 1, "",
                "Verilated model didn't converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

void Vlogicnet::_eval_initial_loop(Vlogicnet__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        _eval_settle(vlSymsp);
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/student/CNN_LogicNets/jet_substructure/jsc_s/3_bits_all/logicnet.v", 1, "",
                "Verilated model didn't DC converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

VL_INLINE_OPT void Vlogicnet::_sequent__TOP__1(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_sequent__TOP__1\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->rst) {
        vlTOPp->logicnet__DOT__M4w[0U] = 0U;
        vlTOPp->logicnet__DOT__M4w[1U] = 0U;
        vlTOPp->logicnet__DOT__M4w[2U] = 0U;
        vlTOPp->logicnet__DOT__M3w[0U] = 0U;
        vlTOPp->logicnet__DOT__M3w[1U] = 0U;
        vlTOPp->logicnet__DOT__M3w[2U] = 0U;
        vlTOPp->logicnet__DOT__M2w[0U] = 0U;
        vlTOPp->logicnet__DOT__M2w[1U] = 0U;
        vlTOPp->logicnet__DOT__M2w[2U] = 0U;
        vlTOPp->logicnet__DOT__M1w[0U] = 0U;
        vlTOPp->logicnet__DOT__M1w[1U] = 0U;
        vlTOPp->logicnet__DOT__M1w[2U] = 0U;
        vlTOPp->logicnet__DOT__M1w[3U] = 0U;
        vlTOPp->logicnet__DOT__M1w[4U] = 0U;
        vlTOPp->logicnet__DOT__M1w[5U] = 0U;
        vlTOPp->logicnet__DOT__M0w = 0ULL;
    } else {
        vlTOPp->logicnet__DOT__M4w[0U] = vlTOPp->logicnet__DOT__M4[0U];
        vlTOPp->logicnet__DOT__M4w[1U] = vlTOPp->logicnet__DOT__M4[1U];
        vlTOPp->logicnet__DOT__M4w[2U] = vlTOPp->logicnet__DOT__M4[2U];
        vlTOPp->logicnet__DOT__M3w[0U] = vlTOPp->logicnet__DOT__M3[0U];
        vlTOPp->logicnet__DOT__M3w[1U] = vlTOPp->logicnet__DOT__M3[1U];
        vlTOPp->logicnet__DOT__M3w[2U] = vlTOPp->logicnet__DOT__M3[2U];
        vlTOPp->logicnet__DOT__M2w[0U] = vlTOPp->logicnet__DOT__M2[0U];
        vlTOPp->logicnet__DOT__M2w[1U] = vlTOPp->logicnet__DOT__M2[1U];
        vlTOPp->logicnet__DOT__M2w[2U] = vlTOPp->logicnet__DOT__M2[2U];
        vlTOPp->logicnet__DOT__M1w[0U] = vlTOPp->logicnet__DOT__M1[0U];
        vlTOPp->logicnet__DOT__M1w[1U] = vlTOPp->logicnet__DOT__M1[1U];
        vlTOPp->logicnet__DOT__M1w[2U] = vlTOPp->logicnet__DOT__M1[2U];
        vlTOPp->logicnet__DOT__M1w[3U] = vlTOPp->logicnet__DOT__M1[3U];
        vlTOPp->logicnet__DOT__M1w[4U] = vlTOPp->logicnet__DOT__M1[4U];
        vlTOPp->logicnet__DOT__M1w[5U] = vlTOPp->logicnet__DOT__M1[5U];
        vlTOPp->logicnet__DOT__M0w = vlTOPp->M0;
    }
    vlTOPp->__Vtableidx161 = ((0x1c0U & vlTOPp->logicnet__DOT__M4w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                           >> 0xfU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                              >> 0xfU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                              >> 0xfU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M4w[2U] 
                                                 << 0xaU) 
                                                | (vlTOPp->logicnet__DOT__M4w[1U] 
                                                   >> 0x16U)))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable161_logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx161];
    vlTOPp->__Vtableidx162 = ((0x1c0U & vlTOPp->logicnet__DOT__M4w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M4w[1U] 
                                           >> 0x19U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M4w[1U] 
                                              >> 0x19U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M4w[1U] 
                                              >> 0x19U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable162_logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx162];
    vlTOPp->__Vtableidx163 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M4w[1U] 
                                          << 0x14U) 
                                         | (0xfffc0U 
                                            & (vlTOPp->logicnet__DOT__M4w[0U] 
                                               >> 0xcU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                           << 1U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                              << 1U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                              << 1U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                >> 0x17U))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable163_logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx163];
    vlTOPp->__Vtableidx164 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M4w[1U] 
                                          << 0x1aU) 
                                         | (0x3ffffc0U 
                                            & (vlTOPp->logicnet__DOT__M4w[0U] 
                                               >> 6U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                           >> 0x15U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                              >> 0x15U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                              >> 0x15U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable164_logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx164];
    vlTOPp->__Vtableidx165 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M4w[1U] 
                                          << 0x11U) 
                                         | (0x1ffc0U 
                                            & (vlTOPp->logicnet__DOT__M4w[0U] 
                                               >> 0xfU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                           >> 0x15U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                              >> 0x15U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                              >> 0x15U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable165_logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx165];
    vlTOPp->__Vtableidx129 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x11U) 
                                         | (0x1ffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0xfU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 7U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 7U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 7U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 4U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable129_logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx129];
    vlTOPp->__Vtableidx130 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1aU) 
                                         | (0x3ffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 6U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0xaU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable130_logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx130];
    vlTOPp->__Vtableidx131 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 8U) | 
                                         (0xc0U & (
                                                   vlTOPp->logicnet__DOT__M3w[0U] 
                                                   >> 0x18U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0xdU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xdU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xdU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 7U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x19U)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable131_logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx131];
    vlTOPp->__Vtableidx132 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                          << 0x1cU) 
                                         | (0xfffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[1U] 
                                               >> 4U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0x19U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0x19U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0x19U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable132_logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx132];
    vlTOPp->__Vtableidx133 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0xbU) 
                                         | (0x7c0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0x15U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                           >> 0xeU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 0xeU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 0xeU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x14U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable133_logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx133];
    vlTOPp->__Vtableidx134 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x14U) 
                                         | (0xfffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0xcU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0x16U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0x16U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0x16U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 4U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable134_logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx134];
    vlTOPp->__Vtableidx135 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1aU) 
                                         | (0x3ffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 6U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           << 5U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x1bU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x1bU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 0x1fU) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 1U)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable135_logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx135];
    vlTOPp->__Vtableidx136 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1aU) 
                                         | (0x3ffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 6U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0x18U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x18U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x18U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 4U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable136_logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx136];
    vlTOPp->__Vtableidx137 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0x15U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable137_logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx137];
    vlTOPp->__Vtableidx138 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0x15U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 8U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable138_logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx138];
    vlTOPp->__Vtableidx139 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                          << 0x1cU) 
                                         | (0xfffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[1U] 
                                               >> 4U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0xdU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xdU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xdU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable139_logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx139];
    vlTOPp->__Vtableidx140 = ((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         << 2U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         >> 0x19U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                            >> 0x19U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                            >> 0x19U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 0xeU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable140_logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx140];
    vlTOPp->__Vtableidx141 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0xcU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0xcU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0xcU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 4U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable141_logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx141];
    vlTOPp->__Vtableidx142 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x14U) 
                                         | (0xfffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0xcU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0x18U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x18U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x18U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 0x1fU) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 1U)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable142_logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx142];
    vlTOPp->__Vtableidx143 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0xbU) 
                                         | (0x7c0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0x15U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0x19U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0x19U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0x19U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x11U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable143_logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx143];
    vlTOPp->__Vtableidx144 = ((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 7U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 7U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 7U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable144_logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx144];
    vlTOPp->__Vtableidx145 = ((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         << 5U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         >> 0x16U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                            >> 0x16U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                            >> 0x16U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 0x14U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable145_logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx145];
    vlTOPp->__Vtableidx146 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x17U) 
                                         | (0x7fffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 9U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0x18U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x18U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x18U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 7U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x19U)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable146_logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx146];
    vlTOPp->__Vtableidx147 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                           >> 8U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 8U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 8U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0xeU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable147_logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx147];
    vlTOPp->__Vtableidx148 = ((0x1c0U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                         >> 2U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                         >> 0x11U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                            >> 0x11U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                            >> 0x11U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 0x17U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable148_logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx148];
    vlTOPp->__Vtableidx149 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x14U) 
                                         | (0xfffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0xcU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0xaU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 0xaU) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x16U)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable149_logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx149];
    vlTOPp->__Vtableidx150 = ((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         << 2U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         >> 0xdU)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                            >> 0xdU)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                            >> 0xdU)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 8U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable150_logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx150];
    vlTOPp->__Vtableidx151 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x14U) 
                                         | (0xfffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0xcU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0xaU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable151_logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx151];
    vlTOPp->__Vtableidx152 = ((0x1c0U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                         << 3U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         << 5U)) | 
                               ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                          >> 0x1bU)) 
                                | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                          >> 0x1bU)) 
                                   | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                             << 0x16U) 
                                            | (vlTOPp->logicnet__DOT__M3w[1U] 
                                               >> 0xaU)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable152_logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx152];
    vlTOPp->__Vtableidx153 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0xeU) 
                                         | (0x3fc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0x12U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                           << 4U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0x1cU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x11U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable153_logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx153];
    vlTOPp->__Vtableidx154 = ((0x1c0U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                         << 3U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                         >> 0x12U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                            >> 0x12U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                            >> 0x12U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                              >> 5U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable154_logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx154];
    vlTOPp->__Vtableidx155 = ((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0x15U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable155_logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx155];
    vlTOPp->__Vtableidx156 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0xdU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xdU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xdU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 4U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable156_logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx156];
    vlTOPp->__Vtableidx157 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                          << 0x1cU) 
                                         | (0xfffffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[1U] 
                                               >> 4U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                           >> 0xaU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                              >> 0xaU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x14U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable157_logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx157];
    vlTOPp->__Vtableidx158 = ((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0xfU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0xfU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0xfU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 0x13U) 
                                                | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                   >> 0xdU)))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable158_logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx158];
    vlTOPp->__Vtableidx159 = ((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                         << 5U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                         << 1U)) | 
                               ((0x10U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                          << 1U)) | 
                                ((8U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                        << 1U)) | (7U 
                                                   & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                      >> 8U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable159_logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx159];
    vlTOPp->__Vtableidx160 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                          << 0x14U) 
                                         | (0xfffc0U 
                                            & (vlTOPp->logicnet__DOT__M3w[0U] 
                                               >> 0xcU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                           >> 0x15U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                              >> 0x15U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 8U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable160_logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx160];
    vlTOPp->__Vtableidx97 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 0x14U) 
                                        | (0xfffc0U 
                                           & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0xcU)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                          >> 0xdU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0xdU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0xdU)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                << 0xaU) 
                                               | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x16U)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable97_logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx97];
    vlTOPp->__Vtableidx98 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                         << 0x1cU) 
                                        | (0xfffffc0U 
                                           & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 4U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                          << 4U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                           << 4U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 0x1cU)) 
                                    | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable98_logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx98];
    vlTOPp->__Vtableidx99 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 0x1dU) 
                                        | (0x1fffffc0U 
                                           & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 3U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                          >> 0xbU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0xbU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0xbU)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                               >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable99_logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx99];
    vlTOPp->__Vtableidx100 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 2U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                         >> 0x11U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                            >> 0x11U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                            >> 0x11U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              >> 0x17U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable100_logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx100];
    vlTOPp->__Vtableidx101 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 9U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 9U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 9U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 7U) 
                                                | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                   >> 0x19U)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable101_logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx101];
    vlTOPp->__Vtableidx102 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0xbU) 
                                         | (0x7c0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 0x15U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 7U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 7U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 7U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x10U) 
                                                | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                   >> 0x10U)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable102_logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx102];
    vlTOPp->__Vtableidx103 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x17U) 
                                         | (0x7fffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 9U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 0x12U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x12U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x12U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x16U) 
                                                | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                   >> 0xaU)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable103_logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx103];
    vlTOPp->__Vtableidx104 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0xbU) 
                                         | (0x7c0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 0x15U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           << 5U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x1bU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x1bU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable104_logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx104];
    vlTOPp->__Vtableidx105 = ((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           << 2U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              << 2U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable105_logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx105];
    vlTOPp->__Vtableidx106 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                          << 0x16U) 
                                         | (0x3fffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[1U] 
                                               >> 0xaU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 0x13U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0x13U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0x13U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable106_logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx106];
    vlTOPp->__Vtableidx107 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0xeU) 
                                         | (0x3fc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 0x12U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 0x18U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x18U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x18U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 2U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable107_logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx107];
    vlTOPp->__Vtableidx108 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 2U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                         >> 2U)) | 
                               ((0x10U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                          >> 2U)) | 
                                ((8U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                        >> 2U)) | (7U 
                                                   & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                      >> 0x11U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable108_logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx108];
    vlTOPp->__Vtableidx109 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                         >> 0xeU)) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                           >> 0x14U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              >> 0x14U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              >> 0x14U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable109_logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx109];
    vlTOPp->__Vtableidx110 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x11U) 
                                         | (0x1ffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 0xfU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 7U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 7U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 7U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x13U) 
                                                | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                   >> 0xdU)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable110_logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx110];
    vlTOPp->__Vtableidx111 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 2U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                         << 4U)) | 
                               ((0x10U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                          << 4U)) | 
                                ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                        >> 0x1cU)) 
                                 | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                          >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable111_logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx111];
    vlTOPp->__Vtableidx112 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0xeU) 
                                         | (0x3fc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 0x12U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 7U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 7U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 7U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable112_logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx112];
    vlTOPp->__Vtableidx113 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 9U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 9U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 9U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 5U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable113_logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx113];
    vlTOPp->__Vtableidx114 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                         << 6U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                         >> 0x15U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                            >> 0x15U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                            >> 0x15U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              >> 0x14U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable114_logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx114];
    vlTOPp->__Vtableidx115 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 5U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         >> 0x13U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                            >> 0x13U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                            >> 0x13U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              >> 5U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable115_logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx115];
    vlTOPp->__Vtableidx116 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x11U) 
                                         | (0x1ffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 0xfU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 0x15U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x15U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0x15U)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x1fU) 
                                                | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                   >> 1U)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable116_logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx116];
    vlTOPp->__Vtableidx117 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                         << 3U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 5U)) | 
                               ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                          >> 0x1bU)) 
                                | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                          >> 0x1bU)) 
                                   | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                            >> 0x11U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable117_logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx117];
    vlTOPp->__Vtableidx118 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x14U) 
                                         | (0xfffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 0xcU)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 0x13U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0x13U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0x13U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable118_logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx118];
    vlTOPp->__Vtableidx119 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 5U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         >> 0x19U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                            >> 0x19U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                            >> 0x19U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              >> 2U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable119_logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx119];
    vlTOPp->__Vtableidx120 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                         << 3U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                         >> 9U)) | 
                               ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                          >> 9U)) | 
                                ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                        >> 9U)) | (7U 
                                                   & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                       << 2U) 
                                                      | (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0x1eU)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable120_logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx120];
    vlTOPp->__Vtableidx121 = ((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 0xfU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0xfU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0xfU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable121_logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx121];
    vlTOPp->__Vtableidx122 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x1aU) 
                                         | (0x3ffffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 6U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 0xcU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0xcU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0xcU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x11U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable122_logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx122];
    vlTOPp->__Vtableidx123 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x1aU) 
                                         | (0x3ffffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 6U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                           << 4U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0x1cU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable123_logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx123];
    vlTOPp->__Vtableidx124 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 8U) | 
                                         (0xc0U & (
                                                   vlTOPp->logicnet__DOT__M2w[0U] 
                                                   >> 0x18U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 0x19U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0x19U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0x19U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable124_logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx124];
    vlTOPp->__Vtableidx125 = ((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         << 2U)) | 
                              ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                         >> 0x19U)) 
                               | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                            >> 0x19U)) 
                                  | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                            >> 0x19U)) 
                                     | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                              >> 2U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable125_logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx125];
    vlTOPp->__Vtableidx126 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                          << 0x1dU) 
                                         | (0x1fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[0U] 
                                               >> 3U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 4U)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 4U)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 8U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable126_logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx126];
    vlTOPp->__Vtableidx127 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                          << 0x1fU) 
                                         | (0x7fffffc0U 
                                            & (vlTOPp->logicnet__DOT__M2w[1U] 
                                               >> 1U)))) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                           >> 0xdU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0xdU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                              >> 0xdU)) 
                                       | (7U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable127_logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx127];
    vlTOPp->__Vtableidx128 = ((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                              | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                           >> 0xcU)) 
                                 | ((0x10U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0xcU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                              >> 0xcU)) 
                                       | (7U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x16U) 
                                                | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                   >> 0xaU)))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable128_logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx128];
    vlTOPp->__Vtableidx65 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 0x13U) 
                                        | (0x7ffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[1U] 
                                              >> 0xdU)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                          >> 0x17U)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                << 0x1fU) 
                                               | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 1U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable65_logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx65];
    vlTOPp->__Vtableidx66 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 7U) | (0x40U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0x19U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                          >> 0xeU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xeU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xeU)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                << 0x1fU) 
                                               | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 1U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable66_logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx66];
    vlTOPp->__Vtableidx67 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                         << 0x17U) 
                                        | (0x7fffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[3U] 
                                              >> 9U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                          << 2U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                           << 2U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                           << 2U)) 
                                    | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable67_logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx67];
    vlTOPp->__Vtableidx68 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                         << 0x17U) 
                                        | (0x7fffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[0U] 
                                              >> 9U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                          >> 0x1aU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                << 0xeU) 
                                               | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x12U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable68_logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx68];
    vlTOPp->__Vtableidx69 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        << 3U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                       >> 0x15U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                          >> 0x15U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                             >> 0x15U)) 
                                                         | (7U 
                                                            & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                                << 0x19U) 
                                                               | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                                  >> 7U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable69_logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx69];
    vlTOPp->__Vtableidx70 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 0xaU) | 
                                        (0x3c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   >> 0x16U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          << 3U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                           << 3U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                           << 3U)) 
                                    | (7U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                              << 4U) 
                                             | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable70_logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx70];
    vlTOPp->__Vtableidx71 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                         << 0x1aU) 
                                        | (0x3ffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[3U] 
                                              >> 6U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0xfU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable71_logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx71];
    vlTOPp->__Vtableidx72 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                         << 0x1aU) 
                                        | (0x3ffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[0U] 
                                              >> 6U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                          >> 0xcU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0xcU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0xcU)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 4U) 
                                               | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable72_logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx72];
    vlTOPp->__Vtableidx73 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                         << 0xeU) | 
                                        (0x3fc0U & 
                                         (vlTOPp->logicnet__DOT__M1w[0U] 
                                          >> 0x12U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 6U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                           >> 6U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                           >> 6U)) 
                                    | (7U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                              << 4U) 
                                             | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                >> 0x1cU)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable73_logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx73];
    vlTOPp->__Vtableidx74 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 0x1cU) 
                                        | (0xfffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[1U] 
                                              >> 4U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                          >> 0x17U)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 0x17U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable74_logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx74];
    vlTOPp->__Vtableidx75 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                         << 0x1bU) 
                                        | (0x7ffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[2U] 
                                              >> 5U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0x15U)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x15U)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x15U)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                << 0x1cU) 
                                               | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 4U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable75_logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx75];
    vlTOPp->__Vtableidx76 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 0xaU) | 
                                        (0x3c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   >> 0x16U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                          >> 8U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                           >> 8U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                           >> 8U)) 
                                    | (7U & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                              << 0xbU) 
                                             | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0x15U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable76_logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx76];
    vlTOPp->__Vtableidx77 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 0xaU) | 
                                        (0x3c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   >> 0x16U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                          >> 0xbU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 0xbU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 0xbU)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 0x17U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable77_logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx77];
    vlTOPp->__Vtableidx78 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                         << 0xfU) | 
                                        (0x7fc0U & 
                                         (vlTOPp->logicnet__DOT__M1w[2U] 
                                          >> 0x11U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 3U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                           >> 3U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                           >> 3U)) 
                                    | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 5U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable78_logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx78];
    vlTOPp->__Vtableidx79 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                         << 0x12U) 
                                        | (0x3ffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[2U] 
                                              >> 0xeU)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                          >> 0x16U)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x16U)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x16U)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable79_logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx79];
    vlTOPp->__Vtableidx80 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                         << 0xbU) | 
                                        (0x7c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[0U] 
                                                   >> 0x15U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                          >> 7U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 7U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 7U)) 
                                    | (7U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                              << 0xcU) 
                                             | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x14U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable80_logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx80];
    vlTOPp->__Vtableidx81 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 2U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 0x19U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                          >> 0x19U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                             >> 0x19U)) 
                                                         | (7U 
                                                            & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                                << 0x10U) 
                                                               | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                                  >> 0x10U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable81_logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx81];
    vlTOPp->__Vtableidx82 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                         << 0x1bU) 
                                        | (0x7ffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[2U] 
                                              >> 5U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                          >> 0x1aU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 5U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable82_logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx82];
    vlTOPp->__Vtableidx83 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                         << 0x1bU) 
                                        | (0x7ffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[2U] 
                                              >> 5U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0xfU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                << 0x10U) 
                                               | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0x10U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable83_logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx83];
    vlTOPp->__Vtableidx84 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                         << 0x17U) 
                                        | (0x7fffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[0U] 
                                              >> 9U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                          >> 7U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 7U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 7U)) 
                                    | (7U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                              << 0xcU) 
                                             | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x14U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable84_logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx84];
    vlTOPp->__Vtableidx85 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        << 3U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0xbU)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                          >> 0xbU)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                             >> 0xbU)) 
                                                         | (7U 
                                                            & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                                << 0xbU) 
                                                               | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                                  >> 0x15U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable85_logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx85];
    vlTOPp->__Vtableidx86 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 1U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0x11U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                          >> 0x11U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                             >> 0x11U)) 
                                                         | (7U 
                                                            & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                               >> 0x17U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable86_logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx86];
    vlTOPp->__Vtableidx87 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 5U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                             >> 0x1cU)) 
                                                         | (7U 
                                                            & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                               >> 2U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable87_logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx87];
    vlTOPp->__Vtableidx88 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                         << 0x1fU) 
                                        | (0x7fffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[4U] 
                                              >> 1U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                          >> 0x19U)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x19U)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x19U)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 0xbU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable88_logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx88];
    vlTOPp->__Vtableidx89 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 2U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                       >> 0x18U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                          >> 0x18U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                             >> 0x18U)) 
                                                         | (7U 
                                                            & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                                << 0x19U) 
                                                               | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                                  >> 7U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable89_logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx89];
    vlTOPp->__Vtableidx90 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 0x19U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                          >> 0x19U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                             >> 0x19U)) 
                                                         | (7U 
                                                            & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                                << 0x1cU) 
                                                               | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                                  >> 4U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable90_logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx90];
    vlTOPp->__Vtableidx91 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                         << 0x17U) 
                                        | (0x7fffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[0U] 
                                              >> 9U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                          << 2U)) | 
                                ((0x10U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           << 2U)) 
                                 | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           << 2U)) 
                                    | (7U & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                              << 0x11U) 
                                             | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0xfU)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable91_logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx91];
    vlTOPp->__Vtableidx92 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 0x1fU) 
                                        | (0x7fffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[1U] 
                                              >> 1U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0x12U)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x12U)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x12U)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 0x1dU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable92_logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx92];
    vlTOPp->__Vtableidx93 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 4U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 0x19U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 0x19U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                             >> 0x19U)) 
                                                         | (7U 
                                                            & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                               >> 8U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable93_logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx93];
    vlTOPp->__Vtableidx94 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 0x1cU) 
                                        | (0xfffffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[1U] 
                                              >> 4U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                          >> 0xaU)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0xaU)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0xaU)) 
                                      | (7U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                               >> 0x14U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable94_logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx94];
    vlTOPp->__Vtableidx95 = ((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        << 3U)) | (
                                                   (0x20U 
                                                    & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                       >> 9U)) 
                                                   | ((0x10U 
                                                       & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                          >> 9U)) 
                                                      | ((8U 
                                                          & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                             >> 9U)) 
                                                         | (7U 
                                                            & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                                << 2U) 
                                                               | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                                  >> 0x1eU)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable95_logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx95];
    vlTOPp->__Vtableidx96 = ((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                         << 0x17U) 
                                        | (0x7fffc0U 
                                           & (vlTOPp->logicnet__DOT__M1w[0U] 
                                              >> 9U)))) 
                             | ((0x20U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                          >> 0x12U)) 
                                | ((0x10U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0x12U)) 
                                   | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0x12U)) 
                                      | (7U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0xcU) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x14U)))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable96_logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx96];
    vlTOPp->__Vtableidx1 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 3U)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x1aU)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x19U)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0x18U)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable1_logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx1];
    vlTOPp->__Vtableidx2 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 3U)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x11U)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x10U)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0xfU)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable2_logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx2];
    vlTOPp->__Vtableidx3 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 3U)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x17U)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x16U)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0x15U)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable3_logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx3];
    vlTOPp->__Vtableidx4 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 6U)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x1aU)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x19U)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0x18U)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable4_logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx4];
    vlTOPp->__Vtableidx5 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 0x24U)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x29U)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x28U)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0x27U)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable5_logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx5];
    vlTOPp->__Vtableidx6 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 0xcU)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x11U)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x10U)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0xfU)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable6_logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx6];
    vlTOPp->__Vtableidx7 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 0x15U)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x20U)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x1fU)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0x1eU)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable7_logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx7];
    vlTOPp->__Vtableidx8 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 9U)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0xeU)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0xdU)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0xcU)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x12U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable8_logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx8];
    vlTOPp->__Vtableidx9 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                >> 0xcU)) 
                                       << 6U)) | ((0x20U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M0w 
                                                               >> 0x26U)) 
                                                      << 5U)) 
                                                  | ((0x10U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M0w 
                                                                  >> 0x25U)) 
                                                         << 4U)) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (vlTOPp->logicnet__DOT__M0w 
                                                                     >> 0x24U)) 
                                                            << 3U)) 
                                                        | (7U 
                                                           & (IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable9_logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx9];
    vlTOPp->__Vtableidx10 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x23U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x22U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x21U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable10_logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx10];
    vlTOPp->__Vtableidx11 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable11_logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx11];
    vlTOPp->__Vtableidx12 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0xeU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0xdU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0xcU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable12_logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx12];
    vlTOPp->__Vtableidx13 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x17U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x16U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x15U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable13_logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx13];
    vlTOPp->__Vtableidx14 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xfU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x14U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x13U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x12U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable14_logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx14];
    vlTOPp->__Vtableidx15 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xfU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x14U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x13U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x12U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x15U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable15_logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx15];
    vlTOPp->__Vtableidx16 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x29U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x28U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x27U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable16_logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx16];
    vlTOPp->__Vtableidx17 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xfU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x23U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x22U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x21U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable17_logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx17];
    vlTOPp->__Vtableidx18 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x21U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable18_logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx18];
    vlTOPp->__Vtableidx19 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0xbU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0xaU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 9U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x12U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable19_logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx19];
    vlTOPp->__Vtableidx20 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 9U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x14U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x13U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x12U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x15U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable20_logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx20];
    vlTOPp->__Vtableidx21 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x17U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x16U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x15U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable21_logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx21];
    vlTOPp->__Vtableidx22 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable22_logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx22];
    vlTOPp->__Vtableidx23 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1dU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1cU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x1eU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable23_logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx23];
    vlTOPp->__Vtableidx24 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x11U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x10U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0xfU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable24_logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx24];
    vlTOPp->__Vtableidx25 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0xeU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0xdU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0xcU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable25_logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx25];
    vlTOPp->__Vtableidx26 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable26_logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx26];
    vlTOPp->__Vtableidx27 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x23U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x22U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x21U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable27_logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx27];
    vlTOPp->__Vtableidx28 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xfU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable28_logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx28];
    vlTOPp->__Vtableidx29 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x23U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x22U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x21U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable29_logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx29];
    vlTOPp->__Vtableidx30 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x20U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1fU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1eU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable30_logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx30];
    vlTOPp->__Vtableidx31 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x15U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x20U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1fU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1eU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable31_logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx31];
    vlTOPp->__Vtableidx32 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 8U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 7U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 6U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x21U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable32_logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx32];
    vlTOPp->__Vtableidx33 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x23U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x22U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x21U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r 
        = vlTOPp->__Vtable33_logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r
        [vlTOPp->__Vtableidx33];
    vlTOPp->__Vtableidx34 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0xeU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0xdU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0xcU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x21U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r 
        = vlTOPp->__Vtable34_logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r
        [vlTOPp->__Vtableidx34];
    vlTOPp->__Vtableidx35 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1dU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1cU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r 
        = vlTOPp->__Vtable35_logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r
        [vlTOPp->__Vtableidx35];
    vlTOPp->__Vtableidx36 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xfU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x17U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x16U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x15U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r 
        = vlTOPp->__Vtable36_logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r
        [vlTOPp->__Vtableidx36];
    vlTOPp->__Vtableidx37 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x1eU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r 
        = vlTOPp->__Vtable37_logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r
        [vlTOPp->__Vtableidx37];
    vlTOPp->__Vtableidx38 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xfU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x2cU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x2bU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x2aU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r 
        = vlTOPp->__Vtable38_logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r
        [vlTOPp->__Vtableidx38];
    vlTOPp->__Vtableidx39 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x29U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x28U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x27U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r 
        = vlTOPp->__Vtable39_logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r
        [vlTOPp->__Vtableidx39];
    vlTOPp->__Vtableidx40 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x15U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x20U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1fU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1eU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x21U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r 
        = vlTOPp->__Vtable40_logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r
        [vlTOPp->__Vtableidx40];
    vlTOPp->__Vtableidx41 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1dU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1cU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r 
        = vlTOPp->__Vtable41_logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r
        [vlTOPp->__Vtableidx41];
    vlTOPp->__Vtableidx42 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 8U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 7U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 6U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r 
        = vlTOPp->__Vtable42_logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r
        [vlTOPp->__Vtableidx42];
    vlTOPp->__Vtableidx43 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x1bU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x29U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x28U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x27U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r 
        = vlTOPp->__Vtable43_logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r
        [vlTOPp->__Vtableidx43];
    vlTOPp->__Vtableidx44 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1dU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1cU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r 
        = vlTOPp->__Vtable44_logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r
        [vlTOPp->__Vtableidx44];
    vlTOPp->__Vtableidx45 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 5U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 4U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 3U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x21U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r 
        = vlTOPp->__Vtable45_logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r
        [vlTOPp->__Vtableidx45];
    vlTOPp->__Vtableidx46 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 5U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 4U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 3U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x21U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r 
        = vlTOPp->__Vtable46_logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r
        [vlTOPp->__Vtableidx46];
    vlTOPp->__Vtableidx47 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 9U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0xeU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0xdU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0xcU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x1bU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r 
        = vlTOPp->__Vtable47_logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r
        [vlTOPp->__Vtableidx47];
    vlTOPp->__Vtableidx48 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 9U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x1eU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r 
        = vlTOPp->__Vtable48_logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r
        [vlTOPp->__Vtableidx48];
    vlTOPp->__Vtableidx49 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x26U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x25U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x24U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2dU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r 
        = vlTOPp->__Vtable49_logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r
        [vlTOPp->__Vtableidx49];
    vlTOPp->__Vtableidx50 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x17U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x16U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x15U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r 
        = vlTOPp->__Vtable50_logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r
        [vlTOPp->__Vtableidx50];
    vlTOPp->__Vtableidx51 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 8U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 7U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 6U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x12U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r 
        = vlTOPp->__Vtable51_logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r
        [vlTOPp->__Vtableidx51];
    vlTOPp->__Vtableidx52 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 5U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 4U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 3U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r 
        = vlTOPp->__Vtable52_logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r
        [vlTOPp->__Vtableidx52];
    vlTOPp->__Vtableidx53 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xfU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1dU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1cU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r 
        = vlTOPp->__Vtable53_logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r
        [vlTOPp->__Vtableidx53];
    vlTOPp->__Vtableidx54 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x17U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x16U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x15U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r 
        = vlTOPp->__Vtable54_logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r
        [vlTOPp->__Vtableidx54];
    vlTOPp->__Vtableidx55 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 9U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x14U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x13U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x12U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r 
        = vlTOPp->__Vtable55_logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r
        [vlTOPp->__Vtableidx55];
    vlTOPp->__Vtableidx56 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 8U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 7U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 6U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r 
        = vlTOPp->__Vtable56_logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r
        [vlTOPp->__Vtableidx56];
    vlTOPp->__Vtableidx57 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0xbU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0xaU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 9U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x1bU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r 
        = vlTOPp->__Vtable57_logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r
        [vlTOPp->__Vtableidx57];
    vlTOPp->__Vtableidx58 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1dU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1cU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1bU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r 
        = vlTOPp->__Vtable58_logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r
        [vlTOPp->__Vtableidx58];
    vlTOPp->__Vtableidx59 = ((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x20U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x1fU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x1eU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x2aU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r 
        = vlTOPp->__Vtable59_logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r
        [vlTOPp->__Vtableidx59];
    vlTOPp->__Vtableidx60 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0xbU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0xaU)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 9U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x18U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r 
        = vlTOPp->__Vtable60_logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r
        [vlTOPp->__Vtableidx60];
    vlTOPp->__Vtableidx61 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x1bU)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r 
        = vlTOPp->__Vtable61_logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r
        [vlTOPp->__Vtableidx61];
    vlTOPp->__Vtableidx62 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x23U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x22U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x21U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x24U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r 
        = vlTOPp->__Vtable62_logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r
        [vlTOPp->__Vtableidx62];
    vlTOPp->__Vtableidx63 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x11U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x10U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0xfU)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x15U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r 
        = vlTOPp->__Vtable63_logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r
        [vlTOPp->__Vtableidx63];
    vlTOPp->__Vtableidx64 = ((0x1c0U & ((IData)((vlTOPp->logicnet__DOT__M0w 
                                                 >> 3U)) 
                                        << 6U)) | (
                                                   (0x20U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M0w 
                                                                >> 0x1aU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M0w 
                                                                   >> 0x19U)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlTOPp->logicnet__DOT__M0w 
                                                                      >> 0x18U)) 
                                                             << 3U)) 
                                                         | (7U 
                                                            & (IData)(
                                                                      (vlTOPp->logicnet__DOT__M0w 
                                                                       >> 0x27U)))))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r 
        = vlTOPp->__Vtable64_logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r
        [vlTOPp->__Vtableidx64];
    vlTOPp->M5 = ((0x7ff8U & (IData)(vlTOPp->M5)) | (IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r));
    vlTOPp->M5 = ((0x7fc7U & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r) 
                   << 3U));
    vlTOPp->M5 = ((0x7e3fU & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r) 
                   << 6U));
    vlTOPp->M5 = ((0x71ffU & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r) 
                   << 9U));
    vlTOPp->M5 = ((0xfffU & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r) 
                   << 0xcU));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xfffffff8U & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xffffffc7U & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xfffffff8U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r) 
                                           << 3U)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xfffffe3fU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xfffff1ffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xfffffe00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r) 
                                           << 9U)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xffff8fffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xfffc7fffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xffff8000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r) 
                                           << 0xfU)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xffe3ffffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xff1fffffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xffe00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r) 
                                           << 0x15U)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xf8ffffffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0xc7ffffffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xf8000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r) 
                                           << 0x1bU)));
    vlTOPp->logicnet__DOT__M4[0U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M4[0U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xfffffffeU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0x3fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r) 
                                           >> 2U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xfffffff1U & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xfffffffeU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r) 
                                           << 1U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xffffff8fU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xfffffc7fU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xffffff80U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r) 
                                           << 7U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xffffe3ffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xffff1fffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xffffe000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r) 
                                           << 0xdU)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xfff8ffffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xffc7ffffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xfff80000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r) 
                                           << 0x13U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xfe3fffffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0xf1ffffffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xfe000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r) 
                                           << 0x19U)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0x8fffffffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M4[1U] = ((0x7fffffffU & 
                                      vlTOPp->logicnet__DOT__M4[1U]) 
                                     | (0x80000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r) 
                                           << 0x1fU)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0x7fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r) 
                                           >> 1U)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xffffffe3U & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xffffff1fU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xffffffe0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r) 
                                           << 5U)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xfffff8ffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xffffc7ffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xfffff800U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r) 
                                           << 0xbU)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xfffe3fffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xfff1ffffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xfffe0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r) 
                                           << 0x11U)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xff8fffffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xfc7fffffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xff800000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r) 
                                           << 0x17U)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0xe3ffffffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M4[2U] = ((0x1fffffffU & 
                                      vlTOPp->logicnet__DOT__M4[2U]) 
                                     | (0xe0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r) 
                                           << 0x1dU)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xfffffff8U & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xffffffc7U & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xfffffff8U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r) 
                                           << 3U)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xfffffe3fU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xfffff1ffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xfffffe00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r) 
                                           << 9U)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xffff8fffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xfffc7fffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xffff8000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r) 
                                           << 0xfU)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xffe3ffffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xff1fffffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xffe00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r) 
                                           << 0x15U)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xf8ffffffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0xc7ffffffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xf8000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r) 
                                           << 0x1bU)));
    vlTOPp->logicnet__DOT__M3[0U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M3[0U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xfffffffeU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0x3fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r) 
                                           >> 2U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xfffffff1U & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xfffffffeU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r) 
                                           << 1U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xffffff8fU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xfffffc7fU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xffffff80U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r) 
                                           << 7U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xffffe3ffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xffff1fffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xffffe000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r) 
                                           << 0xdU)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xfff8ffffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xffc7ffffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xfff80000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r) 
                                           << 0x13U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xfe3fffffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0xf1ffffffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xfe000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r) 
                                           << 0x19U)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0x8fffffffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M3[1U] = ((0x7fffffffU & 
                                      vlTOPp->logicnet__DOT__M3[1U]) 
                                     | (0x80000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r) 
                                           << 0x1fU)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0x7fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r) 
                                           >> 1U)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xffffffe3U & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xffffff1fU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xffffffe0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r) 
                                           << 5U)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xfffff8ffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xffffc7ffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xfffff800U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r) 
                                           << 0xbU)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xfffe3fffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xfff1ffffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xfffe0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r) 
                                           << 0x11U)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xff8fffffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xfc7fffffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xff800000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r) 
                                           << 0x17U)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0xe3ffffffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M3[2U] = ((0x1fffffffU & 
                                      vlTOPp->logicnet__DOT__M3[2U]) 
                                     | (0xe0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r) 
                                           << 0x1dU)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xfffffff8U & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xffffffc7U & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xfffffff8U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r) 
                                           << 3U)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xfffffe3fU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xfffff1ffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xfffffe00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r) 
                                           << 9U)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xffff8fffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xfffc7fffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xffff8000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r) 
                                           << 0xfU)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xffe3ffffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xff1fffffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xffe00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r) 
                                           << 0x15U)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xf8ffffffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0xc7ffffffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xf8000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r) 
                                           << 0x1bU)));
    vlTOPp->logicnet__DOT__M2[0U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M2[0U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xfffffffeU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0x3fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r) 
                                           >> 2U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xfffffff1U & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xfffffffeU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r) 
                                           << 1U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xffffff8fU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xfffffc7fU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xffffff80U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r) 
                                           << 7U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xffffe3ffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xffff1fffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xffffe000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r) 
                                           << 0xdU)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xfff8ffffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xffc7ffffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xfff80000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r) 
                                           << 0x13U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xfe3fffffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0xf1ffffffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xfe000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r) 
                                           << 0x19U)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0x8fffffffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M2[1U] = ((0x7fffffffU & 
                                      vlTOPp->logicnet__DOT__M2[1U]) 
                                     | (0x80000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r) 
                                           << 0x1fU)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0x7fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r) 
                                           >> 1U)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xffffffe3U & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xffffff1fU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xffffffe0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r) 
                                           << 5U)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xfffff8ffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xffffc7ffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xfffff800U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r) 
                                           << 0xbU)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xfffe3fffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xfff1ffffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xfffe0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r) 
                                           << 0x11U)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xff8fffffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xfc7fffffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xff800000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r) 
                                           << 0x17U)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0xe3ffffffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M2[2U] = ((0x1fffffffU & 
                                      vlTOPp->logicnet__DOT__M2[2U]) 
                                     | (0xe0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r) 
                                           << 0x1dU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffffff8U & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffffffc7U & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffffff8U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r) 
                                           << 3U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffffe3fU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffff1ffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffffe00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r) 
                                           << 9U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffff8fffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffc7fffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffff8000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r) 
                                           << 0xfU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffe3ffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xff1fffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffe00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r) 
                                           << 0x15U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xf8ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xc7ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xf8000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r) 
                                           << 0x1bU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffffffeU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0x3fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r) 
                                           >> 2U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffffff1U & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffffffeU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r) 
                                           << 1U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffffff8fU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffffc7fU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffffff80U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r) 
                                           << 7U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffffe3ffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffff1fffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffffe000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r) 
                                           << 0xdU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfff8ffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffc7ffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfff80000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r) 
                                           << 0x13U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfe3fffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xf1ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfe000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r) 
                                           << 0x19U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0x8fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0x7fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0x80000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r) 
                                           << 0x1fU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0x7fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r) 
                                           >> 1U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffffffe3U & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffffff1fU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffffffe0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r) 
                                           << 5U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffff8ffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffffc7ffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffff800U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r) 
                                           << 0xbU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffe3fffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfff1ffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffe0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r) 
                                           << 0x11U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xff8fffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfc7fffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xff800000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r) 
                                           << 0x17U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xe3ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0x1fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xe0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r) 
                                           << 0x1dU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffffff8U & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffffffc7U & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffffff8U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r) 
                                           << 3U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffffe3fU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffff1ffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffffe00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r) 
                                           << 9U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffff8fffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffc7fffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffff8000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r) 
                                           << 0xfU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffe3ffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xff1fffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffe00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r) 
                                           << 0x15U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xf8ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xc7ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xf8000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r) 
                                           << 0x1bU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xfffffffeU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0x3fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r) 
                                           >> 2U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xfffffff1U & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xfffffffeU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r) 
                                           << 1U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xffffff8fU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xfffffc7fU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xffffff80U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r) 
                                           << 7U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xffffe3ffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xffff1fffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xffffe000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r) 
                                           << 0xdU)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xfff8ffffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xffc7ffffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xfff80000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r) 
                                           << 0x13U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xfe3fffffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0xf1ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xfe000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r) 
                                           << 0x19U)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0x8fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M1[4U] = ((0x7fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[4U]) 
                                     | (0x80000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r) 
                                           << 0x1fU)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0x7fffffffU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r) 
                                           >> 1U)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xffffffe3U & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xffffff1fU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xffffffe0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r) 
                                           << 5U)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xfffff8ffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xffffc7ffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xfffff800U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r) 
                                           << 0xbU)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xfffe3fffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xfff1ffffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xfffe0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r) 
                                           << 0x11U)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xff8fffffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xfc7fffffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xff800000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r) 
                                           << 0x17U)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0xe3ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M1[5U] = ((0x1fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[5U]) 
                                     | (0xe0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r) 
                                           << 0x1dU)));
}

void Vlogicnet::_eval(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_eval\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (((IData)(vlTOPp->clk) & (~ (IData)(vlTOPp->__Vclklast__TOP__clk)))) {
        vlTOPp->_sequent__TOP__1(vlSymsp);
        vlTOPp->__Vm_traceActivity[1U] = 1U;
    }
    // Final
    vlTOPp->__Vclklast__TOP__clk = vlTOPp->clk;
}

VL_INLINE_OPT QData Vlogicnet::_change_request(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_change_request\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    return (vlTOPp->_change_request_1(vlSymsp));
}

VL_INLINE_OPT QData Vlogicnet::_change_request_1(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_change_request_1\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vlogicnet::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((M0 & 0ULL))) {
        Verilated::overWidthError("M0");}
    if (VL_UNLIKELY((clk & 0xfeU))) {
        Verilated::overWidthError("clk");}
    if (VL_UNLIKELY((rst & 0xfeU))) {
        Verilated::overWidthError("rst");}
}
#endif  // VL_DEBUG
