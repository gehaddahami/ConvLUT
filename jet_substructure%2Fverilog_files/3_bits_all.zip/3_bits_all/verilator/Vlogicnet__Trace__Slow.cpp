// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vlogicnet__Syms.h"


//======================

void Vlogicnet::trace(VerilatedVcdC* tfp, int, int) {
    tfp->spTrace()->addInitCb(&traceInit, __VlSymsp);
    traceRegister(tfp->spTrace());
}

void Vlogicnet::traceInit(void* userp, VerilatedVcd* tracep, uint32_t code) {
    // Callback from tracep->open()
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    if (!Verilated::calcUnusedSigs()) {
        VL_FATAL_MT(__FILE__, __LINE__, __FILE__,
                        "Turning on wave traces requires Verilated::traceEverOn(true) call before time 0.");
    }
    vlSymsp->__Vm_baseCode = code;
    tracep->module(vlSymsp->name());
    tracep->scopeEscape(' ');
    Vlogicnet::traceInitTop(vlSymsp, tracep);
    tracep->scopeEscape('.');
}

//======================


void Vlogicnet::traceInitTop(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlTOPp->traceInitSub0(userp, tracep);
    }
}

void Vlogicnet::traceInitSub0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    const int c = vlSymsp->__Vm_baseCode;
    if (false && tracep && c) {}  // Prevent unused
    // Body
    {
        tracep->declQuad(c+359,"M0", false,-1, 47,0);
        tracep->declBit(c+361,"clk", false,-1);
        tracep->declBit(c+362,"rst", false,-1);
        tracep->declBus(c+363,"M5", false,-1, 14,0);
        tracep->declQuad(c+359,"logicnet M0", false,-1, 47,0);
        tracep->declBit(c+361,"logicnet clk", false,-1);
        tracep->declBit(c+362,"logicnet rst", false,-1);
        tracep->declBus(c+363,"logicnet M5", false,-1, 14,0);
        tracep->declQuad(c+1,"logicnet M0w", false,-1, 47,0);
        tracep->declArray(c+3,"logicnet M1", false,-1, 191,0);
        tracep->declArray(c+9,"logicnet M1w", false,-1, 191,0);
        tracep->declArray(c+15,"logicnet M2", false,-1, 95,0);
        tracep->declArray(c+18,"logicnet M2w", false,-1, 95,0);
        tracep->declArray(c+21,"logicnet M3", false,-1, 95,0);
        tracep->declArray(c+24,"logicnet M3w", false,-1, 95,0);
        tracep->declArray(c+27,"logicnet M4", false,-1, 95,0);
        tracep->declArray(c+30,"logicnet M4w", false,-1, 95,0);
        tracep->declBus(c+364,"logicnet layer0_reg DataWidth", false,-1, 31,0);
        tracep->declQuad(c+359,"logicnet layer0_reg data_in", false,-1, 47,0);
        tracep->declBit(c+361,"logicnet layer0_reg clk", false,-1);
        tracep->declBit(c+362,"logicnet layer0_reg rst", false,-1);
        tracep->declQuad(c+1,"logicnet layer0_reg data_out", false,-1, 47,0);
        tracep->declQuad(c+1,"logicnet layer0_inst M0", false,-1, 47,0);
        tracep->declArray(c+3,"logicnet layer0_inst M1", false,-1, 191,0);
        tracep->declBus(c+33,"logicnet layer0_inst layer0_N0_wire", false,-1, 8,0);
        tracep->declBus(c+34,"logicnet layer0_inst layer0_N1_wire", false,-1, 8,0);
        tracep->declBus(c+35,"logicnet layer0_inst layer0_N2_wire", false,-1, 8,0);
        tracep->declBus(c+36,"logicnet layer0_inst layer0_N3_wire", false,-1, 8,0);
        tracep->declBus(c+37,"logicnet layer0_inst layer0_N4_wire", false,-1, 8,0);
        tracep->declBus(c+38,"logicnet layer0_inst layer0_N5_wire", false,-1, 8,0);
        tracep->declBus(c+39,"logicnet layer0_inst layer0_N6_wire", false,-1, 8,0);
        tracep->declBus(c+40,"logicnet layer0_inst layer0_N7_wire", false,-1, 8,0);
        tracep->declBus(c+41,"logicnet layer0_inst layer0_N8_wire", false,-1, 8,0);
        tracep->declBus(c+42,"logicnet layer0_inst layer0_N9_wire", false,-1, 8,0);
        tracep->declBus(c+43,"logicnet layer0_inst layer0_N10_wire", false,-1, 8,0);
        tracep->declBus(c+44,"logicnet layer0_inst layer0_N11_wire", false,-1, 8,0);
        tracep->declBus(c+45,"logicnet layer0_inst layer0_N12_wire", false,-1, 8,0);
        tracep->declBus(c+46,"logicnet layer0_inst layer0_N13_wire", false,-1, 8,0);
        tracep->declBus(c+47,"logicnet layer0_inst layer0_N14_wire", false,-1, 8,0);
        tracep->declBus(c+48,"logicnet layer0_inst layer0_N15_wire", false,-1, 8,0);
        tracep->declBus(c+49,"logicnet layer0_inst layer0_N16_wire", false,-1, 8,0);
        tracep->declBus(c+50,"logicnet layer0_inst layer0_N17_wire", false,-1, 8,0);
        tracep->declBus(c+51,"logicnet layer0_inst layer0_N18_wire", false,-1, 8,0);
        tracep->declBus(c+52,"logicnet layer0_inst layer0_N19_wire", false,-1, 8,0);
        tracep->declBus(c+53,"logicnet layer0_inst layer0_N20_wire", false,-1, 8,0);
        tracep->declBus(c+54,"logicnet layer0_inst layer0_N21_wire", false,-1, 8,0);
        tracep->declBus(c+55,"logicnet layer0_inst layer0_N22_wire", false,-1, 8,0);
        tracep->declBus(c+56,"logicnet layer0_inst layer0_N23_wire", false,-1, 8,0);
        tracep->declBus(c+57,"logicnet layer0_inst layer0_N24_wire", false,-1, 8,0);
        tracep->declBus(c+58,"logicnet layer0_inst layer0_N25_wire", false,-1, 8,0);
        tracep->declBus(c+59,"logicnet layer0_inst layer0_N26_wire", false,-1, 8,0);
        tracep->declBus(c+60,"logicnet layer0_inst layer0_N27_wire", false,-1, 8,0);
        tracep->declBus(c+61,"logicnet layer0_inst layer0_N28_wire", false,-1, 8,0);
        tracep->declBus(c+62,"logicnet layer0_inst layer0_N29_wire", false,-1, 8,0);
        tracep->declBus(c+63,"logicnet layer0_inst layer0_N30_wire", false,-1, 8,0);
        tracep->declBus(c+64,"logicnet layer0_inst layer0_N31_wire", false,-1, 8,0);
        tracep->declBus(c+65,"logicnet layer0_inst layer0_N32_wire", false,-1, 8,0);
        tracep->declBus(c+66,"logicnet layer0_inst layer0_N33_wire", false,-1, 8,0);
        tracep->declBus(c+67,"logicnet layer0_inst layer0_N34_wire", false,-1, 8,0);
        tracep->declBus(c+68,"logicnet layer0_inst layer0_N35_wire", false,-1, 8,0);
        tracep->declBus(c+69,"logicnet layer0_inst layer0_N36_wire", false,-1, 8,0);
        tracep->declBus(c+70,"logicnet layer0_inst layer0_N37_wire", false,-1, 8,0);
        tracep->declBus(c+71,"logicnet layer0_inst layer0_N38_wire", false,-1, 8,0);
        tracep->declBus(c+72,"logicnet layer0_inst layer0_N39_wire", false,-1, 8,0);
        tracep->declBus(c+73,"logicnet layer0_inst layer0_N40_wire", false,-1, 8,0);
        tracep->declBus(c+74,"logicnet layer0_inst layer0_N41_wire", false,-1, 8,0);
        tracep->declBus(c+75,"logicnet layer0_inst layer0_N42_wire", false,-1, 8,0);
        tracep->declBus(c+67,"logicnet layer0_inst layer0_N43_wire", false,-1, 8,0);
        tracep->declBus(c+76,"logicnet layer0_inst layer0_N44_wire", false,-1, 8,0);
        tracep->declBus(c+76,"logicnet layer0_inst layer0_N45_wire", false,-1, 8,0);
        tracep->declBus(c+77,"logicnet layer0_inst layer0_N46_wire", false,-1, 8,0);
        tracep->declBus(c+78,"logicnet layer0_inst layer0_N47_wire", false,-1, 8,0);
        tracep->declBus(c+79,"logicnet layer0_inst layer0_N48_wire", false,-1, 8,0);
        tracep->declBus(c+80,"logicnet layer0_inst layer0_N49_wire", false,-1, 8,0);
        tracep->declBus(c+81,"logicnet layer0_inst layer0_N50_wire", false,-1, 8,0);
        tracep->declBus(c+82,"logicnet layer0_inst layer0_N51_wire", false,-1, 8,0);
        tracep->declBus(c+83,"logicnet layer0_inst layer0_N52_wire", false,-1, 8,0);
        tracep->declBus(c+84,"logicnet layer0_inst layer0_N53_wire", false,-1, 8,0);
        tracep->declBus(c+85,"logicnet layer0_inst layer0_N54_wire", false,-1, 8,0);
        tracep->declBus(c+86,"logicnet layer0_inst layer0_N55_wire", false,-1, 8,0);
        tracep->declBus(c+87,"logicnet layer0_inst layer0_N56_wire", false,-1, 8,0);
        tracep->declBus(c+88,"logicnet layer0_inst layer0_N57_wire", false,-1, 8,0);
        tracep->declBus(c+89,"logicnet layer0_inst layer0_N58_wire", false,-1, 8,0);
        tracep->declBus(c+90,"logicnet layer0_inst layer0_N59_wire", false,-1, 8,0);
        tracep->declBus(c+36,"logicnet layer0_inst layer0_N60_wire", false,-1, 8,0);
        tracep->declBus(c+91,"logicnet layer0_inst layer0_N61_wire", false,-1, 8,0);
        tracep->declBus(c+92,"logicnet layer0_inst layer0_N62_wire", false,-1, 8,0);
        tracep->declBus(c+33,"logicnet layer0_inst layer0_N63_wire", false,-1, 8,0);
        tracep->declBus(c+33,"logicnet layer0_inst layer0_N0_inst M0", false,-1, 8,0);
        tracep->declBus(c+93,"logicnet layer0_inst layer0_N0_inst M1", false,-1, 2,0);
        tracep->declBus(c+93,"logicnet layer0_inst layer0_N0_inst M1r", false,-1, 2,0);
        tracep->declBus(c+34,"logicnet layer0_inst layer0_N1_inst M0", false,-1, 8,0);
        tracep->declBus(c+94,"logicnet layer0_inst layer0_N1_inst M1", false,-1, 2,0);
        tracep->declBus(c+94,"logicnet layer0_inst layer0_N1_inst M1r", false,-1, 2,0);
        tracep->declBus(c+35,"logicnet layer0_inst layer0_N2_inst M0", false,-1, 8,0);
        tracep->declBus(c+95,"logicnet layer0_inst layer0_N2_inst M1", false,-1, 2,0);
        tracep->declBus(c+95,"logicnet layer0_inst layer0_N2_inst M1r", false,-1, 2,0);
        tracep->declBus(c+36,"logicnet layer0_inst layer0_N3_inst M0", false,-1, 8,0);
        tracep->declBus(c+96,"logicnet layer0_inst layer0_N3_inst M1", false,-1, 2,0);
        tracep->declBus(c+96,"logicnet layer0_inst layer0_N3_inst M1r", false,-1, 2,0);
        tracep->declBus(c+37,"logicnet layer0_inst layer0_N4_inst M0", false,-1, 8,0);
        tracep->declBus(c+97,"logicnet layer0_inst layer0_N4_inst M1", false,-1, 2,0);
        tracep->declBus(c+97,"logicnet layer0_inst layer0_N4_inst M1r", false,-1, 2,0);
        tracep->declBus(c+38,"logicnet layer0_inst layer0_N5_inst M0", false,-1, 8,0);
        tracep->declBus(c+98,"logicnet layer0_inst layer0_N5_inst M1", false,-1, 2,0);
        tracep->declBus(c+98,"logicnet layer0_inst layer0_N5_inst M1r", false,-1, 2,0);
        tracep->declBus(c+39,"logicnet layer0_inst layer0_N6_inst M0", false,-1, 8,0);
        tracep->declBus(c+99,"logicnet layer0_inst layer0_N6_inst M1", false,-1, 2,0);
        tracep->declBus(c+99,"logicnet layer0_inst layer0_N6_inst M1r", false,-1, 2,0);
        tracep->declBus(c+40,"logicnet layer0_inst layer0_N7_inst M0", false,-1, 8,0);
        tracep->declBus(c+100,"logicnet layer0_inst layer0_N7_inst M1", false,-1, 2,0);
        tracep->declBus(c+100,"logicnet layer0_inst layer0_N7_inst M1r", false,-1, 2,0);
        tracep->declBus(c+41,"logicnet layer0_inst layer0_N8_inst M0", false,-1, 8,0);
        tracep->declBus(c+101,"logicnet layer0_inst layer0_N8_inst M1", false,-1, 2,0);
        tracep->declBus(c+101,"logicnet layer0_inst layer0_N8_inst M1r", false,-1, 2,0);
        tracep->declBus(c+42,"logicnet layer0_inst layer0_N9_inst M0", false,-1, 8,0);
        tracep->declBus(c+102,"logicnet layer0_inst layer0_N9_inst M1", false,-1, 2,0);
        tracep->declBus(c+102,"logicnet layer0_inst layer0_N9_inst M1r", false,-1, 2,0);
        tracep->declBus(c+43,"logicnet layer0_inst layer0_N10_inst M0", false,-1, 8,0);
        tracep->declBus(c+103,"logicnet layer0_inst layer0_N10_inst M1", false,-1, 2,0);
        tracep->declBus(c+103,"logicnet layer0_inst layer0_N10_inst M1r", false,-1, 2,0);
        tracep->declBus(c+44,"logicnet layer0_inst layer0_N11_inst M0", false,-1, 8,0);
        tracep->declBus(c+104,"logicnet layer0_inst layer0_N11_inst M1", false,-1, 2,0);
        tracep->declBus(c+104,"logicnet layer0_inst layer0_N11_inst M1r", false,-1, 2,0);
        tracep->declBus(c+45,"logicnet layer0_inst layer0_N12_inst M0", false,-1, 8,0);
        tracep->declBus(c+105,"logicnet layer0_inst layer0_N12_inst M1", false,-1, 2,0);
        tracep->declBus(c+105,"logicnet layer0_inst layer0_N12_inst M1r", false,-1, 2,0);
        tracep->declBus(c+46,"logicnet layer0_inst layer0_N13_inst M0", false,-1, 8,0);
        tracep->declBus(c+106,"logicnet layer0_inst layer0_N13_inst M1", false,-1, 2,0);
        tracep->declBus(c+106,"logicnet layer0_inst layer0_N13_inst M1r", false,-1, 2,0);
        tracep->declBus(c+47,"logicnet layer0_inst layer0_N14_inst M0", false,-1, 8,0);
        tracep->declBus(c+107,"logicnet layer0_inst layer0_N14_inst M1", false,-1, 2,0);
        tracep->declBus(c+107,"logicnet layer0_inst layer0_N14_inst M1r", false,-1, 2,0);
        tracep->declBus(c+48,"logicnet layer0_inst layer0_N15_inst M0", false,-1, 8,0);
        tracep->declBus(c+108,"logicnet layer0_inst layer0_N15_inst M1", false,-1, 2,0);
        tracep->declBus(c+108,"logicnet layer0_inst layer0_N15_inst M1r", false,-1, 2,0);
        tracep->declBus(c+49,"logicnet layer0_inst layer0_N16_inst M0", false,-1, 8,0);
        tracep->declBus(c+109,"logicnet layer0_inst layer0_N16_inst M1", false,-1, 2,0);
        tracep->declBus(c+109,"logicnet layer0_inst layer0_N16_inst M1r", false,-1, 2,0);
        tracep->declBus(c+50,"logicnet layer0_inst layer0_N17_inst M0", false,-1, 8,0);
        tracep->declBus(c+110,"logicnet layer0_inst layer0_N17_inst M1", false,-1, 2,0);
        tracep->declBus(c+110,"logicnet layer0_inst layer0_N17_inst M1r", false,-1, 2,0);
        tracep->declBus(c+51,"logicnet layer0_inst layer0_N18_inst M0", false,-1, 8,0);
        tracep->declBus(c+111,"logicnet layer0_inst layer0_N18_inst M1", false,-1, 2,0);
        tracep->declBus(c+111,"logicnet layer0_inst layer0_N18_inst M1r", false,-1, 2,0);
        tracep->declBus(c+52,"logicnet layer0_inst layer0_N19_inst M0", false,-1, 8,0);
        tracep->declBus(c+112,"logicnet layer0_inst layer0_N19_inst M1", false,-1, 2,0);
        tracep->declBus(c+112,"logicnet layer0_inst layer0_N19_inst M1r", false,-1, 2,0);
        tracep->declBus(c+53,"logicnet layer0_inst layer0_N20_inst M0", false,-1, 8,0);
        tracep->declBus(c+113,"logicnet layer0_inst layer0_N20_inst M1", false,-1, 2,0);
        tracep->declBus(c+113,"logicnet layer0_inst layer0_N20_inst M1r", false,-1, 2,0);
        tracep->declBus(c+54,"logicnet layer0_inst layer0_N21_inst M0", false,-1, 8,0);
        tracep->declBus(c+114,"logicnet layer0_inst layer0_N21_inst M1", false,-1, 2,0);
        tracep->declBus(c+114,"logicnet layer0_inst layer0_N21_inst M1r", false,-1, 2,0);
        tracep->declBus(c+55,"logicnet layer0_inst layer0_N22_inst M0", false,-1, 8,0);
        tracep->declBus(c+115,"logicnet layer0_inst layer0_N22_inst M1", false,-1, 2,0);
        tracep->declBus(c+115,"logicnet layer0_inst layer0_N22_inst M1r", false,-1, 2,0);
        tracep->declBus(c+56,"logicnet layer0_inst layer0_N23_inst M0", false,-1, 8,0);
        tracep->declBus(c+116,"logicnet layer0_inst layer0_N23_inst M1", false,-1, 2,0);
        tracep->declBus(c+116,"logicnet layer0_inst layer0_N23_inst M1r", false,-1, 2,0);
        tracep->declBus(c+57,"logicnet layer0_inst layer0_N24_inst M0", false,-1, 8,0);
        tracep->declBus(c+117,"logicnet layer0_inst layer0_N24_inst M1", false,-1, 2,0);
        tracep->declBus(c+117,"logicnet layer0_inst layer0_N24_inst M1r", false,-1, 2,0);
        tracep->declBus(c+58,"logicnet layer0_inst layer0_N25_inst M0", false,-1, 8,0);
        tracep->declBus(c+118,"logicnet layer0_inst layer0_N25_inst M1", false,-1, 2,0);
        tracep->declBus(c+118,"logicnet layer0_inst layer0_N25_inst M1r", false,-1, 2,0);
        tracep->declBus(c+59,"logicnet layer0_inst layer0_N26_inst M0", false,-1, 8,0);
        tracep->declBus(c+119,"logicnet layer0_inst layer0_N26_inst M1", false,-1, 2,0);
        tracep->declBus(c+119,"logicnet layer0_inst layer0_N26_inst M1r", false,-1, 2,0);
        tracep->declBus(c+60,"logicnet layer0_inst layer0_N27_inst M0", false,-1, 8,0);
        tracep->declBus(c+120,"logicnet layer0_inst layer0_N27_inst M1", false,-1, 2,0);
        tracep->declBus(c+120,"logicnet layer0_inst layer0_N27_inst M1r", false,-1, 2,0);
        tracep->declBus(c+61,"logicnet layer0_inst layer0_N28_inst M0", false,-1, 8,0);
        tracep->declBus(c+121,"logicnet layer0_inst layer0_N28_inst M1", false,-1, 2,0);
        tracep->declBus(c+121,"logicnet layer0_inst layer0_N28_inst M1r", false,-1, 2,0);
        tracep->declBus(c+62,"logicnet layer0_inst layer0_N29_inst M0", false,-1, 8,0);
        tracep->declBus(c+122,"logicnet layer0_inst layer0_N29_inst M1", false,-1, 2,0);
        tracep->declBus(c+122,"logicnet layer0_inst layer0_N29_inst M1r", false,-1, 2,0);
        tracep->declBus(c+63,"logicnet layer0_inst layer0_N30_inst M0", false,-1, 8,0);
        tracep->declBus(c+123,"logicnet layer0_inst layer0_N30_inst M1", false,-1, 2,0);
        tracep->declBus(c+123,"logicnet layer0_inst layer0_N30_inst M1r", false,-1, 2,0);
        tracep->declBus(c+64,"logicnet layer0_inst layer0_N31_inst M0", false,-1, 8,0);
        tracep->declBus(c+124,"logicnet layer0_inst layer0_N31_inst M1", false,-1, 2,0);
        tracep->declBus(c+124,"logicnet layer0_inst layer0_N31_inst M1r", false,-1, 2,0);
        tracep->declBus(c+65,"logicnet layer0_inst layer0_N32_inst M0", false,-1, 8,0);
        tracep->declBus(c+125,"logicnet layer0_inst layer0_N32_inst M1", false,-1, 2,0);
        tracep->declBus(c+125,"logicnet layer0_inst layer0_N32_inst M1r", false,-1, 2,0);
        tracep->declBus(c+66,"logicnet layer0_inst layer0_N33_inst M0", false,-1, 8,0);
        tracep->declBus(c+126,"logicnet layer0_inst layer0_N33_inst M1", false,-1, 2,0);
        tracep->declBus(c+126,"logicnet layer0_inst layer0_N33_inst M1r", false,-1, 2,0);
        tracep->declBus(c+67,"logicnet layer0_inst layer0_N34_inst M0", false,-1, 8,0);
        tracep->declBus(c+127,"logicnet layer0_inst layer0_N34_inst M1", false,-1, 2,0);
        tracep->declBus(c+127,"logicnet layer0_inst layer0_N34_inst M1r", false,-1, 2,0);
        tracep->declBus(c+68,"logicnet layer0_inst layer0_N35_inst M0", false,-1, 8,0);
        tracep->declBus(c+128,"logicnet layer0_inst layer0_N35_inst M1", false,-1, 2,0);
        tracep->declBus(c+128,"logicnet layer0_inst layer0_N35_inst M1r", false,-1, 2,0);
        tracep->declBus(c+69,"logicnet layer0_inst layer0_N36_inst M0", false,-1, 8,0);
        tracep->declBus(c+129,"logicnet layer0_inst layer0_N36_inst M1", false,-1, 2,0);
        tracep->declBus(c+129,"logicnet layer0_inst layer0_N36_inst M1r", false,-1, 2,0);
        tracep->declBus(c+70,"logicnet layer0_inst layer0_N37_inst M0", false,-1, 8,0);
        tracep->declBus(c+130,"logicnet layer0_inst layer0_N37_inst M1", false,-1, 2,0);
        tracep->declBus(c+130,"logicnet layer0_inst layer0_N37_inst M1r", false,-1, 2,0);
        tracep->declBus(c+71,"logicnet layer0_inst layer0_N38_inst M0", false,-1, 8,0);
        tracep->declBus(c+131,"logicnet layer0_inst layer0_N38_inst M1", false,-1, 2,0);
        tracep->declBus(c+131,"logicnet layer0_inst layer0_N38_inst M1r", false,-1, 2,0);
        tracep->declBus(c+72,"logicnet layer0_inst layer0_N39_inst M0", false,-1, 8,0);
        tracep->declBus(c+132,"logicnet layer0_inst layer0_N39_inst M1", false,-1, 2,0);
        tracep->declBus(c+132,"logicnet layer0_inst layer0_N39_inst M1r", false,-1, 2,0);
        tracep->declBus(c+73,"logicnet layer0_inst layer0_N40_inst M0", false,-1, 8,0);
        tracep->declBus(c+133,"logicnet layer0_inst layer0_N40_inst M1", false,-1, 2,0);
        tracep->declBus(c+133,"logicnet layer0_inst layer0_N40_inst M1r", false,-1, 2,0);
        tracep->declBus(c+74,"logicnet layer0_inst layer0_N41_inst M0", false,-1, 8,0);
        tracep->declBus(c+134,"logicnet layer0_inst layer0_N41_inst M1", false,-1, 2,0);
        tracep->declBus(c+134,"logicnet layer0_inst layer0_N41_inst M1r", false,-1, 2,0);
        tracep->declBus(c+75,"logicnet layer0_inst layer0_N42_inst M0", false,-1, 8,0);
        tracep->declBus(c+135,"logicnet layer0_inst layer0_N42_inst M1", false,-1, 2,0);
        tracep->declBus(c+135,"logicnet layer0_inst layer0_N42_inst M1r", false,-1, 2,0);
        tracep->declBus(c+67,"logicnet layer0_inst layer0_N43_inst M0", false,-1, 8,0);
        tracep->declBus(c+136,"logicnet layer0_inst layer0_N43_inst M1", false,-1, 2,0);
        tracep->declBus(c+136,"logicnet layer0_inst layer0_N43_inst M1r", false,-1, 2,0);
        tracep->declBus(c+76,"logicnet layer0_inst layer0_N44_inst M0", false,-1, 8,0);
        tracep->declBus(c+137,"logicnet layer0_inst layer0_N44_inst M1", false,-1, 2,0);
        tracep->declBus(c+137,"logicnet layer0_inst layer0_N44_inst M1r", false,-1, 2,0);
        tracep->declBus(c+76,"logicnet layer0_inst layer0_N45_inst M0", false,-1, 8,0);
        tracep->declBus(c+138,"logicnet layer0_inst layer0_N45_inst M1", false,-1, 2,0);
        tracep->declBus(c+138,"logicnet layer0_inst layer0_N45_inst M1r", false,-1, 2,0);
        tracep->declBus(c+77,"logicnet layer0_inst layer0_N46_inst M0", false,-1, 8,0);
        tracep->declBus(c+139,"logicnet layer0_inst layer0_N46_inst M1", false,-1, 2,0);
        tracep->declBus(c+139,"logicnet layer0_inst layer0_N46_inst M1r", false,-1, 2,0);
        tracep->declBus(c+78,"logicnet layer0_inst layer0_N47_inst M0", false,-1, 8,0);
        tracep->declBus(c+140,"logicnet layer0_inst layer0_N47_inst M1", false,-1, 2,0);
        tracep->declBus(c+140,"logicnet layer0_inst layer0_N47_inst M1r", false,-1, 2,0);
        tracep->declBus(c+79,"logicnet layer0_inst layer0_N48_inst M0", false,-1, 8,0);
        tracep->declBus(c+141,"logicnet layer0_inst layer0_N48_inst M1", false,-1, 2,0);
        tracep->declBus(c+141,"logicnet layer0_inst layer0_N48_inst M1r", false,-1, 2,0);
        tracep->declBus(c+80,"logicnet layer0_inst layer0_N49_inst M0", false,-1, 8,0);
        tracep->declBus(c+142,"logicnet layer0_inst layer0_N49_inst M1", false,-1, 2,0);
        tracep->declBus(c+142,"logicnet layer0_inst layer0_N49_inst M1r", false,-1, 2,0);
        tracep->declBus(c+81,"logicnet layer0_inst layer0_N50_inst M0", false,-1, 8,0);
        tracep->declBus(c+143,"logicnet layer0_inst layer0_N50_inst M1", false,-1, 2,0);
        tracep->declBus(c+143,"logicnet layer0_inst layer0_N50_inst M1r", false,-1, 2,0);
        tracep->declBus(c+82,"logicnet layer0_inst layer0_N51_inst M0", false,-1, 8,0);
        tracep->declBus(c+144,"logicnet layer0_inst layer0_N51_inst M1", false,-1, 2,0);
        tracep->declBus(c+144,"logicnet layer0_inst layer0_N51_inst M1r", false,-1, 2,0);
        tracep->declBus(c+83,"logicnet layer0_inst layer0_N52_inst M0", false,-1, 8,0);
        tracep->declBus(c+145,"logicnet layer0_inst layer0_N52_inst M1", false,-1, 2,0);
        tracep->declBus(c+145,"logicnet layer0_inst layer0_N52_inst M1r", false,-1, 2,0);
        tracep->declBus(c+84,"logicnet layer0_inst layer0_N53_inst M0", false,-1, 8,0);
        tracep->declBus(c+146,"logicnet layer0_inst layer0_N53_inst M1", false,-1, 2,0);
        tracep->declBus(c+146,"logicnet layer0_inst layer0_N53_inst M1r", false,-1, 2,0);
        tracep->declBus(c+85,"logicnet layer0_inst layer0_N54_inst M0", false,-1, 8,0);
        tracep->declBus(c+147,"logicnet layer0_inst layer0_N54_inst M1", false,-1, 2,0);
        tracep->declBus(c+147,"logicnet layer0_inst layer0_N54_inst M1r", false,-1, 2,0);
        tracep->declBus(c+86,"logicnet layer0_inst layer0_N55_inst M0", false,-1, 8,0);
        tracep->declBus(c+148,"logicnet layer0_inst layer0_N55_inst M1", false,-1, 2,0);
        tracep->declBus(c+148,"logicnet layer0_inst layer0_N55_inst M1r", false,-1, 2,0);
        tracep->declBus(c+87,"logicnet layer0_inst layer0_N56_inst M0", false,-1, 8,0);
        tracep->declBus(c+149,"logicnet layer0_inst layer0_N56_inst M1", false,-1, 2,0);
        tracep->declBus(c+149,"logicnet layer0_inst layer0_N56_inst M1r", false,-1, 2,0);
        tracep->declBus(c+88,"logicnet layer0_inst layer0_N57_inst M0", false,-1, 8,0);
        tracep->declBus(c+150,"logicnet layer0_inst layer0_N57_inst M1", false,-1, 2,0);
        tracep->declBus(c+150,"logicnet layer0_inst layer0_N57_inst M1r", false,-1, 2,0);
        tracep->declBus(c+89,"logicnet layer0_inst layer0_N58_inst M0", false,-1, 8,0);
        tracep->declBus(c+151,"logicnet layer0_inst layer0_N58_inst M1", false,-1, 2,0);
        tracep->declBus(c+151,"logicnet layer0_inst layer0_N58_inst M1r", false,-1, 2,0);
        tracep->declBus(c+90,"logicnet layer0_inst layer0_N59_inst M0", false,-1, 8,0);
        tracep->declBus(c+152,"logicnet layer0_inst layer0_N59_inst M1", false,-1, 2,0);
        tracep->declBus(c+152,"logicnet layer0_inst layer0_N59_inst M1r", false,-1, 2,0);
        tracep->declBus(c+36,"logicnet layer0_inst layer0_N60_inst M0", false,-1, 8,0);
        tracep->declBus(c+153,"logicnet layer0_inst layer0_N60_inst M1", false,-1, 2,0);
        tracep->declBus(c+153,"logicnet layer0_inst layer0_N60_inst M1r", false,-1, 2,0);
        tracep->declBus(c+91,"logicnet layer0_inst layer0_N61_inst M0", false,-1, 8,0);
        tracep->declBus(c+154,"logicnet layer0_inst layer0_N61_inst M1", false,-1, 2,0);
        tracep->declBus(c+154,"logicnet layer0_inst layer0_N61_inst M1r", false,-1, 2,0);
        tracep->declBus(c+92,"logicnet layer0_inst layer0_N62_inst M0", false,-1, 8,0);
        tracep->declBus(c+155,"logicnet layer0_inst layer0_N62_inst M1", false,-1, 2,0);
        tracep->declBus(c+155,"logicnet layer0_inst layer0_N62_inst M1r", false,-1, 2,0);
        tracep->declBus(c+33,"logicnet layer0_inst layer0_N63_inst M0", false,-1, 8,0);
        tracep->declBus(c+156,"logicnet layer0_inst layer0_N63_inst M1", false,-1, 2,0);
        tracep->declBus(c+156,"logicnet layer0_inst layer0_N63_inst M1r", false,-1, 2,0);
        tracep->declBus(c+365,"logicnet layer1_reg DataWidth", false,-1, 31,0);
        tracep->declArray(c+3,"logicnet layer1_reg data_in", false,-1, 191,0);
        tracep->declBit(c+361,"logicnet layer1_reg clk", false,-1);
        tracep->declBit(c+362,"logicnet layer1_reg rst", false,-1);
        tracep->declArray(c+9,"logicnet layer1_reg data_out", false,-1, 191,0);
        tracep->declArray(c+9,"logicnet layer1_inst M0", false,-1, 191,0);
        tracep->declArray(c+15,"logicnet layer1_inst M1", false,-1, 95,0);
        tracep->declBus(c+157,"logicnet layer1_inst layer1_N0_wire", false,-1, 8,0);
        tracep->declBus(c+158,"logicnet layer1_inst layer1_N1_wire", false,-1, 8,0);
        tracep->declBus(c+159,"logicnet layer1_inst layer1_N2_wire", false,-1, 8,0);
        tracep->declBus(c+160,"logicnet layer1_inst layer1_N3_wire", false,-1, 8,0);
        tracep->declBus(c+161,"logicnet layer1_inst layer1_N4_wire", false,-1, 8,0);
        tracep->declBus(c+162,"logicnet layer1_inst layer1_N5_wire", false,-1, 8,0);
        tracep->declBus(c+163,"logicnet layer1_inst layer1_N6_wire", false,-1, 8,0);
        tracep->declBus(c+164,"logicnet layer1_inst layer1_N7_wire", false,-1, 8,0);
        tracep->declBus(c+165,"logicnet layer1_inst layer1_N8_wire", false,-1, 8,0);
        tracep->declBus(c+166,"logicnet layer1_inst layer1_N9_wire", false,-1, 8,0);
        tracep->declBus(c+167,"logicnet layer1_inst layer1_N10_wire", false,-1, 8,0);
        tracep->declBus(c+168,"logicnet layer1_inst layer1_N11_wire", false,-1, 8,0);
        tracep->declBus(c+169,"logicnet layer1_inst layer1_N12_wire", false,-1, 8,0);
        tracep->declBus(c+170,"logicnet layer1_inst layer1_N13_wire", false,-1, 8,0);
        tracep->declBus(c+171,"logicnet layer1_inst layer1_N14_wire", false,-1, 8,0);
        tracep->declBus(c+172,"logicnet layer1_inst layer1_N15_wire", false,-1, 8,0);
        tracep->declBus(c+173,"logicnet layer1_inst layer1_N16_wire", false,-1, 8,0);
        tracep->declBus(c+174,"logicnet layer1_inst layer1_N17_wire", false,-1, 8,0);
        tracep->declBus(c+175,"logicnet layer1_inst layer1_N18_wire", false,-1, 8,0);
        tracep->declBus(c+176,"logicnet layer1_inst layer1_N19_wire", false,-1, 8,0);
        tracep->declBus(c+177,"logicnet layer1_inst layer1_N20_wire", false,-1, 8,0);
        tracep->declBus(c+178,"logicnet layer1_inst layer1_N21_wire", false,-1, 8,0);
        tracep->declBus(c+179,"logicnet layer1_inst layer1_N22_wire", false,-1, 8,0);
        tracep->declBus(c+180,"logicnet layer1_inst layer1_N23_wire", false,-1, 8,0);
        tracep->declBus(c+181,"logicnet layer1_inst layer1_N24_wire", false,-1, 8,0);
        tracep->declBus(c+182,"logicnet layer1_inst layer1_N25_wire", false,-1, 8,0);
        tracep->declBus(c+183,"logicnet layer1_inst layer1_N26_wire", false,-1, 8,0);
        tracep->declBus(c+184,"logicnet layer1_inst layer1_N27_wire", false,-1, 8,0);
        tracep->declBus(c+185,"logicnet layer1_inst layer1_N28_wire", false,-1, 8,0);
        tracep->declBus(c+186,"logicnet layer1_inst layer1_N29_wire", false,-1, 8,0);
        tracep->declBus(c+187,"logicnet layer1_inst layer1_N30_wire", false,-1, 8,0);
        tracep->declBus(c+188,"logicnet layer1_inst layer1_N31_wire", false,-1, 8,0);
        tracep->declBus(c+157,"logicnet layer1_inst layer1_N0_inst M0", false,-1, 8,0);
        tracep->declBus(c+189,"logicnet layer1_inst layer1_N0_inst M1", false,-1, 2,0);
        tracep->declBus(c+189,"logicnet layer1_inst layer1_N0_inst M1r", false,-1, 2,0);
        tracep->declBus(c+158,"logicnet layer1_inst layer1_N1_inst M0", false,-1, 8,0);
        tracep->declBus(c+190,"logicnet layer1_inst layer1_N1_inst M1", false,-1, 2,0);
        tracep->declBus(c+190,"logicnet layer1_inst layer1_N1_inst M1r", false,-1, 2,0);
        tracep->declBus(c+159,"logicnet layer1_inst layer1_N2_inst M0", false,-1, 8,0);
        tracep->declBus(c+191,"logicnet layer1_inst layer1_N2_inst M1", false,-1, 2,0);
        tracep->declBus(c+191,"logicnet layer1_inst layer1_N2_inst M1r", false,-1, 2,0);
        tracep->declBus(c+160,"logicnet layer1_inst layer1_N3_inst M0", false,-1, 8,0);
        tracep->declBus(c+192,"logicnet layer1_inst layer1_N3_inst M1", false,-1, 2,0);
        tracep->declBus(c+192,"logicnet layer1_inst layer1_N3_inst M1r", false,-1, 2,0);
        tracep->declBus(c+161,"logicnet layer1_inst layer1_N4_inst M0", false,-1, 8,0);
        tracep->declBus(c+193,"logicnet layer1_inst layer1_N4_inst M1", false,-1, 2,0);
        tracep->declBus(c+193,"logicnet layer1_inst layer1_N4_inst M1r", false,-1, 2,0);
        tracep->declBus(c+162,"logicnet layer1_inst layer1_N5_inst M0", false,-1, 8,0);
        tracep->declBus(c+194,"logicnet layer1_inst layer1_N5_inst M1", false,-1, 2,0);
        tracep->declBus(c+194,"logicnet layer1_inst layer1_N5_inst M1r", false,-1, 2,0);
        tracep->declBus(c+163,"logicnet layer1_inst layer1_N6_inst M0", false,-1, 8,0);
        tracep->declBus(c+195,"logicnet layer1_inst layer1_N6_inst M1", false,-1, 2,0);
        tracep->declBus(c+195,"logicnet layer1_inst layer1_N6_inst M1r", false,-1, 2,0);
        tracep->declBus(c+164,"logicnet layer1_inst layer1_N7_inst M0", false,-1, 8,0);
        tracep->declBus(c+196,"logicnet layer1_inst layer1_N7_inst M1", false,-1, 2,0);
        tracep->declBus(c+196,"logicnet layer1_inst layer1_N7_inst M1r", false,-1, 2,0);
        tracep->declBus(c+165,"logicnet layer1_inst layer1_N8_inst M0", false,-1, 8,0);
        tracep->declBus(c+197,"logicnet layer1_inst layer1_N8_inst M1", false,-1, 2,0);
        tracep->declBus(c+197,"logicnet layer1_inst layer1_N8_inst M1r", false,-1, 2,0);
        tracep->declBus(c+166,"logicnet layer1_inst layer1_N9_inst M0", false,-1, 8,0);
        tracep->declBus(c+198,"logicnet layer1_inst layer1_N9_inst M1", false,-1, 2,0);
        tracep->declBus(c+198,"logicnet layer1_inst layer1_N9_inst M1r", false,-1, 2,0);
        tracep->declBus(c+167,"logicnet layer1_inst layer1_N10_inst M0", false,-1, 8,0);
        tracep->declBus(c+199,"logicnet layer1_inst layer1_N10_inst M1", false,-1, 2,0);
        tracep->declBus(c+199,"logicnet layer1_inst layer1_N10_inst M1r", false,-1, 2,0);
        tracep->declBus(c+168,"logicnet layer1_inst layer1_N11_inst M0", false,-1, 8,0);
        tracep->declBus(c+200,"logicnet layer1_inst layer1_N11_inst M1", false,-1, 2,0);
        tracep->declBus(c+200,"logicnet layer1_inst layer1_N11_inst M1r", false,-1, 2,0);
        tracep->declBus(c+169,"logicnet layer1_inst layer1_N12_inst M0", false,-1, 8,0);
        tracep->declBus(c+201,"logicnet layer1_inst layer1_N12_inst M1", false,-1, 2,0);
        tracep->declBus(c+201,"logicnet layer1_inst layer1_N12_inst M1r", false,-1, 2,0);
        tracep->declBus(c+170,"logicnet layer1_inst layer1_N13_inst M0", false,-1, 8,0);
        tracep->declBus(c+202,"logicnet layer1_inst layer1_N13_inst M1", false,-1, 2,0);
        tracep->declBus(c+202,"logicnet layer1_inst layer1_N13_inst M1r", false,-1, 2,0);
        tracep->declBus(c+171,"logicnet layer1_inst layer1_N14_inst M0", false,-1, 8,0);
        tracep->declBus(c+203,"logicnet layer1_inst layer1_N14_inst M1", false,-1, 2,0);
        tracep->declBus(c+203,"logicnet layer1_inst layer1_N14_inst M1r", false,-1, 2,0);
        tracep->declBus(c+172,"logicnet layer1_inst layer1_N15_inst M0", false,-1, 8,0);
        tracep->declBus(c+204,"logicnet layer1_inst layer1_N15_inst M1", false,-1, 2,0);
        tracep->declBus(c+204,"logicnet layer1_inst layer1_N15_inst M1r", false,-1, 2,0);
        tracep->declBus(c+173,"logicnet layer1_inst layer1_N16_inst M0", false,-1, 8,0);
        tracep->declBus(c+205,"logicnet layer1_inst layer1_N16_inst M1", false,-1, 2,0);
        tracep->declBus(c+205,"logicnet layer1_inst layer1_N16_inst M1r", false,-1, 2,0);
        tracep->declBus(c+174,"logicnet layer1_inst layer1_N17_inst M0", false,-1, 8,0);
        tracep->declBus(c+206,"logicnet layer1_inst layer1_N17_inst M1", false,-1, 2,0);
        tracep->declBus(c+206,"logicnet layer1_inst layer1_N17_inst M1r", false,-1, 2,0);
        tracep->declBus(c+175,"logicnet layer1_inst layer1_N18_inst M0", false,-1, 8,0);
        tracep->declBus(c+207,"logicnet layer1_inst layer1_N18_inst M1", false,-1, 2,0);
        tracep->declBus(c+207,"logicnet layer1_inst layer1_N18_inst M1r", false,-1, 2,0);
        tracep->declBus(c+176,"logicnet layer1_inst layer1_N19_inst M0", false,-1, 8,0);
        tracep->declBus(c+208,"logicnet layer1_inst layer1_N19_inst M1", false,-1, 2,0);
        tracep->declBus(c+208,"logicnet layer1_inst layer1_N19_inst M1r", false,-1, 2,0);
        tracep->declBus(c+177,"logicnet layer1_inst layer1_N20_inst M0", false,-1, 8,0);
        tracep->declBus(c+209,"logicnet layer1_inst layer1_N20_inst M1", false,-1, 2,0);
        tracep->declBus(c+209,"logicnet layer1_inst layer1_N20_inst M1r", false,-1, 2,0);
        tracep->declBus(c+178,"logicnet layer1_inst layer1_N21_inst M0", false,-1, 8,0);
        tracep->declBus(c+210,"logicnet layer1_inst layer1_N21_inst M1", false,-1, 2,0);
        tracep->declBus(c+210,"logicnet layer1_inst layer1_N21_inst M1r", false,-1, 2,0);
        tracep->declBus(c+179,"logicnet layer1_inst layer1_N22_inst M0", false,-1, 8,0);
        tracep->declBus(c+211,"logicnet layer1_inst layer1_N22_inst M1", false,-1, 2,0);
        tracep->declBus(c+211,"logicnet layer1_inst layer1_N22_inst M1r", false,-1, 2,0);
        tracep->declBus(c+180,"logicnet layer1_inst layer1_N23_inst M0", false,-1, 8,0);
        tracep->declBus(c+212,"logicnet layer1_inst layer1_N23_inst M1", false,-1, 2,0);
        tracep->declBus(c+212,"logicnet layer1_inst layer1_N23_inst M1r", false,-1, 2,0);
        tracep->declBus(c+181,"logicnet layer1_inst layer1_N24_inst M0", false,-1, 8,0);
        tracep->declBus(c+213,"logicnet layer1_inst layer1_N24_inst M1", false,-1, 2,0);
        tracep->declBus(c+213,"logicnet layer1_inst layer1_N24_inst M1r", false,-1, 2,0);
        tracep->declBus(c+182,"logicnet layer1_inst layer1_N25_inst M0", false,-1, 8,0);
        tracep->declBus(c+214,"logicnet layer1_inst layer1_N25_inst M1", false,-1, 2,0);
        tracep->declBus(c+214,"logicnet layer1_inst layer1_N25_inst M1r", false,-1, 2,0);
        tracep->declBus(c+183,"logicnet layer1_inst layer1_N26_inst M0", false,-1, 8,0);
        tracep->declBus(c+215,"logicnet layer1_inst layer1_N26_inst M1", false,-1, 2,0);
        tracep->declBus(c+215,"logicnet layer1_inst layer1_N26_inst M1r", false,-1, 2,0);
        tracep->declBus(c+184,"logicnet layer1_inst layer1_N27_inst M0", false,-1, 8,0);
        tracep->declBus(c+216,"logicnet layer1_inst layer1_N27_inst M1", false,-1, 2,0);
        tracep->declBus(c+216,"logicnet layer1_inst layer1_N27_inst M1r", false,-1, 2,0);
        tracep->declBus(c+185,"logicnet layer1_inst layer1_N28_inst M0", false,-1, 8,0);
        tracep->declBus(c+217,"logicnet layer1_inst layer1_N28_inst M1", false,-1, 2,0);
        tracep->declBus(c+217,"logicnet layer1_inst layer1_N28_inst M1r", false,-1, 2,0);
        tracep->declBus(c+186,"logicnet layer1_inst layer1_N29_inst M0", false,-1, 8,0);
        tracep->declBus(c+218,"logicnet layer1_inst layer1_N29_inst M1", false,-1, 2,0);
        tracep->declBus(c+218,"logicnet layer1_inst layer1_N29_inst M1r", false,-1, 2,0);
        tracep->declBus(c+187,"logicnet layer1_inst layer1_N30_inst M0", false,-1, 8,0);
        tracep->declBus(c+219,"logicnet layer1_inst layer1_N30_inst M1", false,-1, 2,0);
        tracep->declBus(c+219,"logicnet layer1_inst layer1_N30_inst M1r", false,-1, 2,0);
        tracep->declBus(c+188,"logicnet layer1_inst layer1_N31_inst M0", false,-1, 8,0);
        tracep->declBus(c+220,"logicnet layer1_inst layer1_N31_inst M1", false,-1, 2,0);
        tracep->declBus(c+220,"logicnet layer1_inst layer1_N31_inst M1r", false,-1, 2,0);
        tracep->declBus(c+366,"logicnet layer2_reg DataWidth", false,-1, 31,0);
        tracep->declArray(c+15,"logicnet layer2_reg data_in", false,-1, 95,0);
        tracep->declBit(c+361,"logicnet layer2_reg clk", false,-1);
        tracep->declBit(c+362,"logicnet layer2_reg rst", false,-1);
        tracep->declArray(c+18,"logicnet layer2_reg data_out", false,-1, 95,0);
        tracep->declArray(c+18,"logicnet layer2_inst M0", false,-1, 95,0);
        tracep->declArray(c+21,"logicnet layer2_inst M1", false,-1, 95,0);
        tracep->declBus(c+221,"logicnet layer2_inst layer2_N0_wire", false,-1, 8,0);
        tracep->declBus(c+222,"logicnet layer2_inst layer2_N1_wire", false,-1, 8,0);
        tracep->declBus(c+223,"logicnet layer2_inst layer2_N2_wire", false,-1, 8,0);
        tracep->declBus(c+224,"logicnet layer2_inst layer2_N3_wire", false,-1, 8,0);
        tracep->declBus(c+225,"logicnet layer2_inst layer2_N4_wire", false,-1, 8,0);
        tracep->declBus(c+226,"logicnet layer2_inst layer2_N5_wire", false,-1, 8,0);
        tracep->declBus(c+227,"logicnet layer2_inst layer2_N6_wire", false,-1, 8,0);
        tracep->declBus(c+228,"logicnet layer2_inst layer2_N7_wire", false,-1, 8,0);
        tracep->declBus(c+229,"logicnet layer2_inst layer2_N8_wire", false,-1, 8,0);
        tracep->declBus(c+230,"logicnet layer2_inst layer2_N9_wire", false,-1, 8,0);
        tracep->declBus(c+231,"logicnet layer2_inst layer2_N10_wire", false,-1, 8,0);
        tracep->declBus(c+232,"logicnet layer2_inst layer2_N11_wire", false,-1, 8,0);
        tracep->declBus(c+233,"logicnet layer2_inst layer2_N12_wire", false,-1, 8,0);
        tracep->declBus(c+234,"logicnet layer2_inst layer2_N13_wire", false,-1, 8,0);
        tracep->declBus(c+235,"logicnet layer2_inst layer2_N14_wire", false,-1, 8,0);
        tracep->declBus(c+236,"logicnet layer2_inst layer2_N15_wire", false,-1, 8,0);
        tracep->declBus(c+237,"logicnet layer2_inst layer2_N16_wire", false,-1, 8,0);
        tracep->declBus(c+238,"logicnet layer2_inst layer2_N17_wire", false,-1, 8,0);
        tracep->declBus(c+239,"logicnet layer2_inst layer2_N18_wire", false,-1, 8,0);
        tracep->declBus(c+240,"logicnet layer2_inst layer2_N19_wire", false,-1, 8,0);
        tracep->declBus(c+241,"logicnet layer2_inst layer2_N20_wire", false,-1, 8,0);
        tracep->declBus(c+242,"logicnet layer2_inst layer2_N21_wire", false,-1, 8,0);
        tracep->declBus(c+243,"logicnet layer2_inst layer2_N22_wire", false,-1, 8,0);
        tracep->declBus(c+244,"logicnet layer2_inst layer2_N23_wire", false,-1, 8,0);
        tracep->declBus(c+245,"logicnet layer2_inst layer2_N24_wire", false,-1, 8,0);
        tracep->declBus(c+246,"logicnet layer2_inst layer2_N25_wire", false,-1, 8,0);
        tracep->declBus(c+247,"logicnet layer2_inst layer2_N26_wire", false,-1, 8,0);
        tracep->declBus(c+248,"logicnet layer2_inst layer2_N27_wire", false,-1, 8,0);
        tracep->declBus(c+249,"logicnet layer2_inst layer2_N28_wire", false,-1, 8,0);
        tracep->declBus(c+250,"logicnet layer2_inst layer2_N29_wire", false,-1, 8,0);
        tracep->declBus(c+251,"logicnet layer2_inst layer2_N30_wire", false,-1, 8,0);
        tracep->declBus(c+252,"logicnet layer2_inst layer2_N31_wire", false,-1, 8,0);
        tracep->declBus(c+221,"logicnet layer2_inst layer2_N0_inst M0", false,-1, 8,0);
        tracep->declBus(c+253,"logicnet layer2_inst layer2_N0_inst M1", false,-1, 2,0);
        tracep->declBus(c+253,"logicnet layer2_inst layer2_N0_inst M1r", false,-1, 2,0);
        tracep->declBus(c+222,"logicnet layer2_inst layer2_N1_inst M0", false,-1, 8,0);
        tracep->declBus(c+254,"logicnet layer2_inst layer2_N1_inst M1", false,-1, 2,0);
        tracep->declBus(c+254,"logicnet layer2_inst layer2_N1_inst M1r", false,-1, 2,0);
        tracep->declBus(c+223,"logicnet layer2_inst layer2_N2_inst M0", false,-1, 8,0);
        tracep->declBus(c+255,"logicnet layer2_inst layer2_N2_inst M1", false,-1, 2,0);
        tracep->declBus(c+255,"logicnet layer2_inst layer2_N2_inst M1r", false,-1, 2,0);
        tracep->declBus(c+224,"logicnet layer2_inst layer2_N3_inst M0", false,-1, 8,0);
        tracep->declBus(c+256,"logicnet layer2_inst layer2_N3_inst M1", false,-1, 2,0);
        tracep->declBus(c+256,"logicnet layer2_inst layer2_N3_inst M1r", false,-1, 2,0);
        tracep->declBus(c+225,"logicnet layer2_inst layer2_N4_inst M0", false,-1, 8,0);
        tracep->declBus(c+257,"logicnet layer2_inst layer2_N4_inst M1", false,-1, 2,0);
        tracep->declBus(c+257,"logicnet layer2_inst layer2_N4_inst M1r", false,-1, 2,0);
        tracep->declBus(c+226,"logicnet layer2_inst layer2_N5_inst M0", false,-1, 8,0);
        tracep->declBus(c+258,"logicnet layer2_inst layer2_N5_inst M1", false,-1, 2,0);
        tracep->declBus(c+258,"logicnet layer2_inst layer2_N5_inst M1r", false,-1, 2,0);
        tracep->declBus(c+227,"logicnet layer2_inst layer2_N6_inst M0", false,-1, 8,0);
        tracep->declBus(c+259,"logicnet layer2_inst layer2_N6_inst M1", false,-1, 2,0);
        tracep->declBus(c+259,"logicnet layer2_inst layer2_N6_inst M1r", false,-1, 2,0);
        tracep->declBus(c+228,"logicnet layer2_inst layer2_N7_inst M0", false,-1, 8,0);
        tracep->declBus(c+260,"logicnet layer2_inst layer2_N7_inst M1", false,-1, 2,0);
        tracep->declBus(c+260,"logicnet layer2_inst layer2_N7_inst M1r", false,-1, 2,0);
        tracep->declBus(c+229,"logicnet layer2_inst layer2_N8_inst M0", false,-1, 8,0);
        tracep->declBus(c+261,"logicnet layer2_inst layer2_N8_inst M1", false,-1, 2,0);
        tracep->declBus(c+261,"logicnet layer2_inst layer2_N8_inst M1r", false,-1, 2,0);
        tracep->declBus(c+230,"logicnet layer2_inst layer2_N9_inst M0", false,-1, 8,0);
        tracep->declBus(c+262,"logicnet layer2_inst layer2_N9_inst M1", false,-1, 2,0);
        tracep->declBus(c+262,"logicnet layer2_inst layer2_N9_inst M1r", false,-1, 2,0);
        tracep->declBus(c+231,"logicnet layer2_inst layer2_N10_inst M0", false,-1, 8,0);
        tracep->declBus(c+263,"logicnet layer2_inst layer2_N10_inst M1", false,-1, 2,0);
        tracep->declBus(c+263,"logicnet layer2_inst layer2_N10_inst M1r", false,-1, 2,0);
        tracep->declBus(c+232,"logicnet layer2_inst layer2_N11_inst M0", false,-1, 8,0);
        tracep->declBus(c+264,"logicnet layer2_inst layer2_N11_inst M1", false,-1, 2,0);
        tracep->declBus(c+264,"logicnet layer2_inst layer2_N11_inst M1r", false,-1, 2,0);
        tracep->declBus(c+233,"logicnet layer2_inst layer2_N12_inst M0", false,-1, 8,0);
        tracep->declBus(c+265,"logicnet layer2_inst layer2_N12_inst M1", false,-1, 2,0);
        tracep->declBus(c+265,"logicnet layer2_inst layer2_N12_inst M1r", false,-1, 2,0);
        tracep->declBus(c+234,"logicnet layer2_inst layer2_N13_inst M0", false,-1, 8,0);
        tracep->declBus(c+266,"logicnet layer2_inst layer2_N13_inst M1", false,-1, 2,0);
        tracep->declBus(c+266,"logicnet layer2_inst layer2_N13_inst M1r", false,-1, 2,0);
        tracep->declBus(c+235,"logicnet layer2_inst layer2_N14_inst M0", false,-1, 8,0);
        tracep->declBus(c+267,"logicnet layer2_inst layer2_N14_inst M1", false,-1, 2,0);
        tracep->declBus(c+267,"logicnet layer2_inst layer2_N14_inst M1r", false,-1, 2,0);
        tracep->declBus(c+236,"logicnet layer2_inst layer2_N15_inst M0", false,-1, 8,0);
        tracep->declBus(c+268,"logicnet layer2_inst layer2_N15_inst M1", false,-1, 2,0);
        tracep->declBus(c+268,"logicnet layer2_inst layer2_N15_inst M1r", false,-1, 2,0);
        tracep->declBus(c+237,"logicnet layer2_inst layer2_N16_inst M0", false,-1, 8,0);
        tracep->declBus(c+269,"logicnet layer2_inst layer2_N16_inst M1", false,-1, 2,0);
        tracep->declBus(c+269,"logicnet layer2_inst layer2_N16_inst M1r", false,-1, 2,0);
        tracep->declBus(c+238,"logicnet layer2_inst layer2_N17_inst M0", false,-1, 8,0);
        tracep->declBus(c+270,"logicnet layer2_inst layer2_N17_inst M1", false,-1, 2,0);
        tracep->declBus(c+270,"logicnet layer2_inst layer2_N17_inst M1r", false,-1, 2,0);
        tracep->declBus(c+239,"logicnet layer2_inst layer2_N18_inst M0", false,-1, 8,0);
        tracep->declBus(c+271,"logicnet layer2_inst layer2_N18_inst M1", false,-1, 2,0);
        tracep->declBus(c+271,"logicnet layer2_inst layer2_N18_inst M1r", false,-1, 2,0);
        tracep->declBus(c+240,"logicnet layer2_inst layer2_N19_inst M0", false,-1, 8,0);
        tracep->declBus(c+272,"logicnet layer2_inst layer2_N19_inst M1", false,-1, 2,0);
        tracep->declBus(c+272,"logicnet layer2_inst layer2_N19_inst M1r", false,-1, 2,0);
        tracep->declBus(c+241,"logicnet layer2_inst layer2_N20_inst M0", false,-1, 8,0);
        tracep->declBus(c+273,"logicnet layer2_inst layer2_N20_inst M1", false,-1, 2,0);
        tracep->declBus(c+273,"logicnet layer2_inst layer2_N20_inst M1r", false,-1, 2,0);
        tracep->declBus(c+242,"logicnet layer2_inst layer2_N21_inst M0", false,-1, 8,0);
        tracep->declBus(c+274,"logicnet layer2_inst layer2_N21_inst M1", false,-1, 2,0);
        tracep->declBus(c+274,"logicnet layer2_inst layer2_N21_inst M1r", false,-1, 2,0);
        tracep->declBus(c+243,"logicnet layer2_inst layer2_N22_inst M0", false,-1, 8,0);
        tracep->declBus(c+275,"logicnet layer2_inst layer2_N22_inst M1", false,-1, 2,0);
        tracep->declBus(c+275,"logicnet layer2_inst layer2_N22_inst M1r", false,-1, 2,0);
        tracep->declBus(c+244,"logicnet layer2_inst layer2_N23_inst M0", false,-1, 8,0);
        tracep->declBus(c+276,"logicnet layer2_inst layer2_N23_inst M1", false,-1, 2,0);
        tracep->declBus(c+276,"logicnet layer2_inst layer2_N23_inst M1r", false,-1, 2,0);
        tracep->declBus(c+245,"logicnet layer2_inst layer2_N24_inst M0", false,-1, 8,0);
        tracep->declBus(c+277,"logicnet layer2_inst layer2_N24_inst M1", false,-1, 2,0);
        tracep->declBus(c+277,"logicnet layer2_inst layer2_N24_inst M1r", false,-1, 2,0);
        tracep->declBus(c+246,"logicnet layer2_inst layer2_N25_inst M0", false,-1, 8,0);
        tracep->declBus(c+278,"logicnet layer2_inst layer2_N25_inst M1", false,-1, 2,0);
        tracep->declBus(c+278,"logicnet layer2_inst layer2_N25_inst M1r", false,-1, 2,0);
        tracep->declBus(c+247,"logicnet layer2_inst layer2_N26_inst M0", false,-1, 8,0);
        tracep->declBus(c+279,"logicnet layer2_inst layer2_N26_inst M1", false,-1, 2,0);
        tracep->declBus(c+279,"logicnet layer2_inst layer2_N26_inst M1r", false,-1, 2,0);
        tracep->declBus(c+248,"logicnet layer2_inst layer2_N27_inst M0", false,-1, 8,0);
        tracep->declBus(c+280,"logicnet layer2_inst layer2_N27_inst M1", false,-1, 2,0);
        tracep->declBus(c+280,"logicnet layer2_inst layer2_N27_inst M1r", false,-1, 2,0);
        tracep->declBus(c+249,"logicnet layer2_inst layer2_N28_inst M0", false,-1, 8,0);
        tracep->declBus(c+281,"logicnet layer2_inst layer2_N28_inst M1", false,-1, 2,0);
        tracep->declBus(c+281,"logicnet layer2_inst layer2_N28_inst M1r", false,-1, 2,0);
        tracep->declBus(c+250,"logicnet layer2_inst layer2_N29_inst M0", false,-1, 8,0);
        tracep->declBus(c+282,"logicnet layer2_inst layer2_N29_inst M1", false,-1, 2,0);
        tracep->declBus(c+282,"logicnet layer2_inst layer2_N29_inst M1r", false,-1, 2,0);
        tracep->declBus(c+251,"logicnet layer2_inst layer2_N30_inst M0", false,-1, 8,0);
        tracep->declBus(c+283,"logicnet layer2_inst layer2_N30_inst M1", false,-1, 2,0);
        tracep->declBus(c+283,"logicnet layer2_inst layer2_N30_inst M1r", false,-1, 2,0);
        tracep->declBus(c+252,"logicnet layer2_inst layer2_N31_inst M0", false,-1, 8,0);
        tracep->declBus(c+284,"logicnet layer2_inst layer2_N31_inst M1", false,-1, 2,0);
        tracep->declBus(c+284,"logicnet layer2_inst layer2_N31_inst M1r", false,-1, 2,0);
        tracep->declBus(c+366,"logicnet layer3_reg DataWidth", false,-1, 31,0);
        tracep->declArray(c+21,"logicnet layer3_reg data_in", false,-1, 95,0);
        tracep->declBit(c+361,"logicnet layer3_reg clk", false,-1);
        tracep->declBit(c+362,"logicnet layer3_reg rst", false,-1);
        tracep->declArray(c+24,"logicnet layer3_reg data_out", false,-1, 95,0);
        tracep->declArray(c+24,"logicnet layer3_inst M0", false,-1, 95,0);
        tracep->declArray(c+27,"logicnet layer3_inst M1", false,-1, 95,0);
        tracep->declBus(c+285,"logicnet layer3_inst layer3_N0_wire", false,-1, 8,0);
        tracep->declBus(c+286,"logicnet layer3_inst layer3_N1_wire", false,-1, 8,0);
        tracep->declBus(c+287,"logicnet layer3_inst layer3_N2_wire", false,-1, 8,0);
        tracep->declBus(c+288,"logicnet layer3_inst layer3_N3_wire", false,-1, 8,0);
        tracep->declBus(c+289,"logicnet layer3_inst layer3_N4_wire", false,-1, 8,0);
        tracep->declBus(c+290,"logicnet layer3_inst layer3_N5_wire", false,-1, 8,0);
        tracep->declBus(c+291,"logicnet layer3_inst layer3_N6_wire", false,-1, 8,0);
        tracep->declBus(c+292,"logicnet layer3_inst layer3_N7_wire", false,-1, 8,0);
        tracep->declBus(c+293,"logicnet layer3_inst layer3_N8_wire", false,-1, 8,0);
        tracep->declBus(c+294,"logicnet layer3_inst layer3_N9_wire", false,-1, 8,0);
        tracep->declBus(c+295,"logicnet layer3_inst layer3_N10_wire", false,-1, 8,0);
        tracep->declBus(c+296,"logicnet layer3_inst layer3_N11_wire", false,-1, 8,0);
        tracep->declBus(c+297,"logicnet layer3_inst layer3_N12_wire", false,-1, 8,0);
        tracep->declBus(c+298,"logicnet layer3_inst layer3_N13_wire", false,-1, 8,0);
        tracep->declBus(c+299,"logicnet layer3_inst layer3_N14_wire", false,-1, 8,0);
        tracep->declBus(c+300,"logicnet layer3_inst layer3_N15_wire", false,-1, 8,0);
        tracep->declBus(c+301,"logicnet layer3_inst layer3_N16_wire", false,-1, 8,0);
        tracep->declBus(c+302,"logicnet layer3_inst layer3_N17_wire", false,-1, 8,0);
        tracep->declBus(c+303,"logicnet layer3_inst layer3_N18_wire", false,-1, 8,0);
        tracep->declBus(c+304,"logicnet layer3_inst layer3_N19_wire", false,-1, 8,0);
        tracep->declBus(c+305,"logicnet layer3_inst layer3_N20_wire", false,-1, 8,0);
        tracep->declBus(c+306,"logicnet layer3_inst layer3_N21_wire", false,-1, 8,0);
        tracep->declBus(c+307,"logicnet layer3_inst layer3_N22_wire", false,-1, 8,0);
        tracep->declBus(c+308,"logicnet layer3_inst layer3_N23_wire", false,-1, 8,0);
        tracep->declBus(c+309,"logicnet layer3_inst layer3_N24_wire", false,-1, 8,0);
        tracep->declBus(c+310,"logicnet layer3_inst layer3_N25_wire", false,-1, 8,0);
        tracep->declBus(c+311,"logicnet layer3_inst layer3_N26_wire", false,-1, 8,0);
        tracep->declBus(c+312,"logicnet layer3_inst layer3_N27_wire", false,-1, 8,0);
        tracep->declBus(c+313,"logicnet layer3_inst layer3_N28_wire", false,-1, 8,0);
        tracep->declBus(c+314,"logicnet layer3_inst layer3_N29_wire", false,-1, 8,0);
        tracep->declBus(c+315,"logicnet layer3_inst layer3_N30_wire", false,-1, 8,0);
        tracep->declBus(c+316,"logicnet layer3_inst layer3_N31_wire", false,-1, 8,0);
        tracep->declBus(c+285,"logicnet layer3_inst layer3_N0_inst M0", false,-1, 8,0);
        tracep->declBus(c+317,"logicnet layer3_inst layer3_N0_inst M1", false,-1, 2,0);
        tracep->declBus(c+317,"logicnet layer3_inst layer3_N0_inst M1r", false,-1, 2,0);
        tracep->declBus(c+286,"logicnet layer3_inst layer3_N1_inst M0", false,-1, 8,0);
        tracep->declBus(c+318,"logicnet layer3_inst layer3_N1_inst M1", false,-1, 2,0);
        tracep->declBus(c+318,"logicnet layer3_inst layer3_N1_inst M1r", false,-1, 2,0);
        tracep->declBus(c+287,"logicnet layer3_inst layer3_N2_inst M0", false,-1, 8,0);
        tracep->declBus(c+319,"logicnet layer3_inst layer3_N2_inst M1", false,-1, 2,0);
        tracep->declBus(c+319,"logicnet layer3_inst layer3_N2_inst M1r", false,-1, 2,0);
        tracep->declBus(c+288,"logicnet layer3_inst layer3_N3_inst M0", false,-1, 8,0);
        tracep->declBus(c+320,"logicnet layer3_inst layer3_N3_inst M1", false,-1, 2,0);
        tracep->declBus(c+320,"logicnet layer3_inst layer3_N3_inst M1r", false,-1, 2,0);
        tracep->declBus(c+289,"logicnet layer3_inst layer3_N4_inst M0", false,-1, 8,0);
        tracep->declBus(c+321,"logicnet layer3_inst layer3_N4_inst M1", false,-1, 2,0);
        tracep->declBus(c+321,"logicnet layer3_inst layer3_N4_inst M1r", false,-1, 2,0);
        tracep->declBus(c+290,"logicnet layer3_inst layer3_N5_inst M0", false,-1, 8,0);
        tracep->declBus(c+322,"logicnet layer3_inst layer3_N5_inst M1", false,-1, 2,0);
        tracep->declBus(c+322,"logicnet layer3_inst layer3_N5_inst M1r", false,-1, 2,0);
        tracep->declBus(c+291,"logicnet layer3_inst layer3_N6_inst M0", false,-1, 8,0);
        tracep->declBus(c+323,"logicnet layer3_inst layer3_N6_inst M1", false,-1, 2,0);
        tracep->declBus(c+323,"logicnet layer3_inst layer3_N6_inst M1r", false,-1, 2,0);
        tracep->declBus(c+292,"logicnet layer3_inst layer3_N7_inst M0", false,-1, 8,0);
        tracep->declBus(c+324,"logicnet layer3_inst layer3_N7_inst M1", false,-1, 2,0);
        tracep->declBus(c+324,"logicnet layer3_inst layer3_N7_inst M1r", false,-1, 2,0);
        tracep->declBus(c+293,"logicnet layer3_inst layer3_N8_inst M0", false,-1, 8,0);
        tracep->declBus(c+325,"logicnet layer3_inst layer3_N8_inst M1", false,-1, 2,0);
        tracep->declBus(c+325,"logicnet layer3_inst layer3_N8_inst M1r", false,-1, 2,0);
        tracep->declBus(c+294,"logicnet layer3_inst layer3_N9_inst M0", false,-1, 8,0);
        tracep->declBus(c+326,"logicnet layer3_inst layer3_N9_inst M1", false,-1, 2,0);
        tracep->declBus(c+326,"logicnet layer3_inst layer3_N9_inst M1r", false,-1, 2,0);
        tracep->declBus(c+295,"logicnet layer3_inst layer3_N10_inst M0", false,-1, 8,0);
        tracep->declBus(c+327,"logicnet layer3_inst layer3_N10_inst M1", false,-1, 2,0);
        tracep->declBus(c+327,"logicnet layer3_inst layer3_N10_inst M1r", false,-1, 2,0);
        tracep->declBus(c+296,"logicnet layer3_inst layer3_N11_inst M0", false,-1, 8,0);
        tracep->declBus(c+328,"logicnet layer3_inst layer3_N11_inst M1", false,-1, 2,0);
        tracep->declBus(c+328,"logicnet layer3_inst layer3_N11_inst M1r", false,-1, 2,0);
        tracep->declBus(c+297,"logicnet layer3_inst layer3_N12_inst M0", false,-1, 8,0);
        tracep->declBus(c+329,"logicnet layer3_inst layer3_N12_inst M1", false,-1, 2,0);
        tracep->declBus(c+329,"logicnet layer3_inst layer3_N12_inst M1r", false,-1, 2,0);
        tracep->declBus(c+298,"logicnet layer3_inst layer3_N13_inst M0", false,-1, 8,0);
        tracep->declBus(c+330,"logicnet layer3_inst layer3_N13_inst M1", false,-1, 2,0);
        tracep->declBus(c+330,"logicnet layer3_inst layer3_N13_inst M1r", false,-1, 2,0);
        tracep->declBus(c+299,"logicnet layer3_inst layer3_N14_inst M0", false,-1, 8,0);
        tracep->declBus(c+331,"logicnet layer3_inst layer3_N14_inst M1", false,-1, 2,0);
        tracep->declBus(c+331,"logicnet layer3_inst layer3_N14_inst M1r", false,-1, 2,0);
        tracep->declBus(c+300,"logicnet layer3_inst layer3_N15_inst M0", false,-1, 8,0);
        tracep->declBus(c+332,"logicnet layer3_inst layer3_N15_inst M1", false,-1, 2,0);
        tracep->declBus(c+332,"logicnet layer3_inst layer3_N15_inst M1r", false,-1, 2,0);
        tracep->declBus(c+301,"logicnet layer3_inst layer3_N16_inst M0", false,-1, 8,0);
        tracep->declBus(c+333,"logicnet layer3_inst layer3_N16_inst M1", false,-1, 2,0);
        tracep->declBus(c+333,"logicnet layer3_inst layer3_N16_inst M1r", false,-1, 2,0);
        tracep->declBus(c+302,"logicnet layer3_inst layer3_N17_inst M0", false,-1, 8,0);
        tracep->declBus(c+334,"logicnet layer3_inst layer3_N17_inst M1", false,-1, 2,0);
        tracep->declBus(c+334,"logicnet layer3_inst layer3_N17_inst M1r", false,-1, 2,0);
        tracep->declBus(c+303,"logicnet layer3_inst layer3_N18_inst M0", false,-1, 8,0);
        tracep->declBus(c+335,"logicnet layer3_inst layer3_N18_inst M1", false,-1, 2,0);
        tracep->declBus(c+335,"logicnet layer3_inst layer3_N18_inst M1r", false,-1, 2,0);
        tracep->declBus(c+304,"logicnet layer3_inst layer3_N19_inst M0", false,-1, 8,0);
        tracep->declBus(c+336,"logicnet layer3_inst layer3_N19_inst M1", false,-1, 2,0);
        tracep->declBus(c+336,"logicnet layer3_inst layer3_N19_inst M1r", false,-1, 2,0);
        tracep->declBus(c+305,"logicnet layer3_inst layer3_N20_inst M0", false,-1, 8,0);
        tracep->declBus(c+337,"logicnet layer3_inst layer3_N20_inst M1", false,-1, 2,0);
        tracep->declBus(c+337,"logicnet layer3_inst layer3_N20_inst M1r", false,-1, 2,0);
        tracep->declBus(c+306,"logicnet layer3_inst layer3_N21_inst M0", false,-1, 8,0);
        tracep->declBus(c+338,"logicnet layer3_inst layer3_N21_inst M1", false,-1, 2,0);
        tracep->declBus(c+338,"logicnet layer3_inst layer3_N21_inst M1r", false,-1, 2,0);
        tracep->declBus(c+307,"logicnet layer3_inst layer3_N22_inst M0", false,-1, 8,0);
        tracep->declBus(c+339,"logicnet layer3_inst layer3_N22_inst M1", false,-1, 2,0);
        tracep->declBus(c+339,"logicnet layer3_inst layer3_N22_inst M1r", false,-1, 2,0);
        tracep->declBus(c+308,"logicnet layer3_inst layer3_N23_inst M0", false,-1, 8,0);
        tracep->declBus(c+340,"logicnet layer3_inst layer3_N23_inst M1", false,-1, 2,0);
        tracep->declBus(c+340,"logicnet layer3_inst layer3_N23_inst M1r", false,-1, 2,0);
        tracep->declBus(c+309,"logicnet layer3_inst layer3_N24_inst M0", false,-1, 8,0);
        tracep->declBus(c+341,"logicnet layer3_inst layer3_N24_inst M1", false,-1, 2,0);
        tracep->declBus(c+341,"logicnet layer3_inst layer3_N24_inst M1r", false,-1, 2,0);
        tracep->declBus(c+310,"logicnet layer3_inst layer3_N25_inst M0", false,-1, 8,0);
        tracep->declBus(c+342,"logicnet layer3_inst layer3_N25_inst M1", false,-1, 2,0);
        tracep->declBus(c+342,"logicnet layer3_inst layer3_N25_inst M1r", false,-1, 2,0);
        tracep->declBus(c+311,"logicnet layer3_inst layer3_N26_inst M0", false,-1, 8,0);
        tracep->declBus(c+343,"logicnet layer3_inst layer3_N26_inst M1", false,-1, 2,0);
        tracep->declBus(c+343,"logicnet layer3_inst layer3_N26_inst M1r", false,-1, 2,0);
        tracep->declBus(c+312,"logicnet layer3_inst layer3_N27_inst M0", false,-1, 8,0);
        tracep->declBus(c+344,"logicnet layer3_inst layer3_N27_inst M1", false,-1, 2,0);
        tracep->declBus(c+344,"logicnet layer3_inst layer3_N27_inst M1r", false,-1, 2,0);
        tracep->declBus(c+313,"logicnet layer3_inst layer3_N28_inst M0", false,-1, 8,0);
        tracep->declBus(c+345,"logicnet layer3_inst layer3_N28_inst M1", false,-1, 2,0);
        tracep->declBus(c+345,"logicnet layer3_inst layer3_N28_inst M1r", false,-1, 2,0);
        tracep->declBus(c+314,"logicnet layer3_inst layer3_N29_inst M0", false,-1, 8,0);
        tracep->declBus(c+346,"logicnet layer3_inst layer3_N29_inst M1", false,-1, 2,0);
        tracep->declBus(c+346,"logicnet layer3_inst layer3_N29_inst M1r", false,-1, 2,0);
        tracep->declBus(c+315,"logicnet layer3_inst layer3_N30_inst M0", false,-1, 8,0);
        tracep->declBus(c+347,"logicnet layer3_inst layer3_N30_inst M1", false,-1, 2,0);
        tracep->declBus(c+347,"logicnet layer3_inst layer3_N30_inst M1r", false,-1, 2,0);
        tracep->declBus(c+316,"logicnet layer3_inst layer3_N31_inst M0", false,-1, 8,0);
        tracep->declBus(c+348,"logicnet layer3_inst layer3_N31_inst M1", false,-1, 2,0);
        tracep->declBus(c+348,"logicnet layer3_inst layer3_N31_inst M1r", false,-1, 2,0);
        tracep->declBus(c+366,"logicnet layer4_reg DataWidth", false,-1, 31,0);
        tracep->declArray(c+27,"logicnet layer4_reg data_in", false,-1, 95,0);
        tracep->declBit(c+361,"logicnet layer4_reg clk", false,-1);
        tracep->declBit(c+362,"logicnet layer4_reg rst", false,-1);
        tracep->declArray(c+30,"logicnet layer4_reg data_out", false,-1, 95,0);
        tracep->declArray(c+30,"logicnet layer4_inst M0", false,-1, 95,0);
        tracep->declBus(c+363,"logicnet layer4_inst M1", false,-1, 14,0);
        tracep->declBus(c+349,"logicnet layer4_inst layer4_N0_wire", false,-1, 8,0);
        tracep->declBus(c+350,"logicnet layer4_inst layer4_N1_wire", false,-1, 8,0);
        tracep->declBus(c+351,"logicnet layer4_inst layer4_N2_wire", false,-1, 8,0);
        tracep->declBus(c+352,"logicnet layer4_inst layer4_N3_wire", false,-1, 8,0);
        tracep->declBus(c+353,"logicnet layer4_inst layer4_N4_wire", false,-1, 8,0);
        tracep->declBus(c+349,"logicnet layer4_inst layer4_N0_inst M0", false,-1, 8,0);
        tracep->declBus(c+354,"logicnet layer4_inst layer4_N0_inst M1", false,-1, 2,0);
        tracep->declBus(c+354,"logicnet layer4_inst layer4_N0_inst M1r", false,-1, 2,0);
        tracep->declBus(c+350,"logicnet layer4_inst layer4_N1_inst M0", false,-1, 8,0);
        tracep->declBus(c+355,"logicnet layer4_inst layer4_N1_inst M1", false,-1, 2,0);
        tracep->declBus(c+355,"logicnet layer4_inst layer4_N1_inst M1r", false,-1, 2,0);
        tracep->declBus(c+351,"logicnet layer4_inst layer4_N2_inst M0", false,-1, 8,0);
        tracep->declBus(c+356,"logicnet layer4_inst layer4_N2_inst M1", false,-1, 2,0);
        tracep->declBus(c+356,"logicnet layer4_inst layer4_N2_inst M1r", false,-1, 2,0);
        tracep->declBus(c+352,"logicnet layer4_inst layer4_N3_inst M0", false,-1, 8,0);
        tracep->declBus(c+357,"logicnet layer4_inst layer4_N3_inst M1", false,-1, 2,0);
        tracep->declBus(c+357,"logicnet layer4_inst layer4_N3_inst M1r", false,-1, 2,0);
        tracep->declBus(c+353,"logicnet layer4_inst layer4_N4_inst M0", false,-1, 8,0);
        tracep->declBus(c+358,"logicnet layer4_inst layer4_N4_inst M1", false,-1, 2,0);
        tracep->declBus(c+358,"logicnet layer4_inst layer4_N4_inst M1r", false,-1, 2,0);
    }
}

void Vlogicnet::traceRegister(VerilatedVcd* tracep) {
    // Body
    {
        tracep->addFullCb(&traceFullTop0, __VlSymsp);
        tracep->addChgCb(&traceChgTop0, __VlSymsp);
        tracep->addCleanupCb(&traceCleanup, __VlSymsp);
    }
}

void Vlogicnet::traceFullTop0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlTOPp->traceFullSub0(userp, tracep);
    }
}

void Vlogicnet::traceFullSub0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    vluint32_t* const oldp = tracep->oldp(vlSymsp->__Vm_baseCode);
    if (false && oldp) {}  // Prevent unused
    // Body
    {
        tracep->fullQData(oldp+1,(vlTOPp->logicnet__DOT__M0w),48);
        tracep->fullWData(oldp+3,(vlTOPp->logicnet__DOT__M1),192);
        tracep->fullWData(oldp+9,(vlTOPp->logicnet__DOT__M1w),192);
        tracep->fullWData(oldp+15,(vlTOPp->logicnet__DOT__M2),96);
        tracep->fullWData(oldp+18,(vlTOPp->logicnet__DOT__M2w),96);
        tracep->fullWData(oldp+21,(vlTOPp->logicnet__DOT__M3),96);
        tracep->fullWData(oldp+24,(vlTOPp->logicnet__DOT__M3w),96);
        tracep->fullWData(oldp+27,(vlTOPp->logicnet__DOT__M4),96);
        tracep->fullWData(oldp+30,(vlTOPp->logicnet__DOT__M4w),96);
        tracep->fullSData(oldp+33,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+34,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x11U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x10U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+35,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x17U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x16U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+36,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1bU)))))))),9);
        tracep->fullSData(oldp+37,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x24U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x29U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x28U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x27U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+38,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x11U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x10U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1bU)))))))),9);
        tracep->fullSData(oldp+39,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x20U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1fU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1eU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+40,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xeU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xdU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)))))))),9);
        tracep->fullSData(oldp+41,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x26U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x25U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x24U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+42,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x23U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x22U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+43,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+44,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xeU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xdU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+45,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x17U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x16U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+46,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x14U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x13U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x12U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+47,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x14U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x13U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x12U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x15U)))))))),9);
        tracep->fullSData(oldp+48,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x29U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x28U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x27U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+49,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x23U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x22U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+50,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x21U)))))))),9);
        tracep->fullSData(oldp+51,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xbU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xaU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)))))))),9);
        tracep->fullSData(oldp+52,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x14U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x13U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x12U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x15U)))))))),9);
        tracep->fullSData(oldp+53,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x17U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x16U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+54,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+55,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x12U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1dU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1cU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1bU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1eU)))))))),9);
        tracep->fullSData(oldp+56,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x11U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x10U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+57,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xeU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xdU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+58,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+59,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x23U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x22U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+60,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+61,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x23U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x22U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+62,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x12U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x20U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1fU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1eU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+63,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x20U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1fU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1eU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+64,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 8U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 7U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x21U)))))))),9);
        tracep->fullSData(oldp+65,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x23U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x22U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+66,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xeU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xdU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x21U)))))))),9);
        tracep->fullSData(oldp+67,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1dU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1cU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1bU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+68,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x17U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x16U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+69,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1eU)))))))),9);
        tracep->fullSData(oldp+70,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x2cU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x2bU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x2aU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+71,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x29U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x28U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x27U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+72,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x20U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1fU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1eU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x21U)))))))),9);
        tracep->fullSData(oldp+73,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1dU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1cU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1bU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+74,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 8U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 7U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+75,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1bU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x29U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x28U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x27U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+76,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 5U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 4U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x21U)))))))),9);
        tracep->fullSData(oldp+77,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xeU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xdU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1bU)))))))),9);
        tracep->fullSData(oldp+78,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x19U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x18U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1eU)))))))),9);
        tracep->fullSData(oldp+79,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x26U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x25U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x24U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2dU)))))))),9);
        tracep->fullSData(oldp+80,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x17U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x16U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+81,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 8U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 7U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)))))))),9);
        tracep->fullSData(oldp+82,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 5U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 4U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 3U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+83,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1dU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1cU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1bU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+84,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x12U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x17U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x16U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+85,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x14U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x13U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x12U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+86,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 8U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 7U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+87,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xbU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xaU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1bU)))))))),9);
        tracep->fullSData(oldp+88,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1dU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1cU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1bU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x27U)))))))),9);
        tracep->fullSData(oldp+89,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x20U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1fU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1eU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x2aU)))))))),9);
        tracep->fullSData(oldp+90,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xbU)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xaU)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 9U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x18U)))))))),9);
        tracep->fullSData(oldp+91,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x23U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x22U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)))))))),9);
        tracep->fullSData(oldp+92,(((0x1c0U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                               << 6U)) 
                                    | ((0x20U & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x11U)) 
                                                 << 5U)) 
                                       | ((0x10U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x10U)) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((IData)(
                                                       (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xfU)) 
                                               << 3U)) 
                                             | (7U 
                                                & (IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x15U)))))))),9);
        tracep->fullCData(oldp+93,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r),3);
        tracep->fullCData(oldp+94,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r),3);
        tracep->fullCData(oldp+95,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r),3);
        tracep->fullCData(oldp+96,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r),3);
        tracep->fullCData(oldp+97,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r),3);
        tracep->fullCData(oldp+98,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r),3);
        tracep->fullCData(oldp+99,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r),3);
        tracep->fullCData(oldp+100,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r),3);
        tracep->fullCData(oldp+101,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r),3);
        tracep->fullCData(oldp+102,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r),3);
        tracep->fullCData(oldp+103,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r),3);
        tracep->fullCData(oldp+104,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r),3);
        tracep->fullCData(oldp+105,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r),3);
        tracep->fullCData(oldp+106,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r),3);
        tracep->fullCData(oldp+107,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r),3);
        tracep->fullCData(oldp+108,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r),3);
        tracep->fullCData(oldp+109,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r),3);
        tracep->fullCData(oldp+110,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r),3);
        tracep->fullCData(oldp+111,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r),3);
        tracep->fullCData(oldp+112,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r),3);
        tracep->fullCData(oldp+113,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r),3);
        tracep->fullCData(oldp+114,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r),3);
        tracep->fullCData(oldp+115,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r),3);
        tracep->fullCData(oldp+116,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r),3);
        tracep->fullCData(oldp+117,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r),3);
        tracep->fullCData(oldp+118,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r),3);
        tracep->fullCData(oldp+119,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r),3);
        tracep->fullCData(oldp+120,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r),3);
        tracep->fullCData(oldp+121,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r),3);
        tracep->fullCData(oldp+122,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r),3);
        tracep->fullCData(oldp+123,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r),3);
        tracep->fullCData(oldp+124,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r),3);
        tracep->fullCData(oldp+125,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r),3);
        tracep->fullCData(oldp+126,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r),3);
        tracep->fullCData(oldp+127,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r),3);
        tracep->fullCData(oldp+128,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r),3);
        tracep->fullCData(oldp+129,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r),3);
        tracep->fullCData(oldp+130,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r),3);
        tracep->fullCData(oldp+131,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r),3);
        tracep->fullCData(oldp+132,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r),3);
        tracep->fullCData(oldp+133,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r),3);
        tracep->fullCData(oldp+134,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r),3);
        tracep->fullCData(oldp+135,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r),3);
        tracep->fullCData(oldp+136,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r),3);
        tracep->fullCData(oldp+137,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r),3);
        tracep->fullCData(oldp+138,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r),3);
        tracep->fullCData(oldp+139,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r),3);
        tracep->fullCData(oldp+140,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r),3);
        tracep->fullCData(oldp+141,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r),3);
        tracep->fullCData(oldp+142,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r),3);
        tracep->fullCData(oldp+143,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r),3);
        tracep->fullCData(oldp+144,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r),3);
        tracep->fullCData(oldp+145,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r),3);
        tracep->fullCData(oldp+146,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r),3);
        tracep->fullCData(oldp+147,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r),3);
        tracep->fullCData(oldp+148,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r),3);
        tracep->fullCData(oldp+149,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r),3);
        tracep->fullCData(oldp+150,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r),3);
        tracep->fullCData(oldp+151,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r),3);
        tracep->fullCData(oldp+152,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r),3);
        tracep->fullCData(oldp+153,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r),3);
        tracep->fullCData(oldp+154,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r),3);
        tracep->fullCData(oldp+155,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r),3);
        tracep->fullCData(oldp+156,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r),3);
        tracep->fullSData(oldp+157,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 0x13U) 
                                                | (0x7ffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0xdU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x17U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x17U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 0x1fU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 1U)))))))),9);
        tracep->fullSData(oldp+158,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 7U) 
                                                | (0x40U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0x19U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xeU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xeU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0xeU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 0x1fU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 1U)))))))),9);
        tracep->fullSData(oldp+159,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                 << 0x17U) 
                                                | (0x7fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                      >> 9U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  << 2U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             << 2U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[4U] 
                                                << 2U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+160,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                 << 0x17U) 
                                                | (0x7fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 9U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x1aU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x1aU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                     << 0xeU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                       >> 0x12U)))))))),9);
        tracep->fullSData(oldp+161,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                << 3U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                     << 0x19U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 7U)))))))),9);
        tracep->fullSData(oldp+162,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 0xaU) 
                                                | (0x3c0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0x16U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  << 3U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             << 3U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 3U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+163,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0xfU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0xfU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+164,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0xcU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0xcU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0xcU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+165,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                 << 0xeU) 
                                                | (0x3fc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 0x12U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 6U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 6U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 6U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+166,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 0x1cU) 
                                                | (0xfffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 4U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x17U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x17U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0x17U))))))),9);
        tracep->fullSData(oldp+167,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                 << 0x1bU) 
                                                | (0x7ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      >> 5U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 0x1cU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 4U)))))))),9);
        tracep->fullSData(oldp+168,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 0xaU) 
                                                | (0x3c0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0x16U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 8U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 8U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 8U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                     << 0xbU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                       >> 0x15U)))))))),9);
        tracep->fullSData(oldp+169,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 0xaU) 
                                                | (0x3c0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0x16U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                  >> 0xbU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 0xbU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[5U] 
                                                >> 0xbU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0x17U))))))),9);
        tracep->fullSData(oldp+170,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                 << 0xfU) 
                                                | (0x7fc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      >> 0x11U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 3U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 3U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 3U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 5U))))))),9);
        tracep->fullSData(oldp+171,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                 << 0x12U) 
                                                | (0x3ffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      >> 0xeU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0x16U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x16U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[4U] 
                                                >> 0x16U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0x1aU))))))),9);
        tracep->fullSData(oldp+172,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                 << 0xbU) 
                                                | (0x7c0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 0x15U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 7U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 7U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 7U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0xcU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x14U)))))))),9);
        tracep->fullSData(oldp+173,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 0x10U)))))))),9);
        tracep->fullSData(oldp+174,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                 << 0x1bU) 
                                                | (0x7ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      >> 5U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x1aU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x1aU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 5U))))))),9);
        tracep->fullSData(oldp+175,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                 << 0x1bU) 
                                                | (0x7ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      >> 5U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0xfU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0xfU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 0x10U)))))))),9);
        tracep->fullSData(oldp+176,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                 << 0x17U) 
                                                | (0x7fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 9U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 7U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 7U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 7U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0xcU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x14U)))))))),9);
        tracep->fullSData(oldp+177,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                << 3U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xbU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xbU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0xbU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                     << 0xbU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                       >> 0x15U)))))))),9);
        tracep->fullSData(oldp+178,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 1U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                  >> 0x11U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 0x11U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[5U] 
                                                >> 0x11U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0x17U))))))),9);
        tracep->fullSData(oldp+179,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 5U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  << 4U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             << 4U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x1cU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 2U))))))),9);
        tracep->fullSData(oldp+180,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                 << 0x1fU) 
                                                | (0x7fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                      >> 1U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[4U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+181,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x18U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x18U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0x18U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 0x19U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 7U)))))))),9);
        tracep->fullSData(oldp+182,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                << 6U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                     << 0x1cU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                       >> 4U)))))))),9);
        tracep->fullSData(oldp+183,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                 << 0x17U) 
                                                | (0x7fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 9U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  << 2U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             << 2U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 2U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                     << 0x11U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                       >> 0xfU)))))))),9);
        tracep->fullSData(oldp+184,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 0x1fU) 
                                                | (0x7fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 1U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x12U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x12U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0x12U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+185,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 4U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[4U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 8U))))))),9);
        tracep->fullSData(oldp+186,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                 << 0x1cU) 
                                                | (0xfffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 4U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0xaU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0xaU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[4U] 
                                                >> 0xaU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    >> 0x14U))))))),9);
        tracep->fullSData(oldp+187,(((0x1c0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                << 3U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 9U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 9U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 9U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                     << 2U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                       >> 0x1eU)))))))),9);
        tracep->fullSData(oldp+188,(((0x1c0U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                 << 0x17U) 
                                                | (0x7fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 9U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x12U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0x12U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0x12U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0xcU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x14U)))))))),9);
        tracep->fullCData(oldp+189,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r),3);
        tracep->fullCData(oldp+190,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r),3);
        tracep->fullCData(oldp+191,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r),3);
        tracep->fullCData(oldp+192,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r),3);
        tracep->fullCData(oldp+193,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r),3);
        tracep->fullCData(oldp+194,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r),3);
        tracep->fullCData(oldp+195,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r),3);
        tracep->fullCData(oldp+196,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r),3);
        tracep->fullCData(oldp+197,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r),3);
        tracep->fullCData(oldp+198,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r),3);
        tracep->fullCData(oldp+199,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r),3);
        tracep->fullCData(oldp+200,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r),3);
        tracep->fullCData(oldp+201,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r),3);
        tracep->fullCData(oldp+202,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r),3);
        tracep->fullCData(oldp+203,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r),3);
        tracep->fullCData(oldp+204,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r),3);
        tracep->fullCData(oldp+205,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r),3);
        tracep->fullCData(oldp+206,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r),3);
        tracep->fullCData(oldp+207,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r),3);
        tracep->fullCData(oldp+208,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r),3);
        tracep->fullCData(oldp+209,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r),3);
        tracep->fullCData(oldp+210,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r),3);
        tracep->fullCData(oldp+211,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r),3);
        tracep->fullCData(oldp+212,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r),3);
        tracep->fullCData(oldp+213,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r),3);
        tracep->fullCData(oldp+214,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r),3);
        tracep->fullCData(oldp+215,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r),3);
        tracep->fullCData(oldp+216,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r),3);
        tracep->fullCData(oldp+217,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r),3);
        tracep->fullCData(oldp+218,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r),3);
        tracep->fullCData(oldp+219,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r),3);
        tracep->fullCData(oldp+220,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r),3);
        tracep->fullSData(oldp+221,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0xdU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0xdU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0xdU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                     << 0xaU) 
                                                    | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                       >> 0x16U)))))))),9);
        tracep->fullSData(oldp+222,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x1cU) 
                                                | (0xfffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                      >> 4U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  << 4U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             << 4U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x1cU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+223,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 0xbU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0xbU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0xbU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+224,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 0x11U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0x11U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x11U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x17U))))))),9);
        tracep->fullSData(oldp+225,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 9U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 9U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 9U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                     << 7U) 
                                                    | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                       >> 0x19U)))))))),9);
        tracep->fullSData(oldp+226,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0xbU) 
                                                | (0x7c0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0x15U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 7U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 7U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 7U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                       >> 0x10U)))))))),9);
        tracep->fullSData(oldp+227,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x17U) 
                                                | (0x7fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 9U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x12U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x12U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0x12U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                     << 0x16U) 
                                                    | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                       >> 0xaU)))))))),9);
        tracep->fullSData(oldp+228,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0xbU) 
                                                | (0x7c0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0x15U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  << 5U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x1bU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0x1bU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+229,(((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  << 2U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             << 2U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                << 2U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+230,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x16U) 
                                                | (0x3fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                      >> 0xaU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x13U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x13U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x13U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+231,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0xeU) 
                                                | (0x3fc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0x12U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x18U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x18U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0x18U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 2U))))))),9);
        tracep->fullSData(oldp+232,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 2U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 2U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 2U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x11U))))))),9);
        tracep->fullSData(oldp+233,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0xeU)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 0x14U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0x14U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[2U] 
                                                >> 0x14U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x1aU))))))),9);
        tracep->fullSData(oldp+234,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x11U) 
                                                | (0x1ffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0xfU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 7U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 7U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 7U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                     << 0x13U) 
                                                    | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                       >> 0xdU)))))))),9);
        tracep->fullSData(oldp+235,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  << 4U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             << 4U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x1cU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+236,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0xeU) 
                                                | (0x3fc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0x12U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 7U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 7U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 7U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+237,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 9U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 9U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 9U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 5U))))))),9);
        tracep->fullSData(oldp+238,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                << 6U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x14U))))))),9);
        tracep->fullSData(oldp+239,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                << 5U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x13U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x13U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x13U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 5U))))))),9);
        tracep->fullSData(oldp+240,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x11U) 
                                                | (0x1ffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0xfU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                     << 0x1fU) 
                                                    | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                       >> 1U)))))))),9);
        tracep->fullSData(oldp+241,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                << 3U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  << 5U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x1bU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0x1bU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x11U))))))),9);
        tracep->fullSData(oldp+242,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x13U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x13U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x13U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x1aU))))))),9);
        tracep->fullSData(oldp+243,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                << 5U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 2U))))))),9);
        tracep->fullSData(oldp+244,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                << 3U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 9U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 9U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 9U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                     << 2U) 
                                                    | (vlTOPp->logicnet__DOT__M2w[0U] 
                                                       >> 0x1eU)))))))),9);
        tracep->fullSData(oldp+245,(((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0xfU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0xfU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0xfU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x1aU))))))),9);
        tracep->fullSData(oldp+246,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0xcU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0xcU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0xcU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x11U))))))),9);
        tracep->fullSData(oldp+247,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  << 4U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             << 4U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x1cU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+248,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 8U) 
                                                | (0xc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 0x18U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+249,(((0x1c0U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 2U))))))),9);
        tracep->fullSData(oldp+250,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 4U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 4U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 4U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 8U))))))),9);
        tracep->fullSData(oldp+251,(((0x1c0U & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                 << 0x1fU) 
                                                | (0x7fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                      >> 1U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0xdU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0xdU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[1U] 
                                                >> 0xdU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    >> 0x1aU))))))),9);
        tracep->fullSData(oldp+252,(((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0xcU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0xcU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M2w[0U] 
                                                >> 0xcU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                     << 0x16U) 
                                                    | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                       >> 0xaU)))))))),9);
        tracep->fullCData(oldp+253,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r),3);
        tracep->fullCData(oldp+254,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r),3);
        tracep->fullCData(oldp+255,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r),3);
        tracep->fullCData(oldp+256,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r),3);
        tracep->fullCData(oldp+257,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r),3);
        tracep->fullCData(oldp+258,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r),3);
        tracep->fullCData(oldp+259,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r),3);
        tracep->fullCData(oldp+260,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r),3);
        tracep->fullCData(oldp+261,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r),3);
        tracep->fullCData(oldp+262,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r),3);
        tracep->fullCData(oldp+263,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r),3);
        tracep->fullCData(oldp+264,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r),3);
        tracep->fullCData(oldp+265,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r),3);
        tracep->fullCData(oldp+266,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r),3);
        tracep->fullCData(oldp+267,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r),3);
        tracep->fullCData(oldp+268,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r),3);
        tracep->fullCData(oldp+269,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r),3);
        tracep->fullCData(oldp+270,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r),3);
        tracep->fullCData(oldp+271,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r),3);
        tracep->fullCData(oldp+272,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r),3);
        tracep->fullCData(oldp+273,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r),3);
        tracep->fullCData(oldp+274,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r),3);
        tracep->fullCData(oldp+275,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r),3);
        tracep->fullCData(oldp+276,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r),3);
        tracep->fullCData(oldp+277,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r),3);
        tracep->fullCData(oldp+278,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r),3);
        tracep->fullCData(oldp+279,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r),3);
        tracep->fullCData(oldp+280,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r),3);
        tracep->fullCData(oldp+281,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r),3);
        tracep->fullCData(oldp+282,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r),3);
        tracep->fullCData(oldp+283,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r),3);
        tracep->fullCData(oldp+284,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r),3);
        tracep->fullSData(oldp+285,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x11U) 
                                                | (0x1ffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0xfU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 7U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 7U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 7U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+286,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xaU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0xbU))))))),9);
        tracep->fullSData(oldp+287,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 8U) 
                                                | (0xc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0x18U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xdU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 7U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x19U)))))))),9);
        tracep->fullSData(oldp+288,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 0x1cU) 
                                                | (0xfffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                      >> 4U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+289,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0xbU) 
                                                | (0x7c0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0x15U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  >> 0xeU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             >> 0xeU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0xeU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x14U))))))),9);
        tracep->fullSData(oldp+290,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x16U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x16U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0x16U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+291,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  << 5U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x1bU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x1bU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 0x1fU) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 1U)))))))),9);
        tracep->fullSData(oldp+292,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x18U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x18U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x18U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+293,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+294,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 8U))))))),9);
        tracep->fullSData(oldp+295,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 0x1cU) 
                                                | (0xfffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                      >> 4U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xdU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+296,(((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0xeU))))))),9);
        tracep->fullSData(oldp+297,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0xcU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0xcU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0xcU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+298,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x18U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x18U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x18U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 0x1fU) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 1U)))))))),9);
        tracep->fullSData(oldp+299,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0xbU) 
                                                | (0x7c0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0x15U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x11U))))))),9);
        tracep->fullSData(oldp+300,(((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 7U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 7U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 7U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+301,(((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                << 5U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x16U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x16U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0x16U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x14U))))))),9);
        tracep->fullSData(oldp+302,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x17U) 
                                                | (0x7fffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 9U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x18U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x18U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x18U)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 7U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x19U)))))))),9);
        tracep->fullSData(oldp+303,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  >> 8U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             >> 8U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 8U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0xeU))))))),9);
        tracep->fullSData(oldp+304,(((0x1c0U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  >> 0x11U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             >> 0x11U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[2U] 
                                                >> 0x11U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x17U))))))),9);
        tracep->fullSData(oldp+305,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xaU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 0xaU) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x16U)))))))),9);
        tracep->fullSData(oldp+306,(((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                << 2U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xdU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 8U))))))),9);
        tracep->fullSData(oldp+307,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xaU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+308,(((0x1c0U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                << 3U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  << 5U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x1bU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x1bU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 0x16U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0xaU)))))))),9);
        tracep->fullSData(oldp+309,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0xeU) 
                                                | (0x3fc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0x12U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  << 4U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             << 4U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0x1cU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x11U))))))),9);
        tracep->fullSData(oldp+310,(((0x1c0U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                << 3U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x12U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x12U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x12U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 5U))))))),9);
        tracep->fullSData(oldp+311,(((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x1aU))))))),9);
        tracep->fullSData(oldp+312,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x1dU) 
                                                | (0x1fffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 3U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xdU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 4U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0x1cU)))))))),9);
        tracep->fullSData(oldp+313,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                 << 0x1cU) 
                                                | (0xfffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                      >> 4U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[1U] 
                                                >> 0xaU)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 0x14U))))))),9);
        tracep->fullSData(oldp+314,(((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0xfU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0xfU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0xfU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 0x13U) 
                                                    | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                       >> 0xdU)))))))),9);
        tracep->fullSData(oldp+315,(((0x1c0U & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                << 5U)) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  << 1U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             << 1U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[2U] 
                                                << 1U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 8U))))))),9);
        tracep->fullSData(oldp+316,(((0x1c0U & ((vlTOPp->logicnet__DOT__M3w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M3w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    >> 8U))))))),9);
        tracep->fullCData(oldp+317,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r),3);
        tracep->fullCData(oldp+318,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r),3);
        tracep->fullCData(oldp+319,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r),3);
        tracep->fullCData(oldp+320,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r),3);
        tracep->fullCData(oldp+321,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r),3);
        tracep->fullCData(oldp+322,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r),3);
        tracep->fullCData(oldp+323,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r),3);
        tracep->fullCData(oldp+324,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r),3);
        tracep->fullCData(oldp+325,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r),3);
        tracep->fullCData(oldp+326,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r),3);
        tracep->fullCData(oldp+327,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r),3);
        tracep->fullCData(oldp+328,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r),3);
        tracep->fullCData(oldp+329,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r),3);
        tracep->fullCData(oldp+330,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r),3);
        tracep->fullCData(oldp+331,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r),3);
        tracep->fullCData(oldp+332,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r),3);
        tracep->fullCData(oldp+333,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r),3);
        tracep->fullCData(oldp+334,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r),3);
        tracep->fullCData(oldp+335,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r),3);
        tracep->fullCData(oldp+336,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r),3);
        tracep->fullCData(oldp+337,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r),3);
        tracep->fullCData(oldp+338,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r),3);
        tracep->fullCData(oldp+339,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r),3);
        tracep->fullCData(oldp+340,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r),3);
        tracep->fullCData(oldp+341,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r),3);
        tracep->fullCData(oldp+342,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r),3);
        tracep->fullCData(oldp+343,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r),3);
        tracep->fullCData(oldp+344,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r),3);
        tracep->fullCData(oldp+345,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r),3);
        tracep->fullCData(oldp+346,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r),3);
        tracep->fullCData(oldp+347,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r),3);
        tracep->fullCData(oldp+348,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r),3);
        tracep->fullSData(oldp+349,(((0x1c0U & vlTOPp->logicnet__DOT__M4w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                  >> 0xfU)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M4w[0U] 
                                             >> 0xfU)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M4w[0U] 
                                                >> 0xfU)) 
                                              | (7U 
                                                 & ((vlTOPp->logicnet__DOT__M4w[2U] 
                                                     << 0xaU) 
                                                    | (vlTOPp->logicnet__DOT__M4w[1U] 
                                                       >> 0x16U)))))))),9);
        tracep->fullSData(oldp+350,(((0x1c0U & vlTOPp->logicnet__DOT__M4w[0U]) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M4w[1U] 
                                                  >> 0x19U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M4w[1U] 
                                             >> 0x19U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M4w[1U] 
                                                >> 0x19U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+351,(((0x1c0U & ((vlTOPp->logicnet__DOT__M4w[1U] 
                                                 << 0x14U) 
                                                | (0xfffc0U 
                                                   & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                      >> 0xcU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                  << 1U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M4w[2U] 
                                             << 1U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M4w[2U] 
                                                << 1U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                    >> 0x17U))))))),9);
        tracep->fullSData(oldp+352,(((0x1c0U & ((vlTOPp->logicnet__DOT__M4w[1U] 
                                                 << 0x1aU) 
                                                | (0x3ffffc0U 
                                                   & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                      >> 6U)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M4w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M4w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullSData(oldp+353,(((0x1c0U & ((vlTOPp->logicnet__DOT__M4w[1U] 
                                                 << 0x11U) 
                                                | (0x1ffc0U 
                                                   & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                      >> 0xfU)))) 
                                     | ((0x20U & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                  >> 0x15U)) 
                                        | ((0x10U & 
                                            (vlTOPp->logicnet__DOT__M4w[0U] 
                                             >> 0x15U)) 
                                           | ((8U & 
                                               (vlTOPp->logicnet__DOT__M4w[0U] 
                                                >> 0x15U)) 
                                              | (7U 
                                                 & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                    >> 0x1dU))))))),9);
        tracep->fullCData(oldp+354,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r),3);
        tracep->fullCData(oldp+355,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r),3);
        tracep->fullCData(oldp+356,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r),3);
        tracep->fullCData(oldp+357,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r),3);
        tracep->fullCData(oldp+358,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r),3);
        tracep->fullQData(oldp+359,(vlTOPp->M0),48);
        tracep->fullBit(oldp+361,(vlTOPp->clk));
        tracep->fullBit(oldp+362,(vlTOPp->rst));
        tracep->fullSData(oldp+363,(vlTOPp->M5),15);
        tracep->fullIData(oldp+364,(0x30U),32);
        tracep->fullIData(oldp+365,(0xc0U),32);
        tracep->fullIData(oldp+366,(0x60U),32);
    }
}
