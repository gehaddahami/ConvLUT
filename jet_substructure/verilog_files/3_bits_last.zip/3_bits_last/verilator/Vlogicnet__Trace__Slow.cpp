// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vlogicnet__Syms.h"


//======================

void Vlogicnet::trace(VerilatedVcdC* tfp, int, int) {
    tfp->spTrace()->addInitCb(&traceInit, __VlSymsp);
    traceRegister(tfp->spTrace());
}

void Vlogicnet::traceInit(void* userp, VerilatedVcd* tracep, uint32_t code) {
    // Callback from tracep->open()
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    if (!Verilated::calcUnusedSigs()) {
        VL_FATAL_MT(__FILE__, __LINE__, __FILE__,
                        "Turning on wave traces requires Verilated::traceEverOn(true) call before time 0.");
    }
    vlSymsp->__Vm_baseCode = code;
    tracep->module(vlSymsp->name());
    tracep->scopeEscape(' ');
    Vlogicnet::traceInitTop(vlSymsp, tracep);
    tracep->scopeEscape('.');
}

//======================


void Vlogicnet::traceInitTop(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlTOPp->traceInitSub0(userp, tracep);
    }
}

void Vlogicnet::traceInitSub0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    const int c = vlSymsp->__Vm_baseCode;
    if (false && tracep && c) {}  // Prevent unused
    // Body
    {
        tracep->declBus(c+348,"M0", false,-1, 31,0);
        tracep->declBit(c+349,"clk", false,-1);
        tracep->declBit(c+350,"rst", false,-1);
        tracep->declBus(c+351,"M5", false,-1, 14,0);
        tracep->declBus(c+348,"logicnet M0", false,-1, 31,0);
        tracep->declBit(c+349,"logicnet clk", false,-1);
        tracep->declBit(c+350,"logicnet rst", false,-1);
        tracep->declBus(c+351,"logicnet M5", false,-1, 14,0);
        tracep->declBus(c+1,"logicnet M0w", false,-1, 31,0);
        tracep->declArray(c+2,"logicnet M1", false,-1, 127,0);
        tracep->declArray(c+6,"logicnet M1w", false,-1, 127,0);
        tracep->declQuad(c+10,"logicnet M2", false,-1, 63,0);
        tracep->declQuad(c+12,"logicnet M2w", false,-1, 63,0);
        tracep->declQuad(c+14,"logicnet M3", false,-1, 63,0);
        tracep->declQuad(c+16,"logicnet M3w", false,-1, 63,0);
        tracep->declQuad(c+18,"logicnet M4", false,-1, 63,0);
        tracep->declQuad(c+20,"logicnet M4w", false,-1, 63,0);
        tracep->declBus(c+352,"logicnet layer0_reg DataWidth", false,-1, 31,0);
        tracep->declBus(c+348,"logicnet layer0_reg data_in", false,-1, 31,0);
        tracep->declBit(c+349,"logicnet layer0_reg clk", false,-1);
        tracep->declBit(c+350,"logicnet layer0_reg rst", false,-1);
        tracep->declBus(c+1,"logicnet layer0_reg data_out", false,-1, 31,0);
        tracep->declBus(c+1,"logicnet layer0_inst M0", false,-1, 31,0);
        tracep->declArray(c+2,"logicnet layer0_inst M1", false,-1, 127,0);
        tracep->declBus(c+22,"logicnet layer0_inst layer0_N0_wire", false,-1, 5,0);
        tracep->declBus(c+23,"logicnet layer0_inst layer0_N1_wire", false,-1, 5,0);
        tracep->declBus(c+24,"logicnet layer0_inst layer0_N2_wire", false,-1, 5,0);
        tracep->declBus(c+25,"logicnet layer0_inst layer0_N3_wire", false,-1, 5,0);
        tracep->declBus(c+26,"logicnet layer0_inst layer0_N4_wire", false,-1, 5,0);
        tracep->declBus(c+27,"logicnet layer0_inst layer0_N5_wire", false,-1, 5,0);
        tracep->declBus(c+28,"logicnet layer0_inst layer0_N6_wire", false,-1, 5,0);
        tracep->declBus(c+29,"logicnet layer0_inst layer0_N7_wire", false,-1, 5,0);
        tracep->declBus(c+30,"logicnet layer0_inst layer0_N8_wire", false,-1, 5,0);
        tracep->declBus(c+31,"logicnet layer0_inst layer0_N9_wire", false,-1, 5,0);
        tracep->declBus(c+32,"logicnet layer0_inst layer0_N10_wire", false,-1, 5,0);
        tracep->declBus(c+33,"logicnet layer0_inst layer0_N11_wire", false,-1, 5,0);
        tracep->declBus(c+34,"logicnet layer0_inst layer0_N12_wire", false,-1, 5,0);
        tracep->declBus(c+35,"logicnet layer0_inst layer0_N13_wire", false,-1, 5,0);
        tracep->declBus(c+36,"logicnet layer0_inst layer0_N14_wire", false,-1, 5,0);
        tracep->declBus(c+37,"logicnet layer0_inst layer0_N15_wire", false,-1, 5,0);
        tracep->declBus(c+38,"logicnet layer0_inst layer0_N16_wire", false,-1, 5,0);
        tracep->declBus(c+39,"logicnet layer0_inst layer0_N17_wire", false,-1, 5,0);
        tracep->declBus(c+40,"logicnet layer0_inst layer0_N18_wire", false,-1, 5,0);
        tracep->declBus(c+41,"logicnet layer0_inst layer0_N19_wire", false,-1, 5,0);
        tracep->declBus(c+42,"logicnet layer0_inst layer0_N20_wire", false,-1, 5,0);
        tracep->declBus(c+43,"logicnet layer0_inst layer0_N21_wire", false,-1, 5,0);
        tracep->declBus(c+44,"logicnet layer0_inst layer0_N22_wire", false,-1, 5,0);
        tracep->declBus(c+45,"logicnet layer0_inst layer0_N23_wire", false,-1, 5,0);
        tracep->declBus(c+46,"logicnet layer0_inst layer0_N24_wire", false,-1, 5,0);
        tracep->declBus(c+47,"logicnet layer0_inst layer0_N25_wire", false,-1, 5,0);
        tracep->declBus(c+48,"logicnet layer0_inst layer0_N26_wire", false,-1, 5,0);
        tracep->declBus(c+49,"logicnet layer0_inst layer0_N27_wire", false,-1, 5,0);
        tracep->declBus(c+50,"logicnet layer0_inst layer0_N28_wire", false,-1, 5,0);
        tracep->declBus(c+51,"logicnet layer0_inst layer0_N29_wire", false,-1, 5,0);
        tracep->declBus(c+52,"logicnet layer0_inst layer0_N30_wire", false,-1, 5,0);
        tracep->declBus(c+53,"logicnet layer0_inst layer0_N31_wire", false,-1, 5,0);
        tracep->declBus(c+54,"logicnet layer0_inst layer0_N32_wire", false,-1, 5,0);
        tracep->declBus(c+55,"logicnet layer0_inst layer0_N33_wire", false,-1, 5,0);
        tracep->declBus(c+56,"logicnet layer0_inst layer0_N34_wire", false,-1, 5,0);
        tracep->declBus(c+57,"logicnet layer0_inst layer0_N35_wire", false,-1, 5,0);
        tracep->declBus(c+58,"logicnet layer0_inst layer0_N36_wire", false,-1, 5,0);
        tracep->declBus(c+59,"logicnet layer0_inst layer0_N37_wire", false,-1, 5,0);
        tracep->declBus(c+60,"logicnet layer0_inst layer0_N38_wire", false,-1, 5,0);
        tracep->declBus(c+61,"logicnet layer0_inst layer0_N39_wire", false,-1, 5,0);
        tracep->declBus(c+62,"logicnet layer0_inst layer0_N40_wire", false,-1, 5,0);
        tracep->declBus(c+63,"logicnet layer0_inst layer0_N41_wire", false,-1, 5,0);
        tracep->declBus(c+64,"logicnet layer0_inst layer0_N42_wire", false,-1, 5,0);
        tracep->declBus(c+56,"logicnet layer0_inst layer0_N43_wire", false,-1, 5,0);
        tracep->declBus(c+65,"logicnet layer0_inst layer0_N44_wire", false,-1, 5,0);
        tracep->declBus(c+65,"logicnet layer0_inst layer0_N45_wire", false,-1, 5,0);
        tracep->declBus(c+66,"logicnet layer0_inst layer0_N46_wire", false,-1, 5,0);
        tracep->declBus(c+67,"logicnet layer0_inst layer0_N47_wire", false,-1, 5,0);
        tracep->declBus(c+68,"logicnet layer0_inst layer0_N48_wire", false,-1, 5,0);
        tracep->declBus(c+69,"logicnet layer0_inst layer0_N49_wire", false,-1, 5,0);
        tracep->declBus(c+70,"logicnet layer0_inst layer0_N50_wire", false,-1, 5,0);
        tracep->declBus(c+71,"logicnet layer0_inst layer0_N51_wire", false,-1, 5,0);
        tracep->declBus(c+72,"logicnet layer0_inst layer0_N52_wire", false,-1, 5,0);
        tracep->declBus(c+73,"logicnet layer0_inst layer0_N53_wire", false,-1, 5,0);
        tracep->declBus(c+74,"logicnet layer0_inst layer0_N54_wire", false,-1, 5,0);
        tracep->declBus(c+75,"logicnet layer0_inst layer0_N55_wire", false,-1, 5,0);
        tracep->declBus(c+76,"logicnet layer0_inst layer0_N56_wire", false,-1, 5,0);
        tracep->declBus(c+77,"logicnet layer0_inst layer0_N57_wire", false,-1, 5,0);
        tracep->declBus(c+78,"logicnet layer0_inst layer0_N58_wire", false,-1, 5,0);
        tracep->declBus(c+79,"logicnet layer0_inst layer0_N59_wire", false,-1, 5,0);
        tracep->declBus(c+25,"logicnet layer0_inst layer0_N60_wire", false,-1, 5,0);
        tracep->declBus(c+80,"logicnet layer0_inst layer0_N61_wire", false,-1, 5,0);
        tracep->declBus(c+81,"logicnet layer0_inst layer0_N62_wire", false,-1, 5,0);
        tracep->declBus(c+22,"logicnet layer0_inst layer0_N63_wire", false,-1, 5,0);
        tracep->declBus(c+22,"logicnet layer0_inst layer0_N0_inst M0", false,-1, 5,0);
        tracep->declBus(c+82,"logicnet layer0_inst layer0_N0_inst M1", false,-1, 1,0);
        tracep->declBus(c+82,"logicnet layer0_inst layer0_N0_inst M1r", false,-1, 1,0);
        tracep->declBus(c+23,"logicnet layer0_inst layer0_N1_inst M0", false,-1, 5,0);
        tracep->declBus(c+83,"logicnet layer0_inst layer0_N1_inst M1", false,-1, 1,0);
        tracep->declBus(c+83,"logicnet layer0_inst layer0_N1_inst M1r", false,-1, 1,0);
        tracep->declBus(c+24,"logicnet layer0_inst layer0_N2_inst M0", false,-1, 5,0);
        tracep->declBus(c+84,"logicnet layer0_inst layer0_N2_inst M1", false,-1, 1,0);
        tracep->declBus(c+84,"logicnet layer0_inst layer0_N2_inst M1r", false,-1, 1,0);
        tracep->declBus(c+25,"logicnet layer0_inst layer0_N3_inst M0", false,-1, 5,0);
        tracep->declBus(c+85,"logicnet layer0_inst layer0_N3_inst M1", false,-1, 1,0);
        tracep->declBus(c+85,"logicnet layer0_inst layer0_N3_inst M1r", false,-1, 1,0);
        tracep->declBus(c+26,"logicnet layer0_inst layer0_N4_inst M0", false,-1, 5,0);
        tracep->declBus(c+86,"logicnet layer0_inst layer0_N4_inst M1", false,-1, 1,0);
        tracep->declBus(c+86,"logicnet layer0_inst layer0_N4_inst M1r", false,-1, 1,0);
        tracep->declBus(c+27,"logicnet layer0_inst layer0_N5_inst M0", false,-1, 5,0);
        tracep->declBus(c+87,"logicnet layer0_inst layer0_N5_inst M1", false,-1, 1,0);
        tracep->declBus(c+87,"logicnet layer0_inst layer0_N5_inst M1r", false,-1, 1,0);
        tracep->declBus(c+28,"logicnet layer0_inst layer0_N6_inst M0", false,-1, 5,0);
        tracep->declBus(c+88,"logicnet layer0_inst layer0_N6_inst M1", false,-1, 1,0);
        tracep->declBus(c+88,"logicnet layer0_inst layer0_N6_inst M1r", false,-1, 1,0);
        tracep->declBus(c+29,"logicnet layer0_inst layer0_N7_inst M0", false,-1, 5,0);
        tracep->declBus(c+89,"logicnet layer0_inst layer0_N7_inst M1", false,-1, 1,0);
        tracep->declBus(c+89,"logicnet layer0_inst layer0_N7_inst M1r", false,-1, 1,0);
        tracep->declBus(c+30,"logicnet layer0_inst layer0_N8_inst M0", false,-1, 5,0);
        tracep->declBus(c+90,"logicnet layer0_inst layer0_N8_inst M1", false,-1, 1,0);
        tracep->declBus(c+90,"logicnet layer0_inst layer0_N8_inst M1r", false,-1, 1,0);
        tracep->declBus(c+31,"logicnet layer0_inst layer0_N9_inst M0", false,-1, 5,0);
        tracep->declBus(c+91,"logicnet layer0_inst layer0_N9_inst M1", false,-1, 1,0);
        tracep->declBus(c+91,"logicnet layer0_inst layer0_N9_inst M1r", false,-1, 1,0);
        tracep->declBus(c+32,"logicnet layer0_inst layer0_N10_inst M0", false,-1, 5,0);
        tracep->declBus(c+92,"logicnet layer0_inst layer0_N10_inst M1", false,-1, 1,0);
        tracep->declBus(c+92,"logicnet layer0_inst layer0_N10_inst M1r", false,-1, 1,0);
        tracep->declBus(c+33,"logicnet layer0_inst layer0_N11_inst M0", false,-1, 5,0);
        tracep->declBus(c+93,"logicnet layer0_inst layer0_N11_inst M1", false,-1, 1,0);
        tracep->declBus(c+93,"logicnet layer0_inst layer0_N11_inst M1r", false,-1, 1,0);
        tracep->declBus(c+34,"logicnet layer0_inst layer0_N12_inst M0", false,-1, 5,0);
        tracep->declBus(c+94,"logicnet layer0_inst layer0_N12_inst M1", false,-1, 1,0);
        tracep->declBus(c+94,"logicnet layer0_inst layer0_N12_inst M1r", false,-1, 1,0);
        tracep->declBus(c+35,"logicnet layer0_inst layer0_N13_inst M0", false,-1, 5,0);
        tracep->declBus(c+95,"logicnet layer0_inst layer0_N13_inst M1", false,-1, 1,0);
        tracep->declBus(c+95,"logicnet layer0_inst layer0_N13_inst M1r", false,-1, 1,0);
        tracep->declBus(c+36,"logicnet layer0_inst layer0_N14_inst M0", false,-1, 5,0);
        tracep->declBus(c+96,"logicnet layer0_inst layer0_N14_inst M1", false,-1, 1,0);
        tracep->declBus(c+96,"logicnet layer0_inst layer0_N14_inst M1r", false,-1, 1,0);
        tracep->declBus(c+37,"logicnet layer0_inst layer0_N15_inst M0", false,-1, 5,0);
        tracep->declBus(c+97,"logicnet layer0_inst layer0_N15_inst M1", false,-1, 1,0);
        tracep->declBus(c+97,"logicnet layer0_inst layer0_N15_inst M1r", false,-1, 1,0);
        tracep->declBus(c+38,"logicnet layer0_inst layer0_N16_inst M0", false,-1, 5,0);
        tracep->declBus(c+98,"logicnet layer0_inst layer0_N16_inst M1", false,-1, 1,0);
        tracep->declBus(c+98,"logicnet layer0_inst layer0_N16_inst M1r", false,-1, 1,0);
        tracep->declBus(c+39,"logicnet layer0_inst layer0_N17_inst M0", false,-1, 5,0);
        tracep->declBus(c+99,"logicnet layer0_inst layer0_N17_inst M1", false,-1, 1,0);
        tracep->declBus(c+99,"logicnet layer0_inst layer0_N17_inst M1r", false,-1, 1,0);
        tracep->declBus(c+40,"logicnet layer0_inst layer0_N18_inst M0", false,-1, 5,0);
        tracep->declBus(c+100,"logicnet layer0_inst layer0_N18_inst M1", false,-1, 1,0);
        tracep->declBus(c+100,"logicnet layer0_inst layer0_N18_inst M1r", false,-1, 1,0);
        tracep->declBus(c+41,"logicnet layer0_inst layer0_N19_inst M0", false,-1, 5,0);
        tracep->declBus(c+101,"logicnet layer0_inst layer0_N19_inst M1", false,-1, 1,0);
        tracep->declBus(c+101,"logicnet layer0_inst layer0_N19_inst M1r", false,-1, 1,0);
        tracep->declBus(c+42,"logicnet layer0_inst layer0_N20_inst M0", false,-1, 5,0);
        tracep->declBus(c+102,"logicnet layer0_inst layer0_N20_inst M1", false,-1, 1,0);
        tracep->declBus(c+102,"logicnet layer0_inst layer0_N20_inst M1r", false,-1, 1,0);
        tracep->declBus(c+43,"logicnet layer0_inst layer0_N21_inst M0", false,-1, 5,0);
        tracep->declBus(c+103,"logicnet layer0_inst layer0_N21_inst M1", false,-1, 1,0);
        tracep->declBus(c+103,"logicnet layer0_inst layer0_N21_inst M1r", false,-1, 1,0);
        tracep->declBus(c+44,"logicnet layer0_inst layer0_N22_inst M0", false,-1, 5,0);
        tracep->declBus(c+104,"logicnet layer0_inst layer0_N22_inst M1", false,-1, 1,0);
        tracep->declBus(c+104,"logicnet layer0_inst layer0_N22_inst M1r", false,-1, 1,0);
        tracep->declBus(c+45,"logicnet layer0_inst layer0_N23_inst M0", false,-1, 5,0);
        tracep->declBus(c+105,"logicnet layer0_inst layer0_N23_inst M1", false,-1, 1,0);
        tracep->declBus(c+105,"logicnet layer0_inst layer0_N23_inst M1r", false,-1, 1,0);
        tracep->declBus(c+46,"logicnet layer0_inst layer0_N24_inst M0", false,-1, 5,0);
        tracep->declBus(c+106,"logicnet layer0_inst layer0_N24_inst M1", false,-1, 1,0);
        tracep->declBus(c+106,"logicnet layer0_inst layer0_N24_inst M1r", false,-1, 1,0);
        tracep->declBus(c+47,"logicnet layer0_inst layer0_N25_inst M0", false,-1, 5,0);
        tracep->declBus(c+107,"logicnet layer0_inst layer0_N25_inst M1", false,-1, 1,0);
        tracep->declBus(c+107,"logicnet layer0_inst layer0_N25_inst M1r", false,-1, 1,0);
        tracep->declBus(c+48,"logicnet layer0_inst layer0_N26_inst M0", false,-1, 5,0);
        tracep->declBus(c+108,"logicnet layer0_inst layer0_N26_inst M1", false,-1, 1,0);
        tracep->declBus(c+108,"logicnet layer0_inst layer0_N26_inst M1r", false,-1, 1,0);
        tracep->declBus(c+49,"logicnet layer0_inst layer0_N27_inst M0", false,-1, 5,0);
        tracep->declBus(c+109,"logicnet layer0_inst layer0_N27_inst M1", false,-1, 1,0);
        tracep->declBus(c+109,"logicnet layer0_inst layer0_N27_inst M1r", false,-1, 1,0);
        tracep->declBus(c+50,"logicnet layer0_inst layer0_N28_inst M0", false,-1, 5,0);
        tracep->declBus(c+110,"logicnet layer0_inst layer0_N28_inst M1", false,-1, 1,0);
        tracep->declBus(c+110,"logicnet layer0_inst layer0_N28_inst M1r", false,-1, 1,0);
        tracep->declBus(c+51,"logicnet layer0_inst layer0_N29_inst M0", false,-1, 5,0);
        tracep->declBus(c+111,"logicnet layer0_inst layer0_N29_inst M1", false,-1, 1,0);
        tracep->declBus(c+111,"logicnet layer0_inst layer0_N29_inst M1r", false,-1, 1,0);
        tracep->declBus(c+52,"logicnet layer0_inst layer0_N30_inst M0", false,-1, 5,0);
        tracep->declBus(c+112,"logicnet layer0_inst layer0_N30_inst M1", false,-1, 1,0);
        tracep->declBus(c+112,"logicnet layer0_inst layer0_N30_inst M1r", false,-1, 1,0);
        tracep->declBus(c+53,"logicnet layer0_inst layer0_N31_inst M0", false,-1, 5,0);
        tracep->declBus(c+113,"logicnet layer0_inst layer0_N31_inst M1", false,-1, 1,0);
        tracep->declBus(c+113,"logicnet layer0_inst layer0_N31_inst M1r", false,-1, 1,0);
        tracep->declBus(c+54,"logicnet layer0_inst layer0_N32_inst M0", false,-1, 5,0);
        tracep->declBus(c+114,"logicnet layer0_inst layer0_N32_inst M1", false,-1, 1,0);
        tracep->declBus(c+114,"logicnet layer0_inst layer0_N32_inst M1r", false,-1, 1,0);
        tracep->declBus(c+55,"logicnet layer0_inst layer0_N33_inst M0", false,-1, 5,0);
        tracep->declBus(c+115,"logicnet layer0_inst layer0_N33_inst M1", false,-1, 1,0);
        tracep->declBus(c+115,"logicnet layer0_inst layer0_N33_inst M1r", false,-1, 1,0);
        tracep->declBus(c+56,"logicnet layer0_inst layer0_N34_inst M0", false,-1, 5,0);
        tracep->declBus(c+116,"logicnet layer0_inst layer0_N34_inst M1", false,-1, 1,0);
        tracep->declBus(c+116,"logicnet layer0_inst layer0_N34_inst M1r", false,-1, 1,0);
        tracep->declBus(c+57,"logicnet layer0_inst layer0_N35_inst M0", false,-1, 5,0);
        tracep->declBus(c+117,"logicnet layer0_inst layer0_N35_inst M1", false,-1, 1,0);
        tracep->declBus(c+117,"logicnet layer0_inst layer0_N35_inst M1r", false,-1, 1,0);
        tracep->declBus(c+58,"logicnet layer0_inst layer0_N36_inst M0", false,-1, 5,0);
        tracep->declBus(c+118,"logicnet layer0_inst layer0_N36_inst M1", false,-1, 1,0);
        tracep->declBus(c+118,"logicnet layer0_inst layer0_N36_inst M1r", false,-1, 1,0);
        tracep->declBus(c+59,"logicnet layer0_inst layer0_N37_inst M0", false,-1, 5,0);
        tracep->declBus(c+119,"logicnet layer0_inst layer0_N37_inst M1", false,-1, 1,0);
        tracep->declBus(c+119,"logicnet layer0_inst layer0_N37_inst M1r", false,-1, 1,0);
        tracep->declBus(c+60,"logicnet layer0_inst layer0_N38_inst M0", false,-1, 5,0);
        tracep->declBus(c+120,"logicnet layer0_inst layer0_N38_inst M1", false,-1, 1,0);
        tracep->declBus(c+120,"logicnet layer0_inst layer0_N38_inst M1r", false,-1, 1,0);
        tracep->declBus(c+61,"logicnet layer0_inst layer0_N39_inst M0", false,-1, 5,0);
        tracep->declBus(c+121,"logicnet layer0_inst layer0_N39_inst M1", false,-1, 1,0);
        tracep->declBus(c+121,"logicnet layer0_inst layer0_N39_inst M1r", false,-1, 1,0);
        tracep->declBus(c+62,"logicnet layer0_inst layer0_N40_inst M0", false,-1, 5,0);
        tracep->declBus(c+122,"logicnet layer0_inst layer0_N40_inst M1", false,-1, 1,0);
        tracep->declBus(c+122,"logicnet layer0_inst layer0_N40_inst M1r", false,-1, 1,0);
        tracep->declBus(c+63,"logicnet layer0_inst layer0_N41_inst M0", false,-1, 5,0);
        tracep->declBus(c+123,"logicnet layer0_inst layer0_N41_inst M1", false,-1, 1,0);
        tracep->declBus(c+123,"logicnet layer0_inst layer0_N41_inst M1r", false,-1, 1,0);
        tracep->declBus(c+64,"logicnet layer0_inst layer0_N42_inst M0", false,-1, 5,0);
        tracep->declBus(c+124,"logicnet layer0_inst layer0_N42_inst M1", false,-1, 1,0);
        tracep->declBus(c+124,"logicnet layer0_inst layer0_N42_inst M1r", false,-1, 1,0);
        tracep->declBus(c+56,"logicnet layer0_inst layer0_N43_inst M0", false,-1, 5,0);
        tracep->declBus(c+125,"logicnet layer0_inst layer0_N43_inst M1", false,-1, 1,0);
        tracep->declBus(c+125,"logicnet layer0_inst layer0_N43_inst M1r", false,-1, 1,0);
        tracep->declBus(c+65,"logicnet layer0_inst layer0_N44_inst M0", false,-1, 5,0);
        tracep->declBus(c+126,"logicnet layer0_inst layer0_N44_inst M1", false,-1, 1,0);
        tracep->declBus(c+126,"logicnet layer0_inst layer0_N44_inst M1r", false,-1, 1,0);
        tracep->declBus(c+65,"logicnet layer0_inst layer0_N45_inst M0", false,-1, 5,0);
        tracep->declBus(c+127,"logicnet layer0_inst layer0_N45_inst M1", false,-1, 1,0);
        tracep->declBus(c+127,"logicnet layer0_inst layer0_N45_inst M1r", false,-1, 1,0);
        tracep->declBus(c+66,"logicnet layer0_inst layer0_N46_inst M0", false,-1, 5,0);
        tracep->declBus(c+128,"logicnet layer0_inst layer0_N46_inst M1", false,-1, 1,0);
        tracep->declBus(c+128,"logicnet layer0_inst layer0_N46_inst M1r", false,-1, 1,0);
        tracep->declBus(c+67,"logicnet layer0_inst layer0_N47_inst M0", false,-1, 5,0);
        tracep->declBus(c+129,"logicnet layer0_inst layer0_N47_inst M1", false,-1, 1,0);
        tracep->declBus(c+129,"logicnet layer0_inst layer0_N47_inst M1r", false,-1, 1,0);
        tracep->declBus(c+68,"logicnet layer0_inst layer0_N48_inst M0", false,-1, 5,0);
        tracep->declBus(c+130,"logicnet layer0_inst layer0_N48_inst M1", false,-1, 1,0);
        tracep->declBus(c+130,"logicnet layer0_inst layer0_N48_inst M1r", false,-1, 1,0);
        tracep->declBus(c+69,"logicnet layer0_inst layer0_N49_inst M0", false,-1, 5,0);
        tracep->declBus(c+131,"logicnet layer0_inst layer0_N49_inst M1", false,-1, 1,0);
        tracep->declBus(c+131,"logicnet layer0_inst layer0_N49_inst M1r", false,-1, 1,0);
        tracep->declBus(c+70,"logicnet layer0_inst layer0_N50_inst M0", false,-1, 5,0);
        tracep->declBus(c+132,"logicnet layer0_inst layer0_N50_inst M1", false,-1, 1,0);
        tracep->declBus(c+132,"logicnet layer0_inst layer0_N50_inst M1r", false,-1, 1,0);
        tracep->declBus(c+71,"logicnet layer0_inst layer0_N51_inst M0", false,-1, 5,0);
        tracep->declBus(c+133,"logicnet layer0_inst layer0_N51_inst M1", false,-1, 1,0);
        tracep->declBus(c+133,"logicnet layer0_inst layer0_N51_inst M1r", false,-1, 1,0);
        tracep->declBus(c+72,"logicnet layer0_inst layer0_N52_inst M0", false,-1, 5,0);
        tracep->declBus(c+134,"logicnet layer0_inst layer0_N52_inst M1", false,-1, 1,0);
        tracep->declBus(c+134,"logicnet layer0_inst layer0_N52_inst M1r", false,-1, 1,0);
        tracep->declBus(c+73,"logicnet layer0_inst layer0_N53_inst M0", false,-1, 5,0);
        tracep->declBus(c+135,"logicnet layer0_inst layer0_N53_inst M1", false,-1, 1,0);
        tracep->declBus(c+135,"logicnet layer0_inst layer0_N53_inst M1r", false,-1, 1,0);
        tracep->declBus(c+74,"logicnet layer0_inst layer0_N54_inst M0", false,-1, 5,0);
        tracep->declBus(c+136,"logicnet layer0_inst layer0_N54_inst M1", false,-1, 1,0);
        tracep->declBus(c+136,"logicnet layer0_inst layer0_N54_inst M1r", false,-1, 1,0);
        tracep->declBus(c+75,"logicnet layer0_inst layer0_N55_inst M0", false,-1, 5,0);
        tracep->declBus(c+137,"logicnet layer0_inst layer0_N55_inst M1", false,-1, 1,0);
        tracep->declBus(c+137,"logicnet layer0_inst layer0_N55_inst M1r", false,-1, 1,0);
        tracep->declBus(c+76,"logicnet layer0_inst layer0_N56_inst M0", false,-1, 5,0);
        tracep->declBus(c+138,"logicnet layer0_inst layer0_N56_inst M1", false,-1, 1,0);
        tracep->declBus(c+138,"logicnet layer0_inst layer0_N56_inst M1r", false,-1, 1,0);
        tracep->declBus(c+77,"logicnet layer0_inst layer0_N57_inst M0", false,-1, 5,0);
        tracep->declBus(c+139,"logicnet layer0_inst layer0_N57_inst M1", false,-1, 1,0);
        tracep->declBus(c+139,"logicnet layer0_inst layer0_N57_inst M1r", false,-1, 1,0);
        tracep->declBus(c+78,"logicnet layer0_inst layer0_N58_inst M0", false,-1, 5,0);
        tracep->declBus(c+140,"logicnet layer0_inst layer0_N58_inst M1", false,-1, 1,0);
        tracep->declBus(c+140,"logicnet layer0_inst layer0_N58_inst M1r", false,-1, 1,0);
        tracep->declBus(c+79,"logicnet layer0_inst layer0_N59_inst M0", false,-1, 5,0);
        tracep->declBus(c+141,"logicnet layer0_inst layer0_N59_inst M1", false,-1, 1,0);
        tracep->declBus(c+141,"logicnet layer0_inst layer0_N59_inst M1r", false,-1, 1,0);
        tracep->declBus(c+25,"logicnet layer0_inst layer0_N60_inst M0", false,-1, 5,0);
        tracep->declBus(c+142,"logicnet layer0_inst layer0_N60_inst M1", false,-1, 1,0);
        tracep->declBus(c+142,"logicnet layer0_inst layer0_N60_inst M1r", false,-1, 1,0);
        tracep->declBus(c+80,"logicnet layer0_inst layer0_N61_inst M0", false,-1, 5,0);
        tracep->declBus(c+143,"logicnet layer0_inst layer0_N61_inst M1", false,-1, 1,0);
        tracep->declBus(c+143,"logicnet layer0_inst layer0_N61_inst M1r", false,-1, 1,0);
        tracep->declBus(c+81,"logicnet layer0_inst layer0_N62_inst M0", false,-1, 5,0);
        tracep->declBus(c+144,"logicnet layer0_inst layer0_N62_inst M1", false,-1, 1,0);
        tracep->declBus(c+144,"logicnet layer0_inst layer0_N62_inst M1r", false,-1, 1,0);
        tracep->declBus(c+22,"logicnet layer0_inst layer0_N63_inst M0", false,-1, 5,0);
        tracep->declBus(c+145,"logicnet layer0_inst layer0_N63_inst M1", false,-1, 1,0);
        tracep->declBus(c+145,"logicnet layer0_inst layer0_N63_inst M1r", false,-1, 1,0);
        tracep->declBus(c+353,"logicnet layer1_reg DataWidth", false,-1, 31,0);
        tracep->declArray(c+2,"logicnet layer1_reg data_in", false,-1, 127,0);
        tracep->declBit(c+349,"logicnet layer1_reg clk", false,-1);
        tracep->declBit(c+350,"logicnet layer1_reg rst", false,-1);
        tracep->declArray(c+6,"logicnet layer1_reg data_out", false,-1, 127,0);
        tracep->declArray(c+6,"logicnet layer1_inst M0", false,-1, 127,0);
        tracep->declQuad(c+10,"logicnet layer1_inst M1", false,-1, 63,0);
        tracep->declBus(c+146,"logicnet layer1_inst layer1_N0_wire", false,-1, 5,0);
        tracep->declBus(c+147,"logicnet layer1_inst layer1_N1_wire", false,-1, 5,0);
        tracep->declBus(c+148,"logicnet layer1_inst layer1_N2_wire", false,-1, 5,0);
        tracep->declBus(c+149,"logicnet layer1_inst layer1_N3_wire", false,-1, 5,0);
        tracep->declBus(c+150,"logicnet layer1_inst layer1_N4_wire", false,-1, 5,0);
        tracep->declBus(c+151,"logicnet layer1_inst layer1_N5_wire", false,-1, 5,0);
        tracep->declBus(c+152,"logicnet layer1_inst layer1_N6_wire", false,-1, 5,0);
        tracep->declBus(c+153,"logicnet layer1_inst layer1_N7_wire", false,-1, 5,0);
        tracep->declBus(c+154,"logicnet layer1_inst layer1_N8_wire", false,-1, 5,0);
        tracep->declBus(c+155,"logicnet layer1_inst layer1_N9_wire", false,-1, 5,0);
        tracep->declBus(c+156,"logicnet layer1_inst layer1_N10_wire", false,-1, 5,0);
        tracep->declBus(c+157,"logicnet layer1_inst layer1_N11_wire", false,-1, 5,0);
        tracep->declBus(c+158,"logicnet layer1_inst layer1_N12_wire", false,-1, 5,0);
        tracep->declBus(c+159,"logicnet layer1_inst layer1_N13_wire", false,-1, 5,0);
        tracep->declBus(c+160,"logicnet layer1_inst layer1_N14_wire", false,-1, 5,0);
        tracep->declBus(c+161,"logicnet layer1_inst layer1_N15_wire", false,-1, 5,0);
        tracep->declBus(c+162,"logicnet layer1_inst layer1_N16_wire", false,-1, 5,0);
        tracep->declBus(c+163,"logicnet layer1_inst layer1_N17_wire", false,-1, 5,0);
        tracep->declBus(c+164,"logicnet layer1_inst layer1_N18_wire", false,-1, 5,0);
        tracep->declBus(c+165,"logicnet layer1_inst layer1_N19_wire", false,-1, 5,0);
        tracep->declBus(c+166,"logicnet layer1_inst layer1_N20_wire", false,-1, 5,0);
        tracep->declBus(c+167,"logicnet layer1_inst layer1_N21_wire", false,-1, 5,0);
        tracep->declBus(c+168,"logicnet layer1_inst layer1_N22_wire", false,-1, 5,0);
        tracep->declBus(c+169,"logicnet layer1_inst layer1_N23_wire", false,-1, 5,0);
        tracep->declBus(c+170,"logicnet layer1_inst layer1_N24_wire", false,-1, 5,0);
        tracep->declBus(c+171,"logicnet layer1_inst layer1_N25_wire", false,-1, 5,0);
        tracep->declBus(c+172,"logicnet layer1_inst layer1_N26_wire", false,-1, 5,0);
        tracep->declBus(c+173,"logicnet layer1_inst layer1_N27_wire", false,-1, 5,0);
        tracep->declBus(c+174,"logicnet layer1_inst layer1_N28_wire", false,-1, 5,0);
        tracep->declBus(c+175,"logicnet layer1_inst layer1_N29_wire", false,-1, 5,0);
        tracep->declBus(c+176,"logicnet layer1_inst layer1_N30_wire", false,-1, 5,0);
        tracep->declBus(c+177,"logicnet layer1_inst layer1_N31_wire", false,-1, 5,0);
        tracep->declBus(c+146,"logicnet layer1_inst layer1_N0_inst M0", false,-1, 5,0);
        tracep->declBus(c+178,"logicnet layer1_inst layer1_N0_inst M1", false,-1, 1,0);
        tracep->declBus(c+178,"logicnet layer1_inst layer1_N0_inst M1r", false,-1, 1,0);
        tracep->declBus(c+147,"logicnet layer1_inst layer1_N1_inst M0", false,-1, 5,0);
        tracep->declBus(c+179,"logicnet layer1_inst layer1_N1_inst M1", false,-1, 1,0);
        tracep->declBus(c+179,"logicnet layer1_inst layer1_N1_inst M1r", false,-1, 1,0);
        tracep->declBus(c+148,"logicnet layer1_inst layer1_N2_inst M0", false,-1, 5,0);
        tracep->declBus(c+180,"logicnet layer1_inst layer1_N2_inst M1", false,-1, 1,0);
        tracep->declBus(c+180,"logicnet layer1_inst layer1_N2_inst M1r", false,-1, 1,0);
        tracep->declBus(c+149,"logicnet layer1_inst layer1_N3_inst M0", false,-1, 5,0);
        tracep->declBus(c+181,"logicnet layer1_inst layer1_N3_inst M1", false,-1, 1,0);
        tracep->declBus(c+181,"logicnet layer1_inst layer1_N3_inst M1r", false,-1, 1,0);
        tracep->declBus(c+150,"logicnet layer1_inst layer1_N4_inst M0", false,-1, 5,0);
        tracep->declBus(c+182,"logicnet layer1_inst layer1_N4_inst M1", false,-1, 1,0);
        tracep->declBus(c+182,"logicnet layer1_inst layer1_N4_inst M1r", false,-1, 1,0);
        tracep->declBus(c+151,"logicnet layer1_inst layer1_N5_inst M0", false,-1, 5,0);
        tracep->declBus(c+183,"logicnet layer1_inst layer1_N5_inst M1", false,-1, 1,0);
        tracep->declBus(c+183,"logicnet layer1_inst layer1_N5_inst M1r", false,-1, 1,0);
        tracep->declBus(c+152,"logicnet layer1_inst layer1_N6_inst M0", false,-1, 5,0);
        tracep->declBus(c+184,"logicnet layer1_inst layer1_N6_inst M1", false,-1, 1,0);
        tracep->declBus(c+184,"logicnet layer1_inst layer1_N6_inst M1r", false,-1, 1,0);
        tracep->declBus(c+153,"logicnet layer1_inst layer1_N7_inst M0", false,-1, 5,0);
        tracep->declBus(c+185,"logicnet layer1_inst layer1_N7_inst M1", false,-1, 1,0);
        tracep->declBus(c+185,"logicnet layer1_inst layer1_N7_inst M1r", false,-1, 1,0);
        tracep->declBus(c+154,"logicnet layer1_inst layer1_N8_inst M0", false,-1, 5,0);
        tracep->declBus(c+186,"logicnet layer1_inst layer1_N8_inst M1", false,-1, 1,0);
        tracep->declBus(c+186,"logicnet layer1_inst layer1_N8_inst M1r", false,-1, 1,0);
        tracep->declBus(c+155,"logicnet layer1_inst layer1_N9_inst M0", false,-1, 5,0);
        tracep->declBus(c+187,"logicnet layer1_inst layer1_N9_inst M1", false,-1, 1,0);
        tracep->declBus(c+187,"logicnet layer1_inst layer1_N9_inst M1r", false,-1, 1,0);
        tracep->declBus(c+156,"logicnet layer1_inst layer1_N10_inst M0", false,-1, 5,0);
        tracep->declBus(c+188,"logicnet layer1_inst layer1_N10_inst M1", false,-1, 1,0);
        tracep->declBus(c+188,"logicnet layer1_inst layer1_N10_inst M1r", false,-1, 1,0);
        tracep->declBus(c+157,"logicnet layer1_inst layer1_N11_inst M0", false,-1, 5,0);
        tracep->declBus(c+189,"logicnet layer1_inst layer1_N11_inst M1", false,-1, 1,0);
        tracep->declBus(c+189,"logicnet layer1_inst layer1_N11_inst M1r", false,-1, 1,0);
        tracep->declBus(c+158,"logicnet layer1_inst layer1_N12_inst M0", false,-1, 5,0);
        tracep->declBus(c+190,"logicnet layer1_inst layer1_N12_inst M1", false,-1, 1,0);
        tracep->declBus(c+190,"logicnet layer1_inst layer1_N12_inst M1r", false,-1, 1,0);
        tracep->declBus(c+159,"logicnet layer1_inst layer1_N13_inst M0", false,-1, 5,0);
        tracep->declBus(c+191,"logicnet layer1_inst layer1_N13_inst M1", false,-1, 1,0);
        tracep->declBus(c+191,"logicnet layer1_inst layer1_N13_inst M1r", false,-1, 1,0);
        tracep->declBus(c+160,"logicnet layer1_inst layer1_N14_inst M0", false,-1, 5,0);
        tracep->declBus(c+192,"logicnet layer1_inst layer1_N14_inst M1", false,-1, 1,0);
        tracep->declBus(c+192,"logicnet layer1_inst layer1_N14_inst M1r", false,-1, 1,0);
        tracep->declBus(c+161,"logicnet layer1_inst layer1_N15_inst M0", false,-1, 5,0);
        tracep->declBus(c+193,"logicnet layer1_inst layer1_N15_inst M1", false,-1, 1,0);
        tracep->declBus(c+193,"logicnet layer1_inst layer1_N15_inst M1r", false,-1, 1,0);
        tracep->declBus(c+162,"logicnet layer1_inst layer1_N16_inst M0", false,-1, 5,0);
        tracep->declBus(c+194,"logicnet layer1_inst layer1_N16_inst M1", false,-1, 1,0);
        tracep->declBus(c+194,"logicnet layer1_inst layer1_N16_inst M1r", false,-1, 1,0);
        tracep->declBus(c+163,"logicnet layer1_inst layer1_N17_inst M0", false,-1, 5,0);
        tracep->declBus(c+195,"logicnet layer1_inst layer1_N17_inst M1", false,-1, 1,0);
        tracep->declBus(c+195,"logicnet layer1_inst layer1_N17_inst M1r", false,-1, 1,0);
        tracep->declBus(c+164,"logicnet layer1_inst layer1_N18_inst M0", false,-1, 5,0);
        tracep->declBus(c+196,"logicnet layer1_inst layer1_N18_inst M1", false,-1, 1,0);
        tracep->declBus(c+196,"logicnet layer1_inst layer1_N18_inst M1r", false,-1, 1,0);
        tracep->declBus(c+165,"logicnet layer1_inst layer1_N19_inst M0", false,-1, 5,0);
        tracep->declBus(c+197,"logicnet layer1_inst layer1_N19_inst M1", false,-1, 1,0);
        tracep->declBus(c+197,"logicnet layer1_inst layer1_N19_inst M1r", false,-1, 1,0);
        tracep->declBus(c+166,"logicnet layer1_inst layer1_N20_inst M0", false,-1, 5,0);
        tracep->declBus(c+198,"logicnet layer1_inst layer1_N20_inst M1", false,-1, 1,0);
        tracep->declBus(c+198,"logicnet layer1_inst layer1_N20_inst M1r", false,-1, 1,0);
        tracep->declBus(c+167,"logicnet layer1_inst layer1_N21_inst M0", false,-1, 5,0);
        tracep->declBus(c+199,"logicnet layer1_inst layer1_N21_inst M1", false,-1, 1,0);
        tracep->declBus(c+199,"logicnet layer1_inst layer1_N21_inst M1r", false,-1, 1,0);
        tracep->declBus(c+168,"logicnet layer1_inst layer1_N22_inst M0", false,-1, 5,0);
        tracep->declBus(c+200,"logicnet layer1_inst layer1_N22_inst M1", false,-1, 1,0);
        tracep->declBus(c+200,"logicnet layer1_inst layer1_N22_inst M1r", false,-1, 1,0);
        tracep->declBus(c+169,"logicnet layer1_inst layer1_N23_inst M0", false,-1, 5,0);
        tracep->declBus(c+201,"logicnet layer1_inst layer1_N23_inst M1", false,-1, 1,0);
        tracep->declBus(c+201,"logicnet layer1_inst layer1_N23_inst M1r", false,-1, 1,0);
        tracep->declBus(c+170,"logicnet layer1_inst layer1_N24_inst M0", false,-1, 5,0);
        tracep->declBus(c+202,"logicnet layer1_inst layer1_N24_inst M1", false,-1, 1,0);
        tracep->declBus(c+202,"logicnet layer1_inst layer1_N24_inst M1r", false,-1, 1,0);
        tracep->declBus(c+171,"logicnet layer1_inst layer1_N25_inst M0", false,-1, 5,0);
        tracep->declBus(c+203,"logicnet layer1_inst layer1_N25_inst M1", false,-1, 1,0);
        tracep->declBus(c+203,"logicnet layer1_inst layer1_N25_inst M1r", false,-1, 1,0);
        tracep->declBus(c+172,"logicnet layer1_inst layer1_N26_inst M0", false,-1, 5,0);
        tracep->declBus(c+204,"logicnet layer1_inst layer1_N26_inst M1", false,-1, 1,0);
        tracep->declBus(c+204,"logicnet layer1_inst layer1_N26_inst M1r", false,-1, 1,0);
        tracep->declBus(c+173,"logicnet layer1_inst layer1_N27_inst M0", false,-1, 5,0);
        tracep->declBus(c+205,"logicnet layer1_inst layer1_N27_inst M1", false,-1, 1,0);
        tracep->declBus(c+205,"logicnet layer1_inst layer1_N27_inst M1r", false,-1, 1,0);
        tracep->declBus(c+174,"logicnet layer1_inst layer1_N28_inst M0", false,-1, 5,0);
        tracep->declBus(c+206,"logicnet layer1_inst layer1_N28_inst M1", false,-1, 1,0);
        tracep->declBus(c+206,"logicnet layer1_inst layer1_N28_inst M1r", false,-1, 1,0);
        tracep->declBus(c+175,"logicnet layer1_inst layer1_N29_inst M0", false,-1, 5,0);
        tracep->declBus(c+207,"logicnet layer1_inst layer1_N29_inst M1", false,-1, 1,0);
        tracep->declBus(c+207,"logicnet layer1_inst layer1_N29_inst M1r", false,-1, 1,0);
        tracep->declBus(c+176,"logicnet layer1_inst layer1_N30_inst M0", false,-1, 5,0);
        tracep->declBus(c+208,"logicnet layer1_inst layer1_N30_inst M1", false,-1, 1,0);
        tracep->declBus(c+208,"logicnet layer1_inst layer1_N30_inst M1r", false,-1, 1,0);
        tracep->declBus(c+177,"logicnet layer1_inst layer1_N31_inst M0", false,-1, 5,0);
        tracep->declBus(c+209,"logicnet layer1_inst layer1_N31_inst M1", false,-1, 1,0);
        tracep->declBus(c+209,"logicnet layer1_inst layer1_N31_inst M1r", false,-1, 1,0);
        tracep->declBus(c+354,"logicnet layer2_reg DataWidth", false,-1, 31,0);
        tracep->declQuad(c+10,"logicnet layer2_reg data_in", false,-1, 63,0);
        tracep->declBit(c+349,"logicnet layer2_reg clk", false,-1);
        tracep->declBit(c+350,"logicnet layer2_reg rst", false,-1);
        tracep->declQuad(c+12,"logicnet layer2_reg data_out", false,-1, 63,0);
        tracep->declQuad(c+12,"logicnet layer2_inst M0", false,-1, 63,0);
        tracep->declQuad(c+14,"logicnet layer2_inst M1", false,-1, 63,0);
        tracep->declBus(c+210,"logicnet layer2_inst layer2_N0_wire", false,-1, 5,0);
        tracep->declBus(c+211,"logicnet layer2_inst layer2_N1_wire", false,-1, 5,0);
        tracep->declBus(c+212,"logicnet layer2_inst layer2_N2_wire", false,-1, 5,0);
        tracep->declBus(c+213,"logicnet layer2_inst layer2_N3_wire", false,-1, 5,0);
        tracep->declBus(c+214,"logicnet layer2_inst layer2_N4_wire", false,-1, 5,0);
        tracep->declBus(c+215,"logicnet layer2_inst layer2_N5_wire", false,-1, 5,0);
        tracep->declBus(c+216,"logicnet layer2_inst layer2_N6_wire", false,-1, 5,0);
        tracep->declBus(c+217,"logicnet layer2_inst layer2_N7_wire", false,-1, 5,0);
        tracep->declBus(c+218,"logicnet layer2_inst layer2_N8_wire", false,-1, 5,0);
        tracep->declBus(c+219,"logicnet layer2_inst layer2_N9_wire", false,-1, 5,0);
        tracep->declBus(c+220,"logicnet layer2_inst layer2_N10_wire", false,-1, 5,0);
        tracep->declBus(c+221,"logicnet layer2_inst layer2_N11_wire", false,-1, 5,0);
        tracep->declBus(c+222,"logicnet layer2_inst layer2_N12_wire", false,-1, 5,0);
        tracep->declBus(c+223,"logicnet layer2_inst layer2_N13_wire", false,-1, 5,0);
        tracep->declBus(c+224,"logicnet layer2_inst layer2_N14_wire", false,-1, 5,0);
        tracep->declBus(c+225,"logicnet layer2_inst layer2_N15_wire", false,-1, 5,0);
        tracep->declBus(c+226,"logicnet layer2_inst layer2_N16_wire", false,-1, 5,0);
        tracep->declBus(c+227,"logicnet layer2_inst layer2_N17_wire", false,-1, 5,0);
        tracep->declBus(c+228,"logicnet layer2_inst layer2_N18_wire", false,-1, 5,0);
        tracep->declBus(c+229,"logicnet layer2_inst layer2_N19_wire", false,-1, 5,0);
        tracep->declBus(c+230,"logicnet layer2_inst layer2_N20_wire", false,-1, 5,0);
        tracep->declBus(c+231,"logicnet layer2_inst layer2_N21_wire", false,-1, 5,0);
        tracep->declBus(c+232,"logicnet layer2_inst layer2_N22_wire", false,-1, 5,0);
        tracep->declBus(c+233,"logicnet layer2_inst layer2_N23_wire", false,-1, 5,0);
        tracep->declBus(c+234,"logicnet layer2_inst layer2_N24_wire", false,-1, 5,0);
        tracep->declBus(c+235,"logicnet layer2_inst layer2_N25_wire", false,-1, 5,0);
        tracep->declBus(c+236,"logicnet layer2_inst layer2_N26_wire", false,-1, 5,0);
        tracep->declBus(c+237,"logicnet layer2_inst layer2_N27_wire", false,-1, 5,0);
        tracep->declBus(c+238,"logicnet layer2_inst layer2_N28_wire", false,-1, 5,0);
        tracep->declBus(c+239,"logicnet layer2_inst layer2_N29_wire", false,-1, 5,0);
        tracep->declBus(c+240,"logicnet layer2_inst layer2_N30_wire", false,-1, 5,0);
        tracep->declBus(c+241,"logicnet layer2_inst layer2_N31_wire", false,-1, 5,0);
        tracep->declBus(c+210,"logicnet layer2_inst layer2_N0_inst M0", false,-1, 5,0);
        tracep->declBus(c+242,"logicnet layer2_inst layer2_N0_inst M1", false,-1, 1,0);
        tracep->declBus(c+242,"logicnet layer2_inst layer2_N0_inst M1r", false,-1, 1,0);
        tracep->declBus(c+211,"logicnet layer2_inst layer2_N1_inst M0", false,-1, 5,0);
        tracep->declBus(c+243,"logicnet layer2_inst layer2_N1_inst M1", false,-1, 1,0);
        tracep->declBus(c+243,"logicnet layer2_inst layer2_N1_inst M1r", false,-1, 1,0);
        tracep->declBus(c+212,"logicnet layer2_inst layer2_N2_inst M0", false,-1, 5,0);
        tracep->declBus(c+244,"logicnet layer2_inst layer2_N2_inst M1", false,-1, 1,0);
        tracep->declBus(c+244,"logicnet layer2_inst layer2_N2_inst M1r", false,-1, 1,0);
        tracep->declBus(c+213,"logicnet layer2_inst layer2_N3_inst M0", false,-1, 5,0);
        tracep->declBus(c+245,"logicnet layer2_inst layer2_N3_inst M1", false,-1, 1,0);
        tracep->declBus(c+245,"logicnet layer2_inst layer2_N3_inst M1r", false,-1, 1,0);
        tracep->declBus(c+214,"logicnet layer2_inst layer2_N4_inst M0", false,-1, 5,0);
        tracep->declBus(c+246,"logicnet layer2_inst layer2_N4_inst M1", false,-1, 1,0);
        tracep->declBus(c+246,"logicnet layer2_inst layer2_N4_inst M1r", false,-1, 1,0);
        tracep->declBus(c+215,"logicnet layer2_inst layer2_N5_inst M0", false,-1, 5,0);
        tracep->declBus(c+247,"logicnet layer2_inst layer2_N5_inst M1", false,-1, 1,0);
        tracep->declBus(c+247,"logicnet layer2_inst layer2_N5_inst M1r", false,-1, 1,0);
        tracep->declBus(c+216,"logicnet layer2_inst layer2_N6_inst M0", false,-1, 5,0);
        tracep->declBus(c+248,"logicnet layer2_inst layer2_N6_inst M1", false,-1, 1,0);
        tracep->declBus(c+248,"logicnet layer2_inst layer2_N6_inst M1r", false,-1, 1,0);
        tracep->declBus(c+217,"logicnet layer2_inst layer2_N7_inst M0", false,-1, 5,0);
        tracep->declBus(c+249,"logicnet layer2_inst layer2_N7_inst M1", false,-1, 1,0);
        tracep->declBus(c+249,"logicnet layer2_inst layer2_N7_inst M1r", false,-1, 1,0);
        tracep->declBus(c+218,"logicnet layer2_inst layer2_N8_inst M0", false,-1, 5,0);
        tracep->declBus(c+250,"logicnet layer2_inst layer2_N8_inst M1", false,-1, 1,0);
        tracep->declBus(c+250,"logicnet layer2_inst layer2_N8_inst M1r", false,-1, 1,0);
        tracep->declBus(c+219,"logicnet layer2_inst layer2_N9_inst M0", false,-1, 5,0);
        tracep->declBus(c+251,"logicnet layer2_inst layer2_N9_inst M1", false,-1, 1,0);
        tracep->declBus(c+251,"logicnet layer2_inst layer2_N9_inst M1r", false,-1, 1,0);
        tracep->declBus(c+220,"logicnet layer2_inst layer2_N10_inst M0", false,-1, 5,0);
        tracep->declBus(c+252,"logicnet layer2_inst layer2_N10_inst M1", false,-1, 1,0);
        tracep->declBus(c+252,"logicnet layer2_inst layer2_N10_inst M1r", false,-1, 1,0);
        tracep->declBus(c+221,"logicnet layer2_inst layer2_N11_inst M0", false,-1, 5,0);
        tracep->declBus(c+253,"logicnet layer2_inst layer2_N11_inst M1", false,-1, 1,0);
        tracep->declBus(c+253,"logicnet layer2_inst layer2_N11_inst M1r", false,-1, 1,0);
        tracep->declBus(c+222,"logicnet layer2_inst layer2_N12_inst M0", false,-1, 5,0);
        tracep->declBus(c+254,"logicnet layer2_inst layer2_N12_inst M1", false,-1, 1,0);
        tracep->declBus(c+254,"logicnet layer2_inst layer2_N12_inst M1r", false,-1, 1,0);
        tracep->declBus(c+223,"logicnet layer2_inst layer2_N13_inst M0", false,-1, 5,0);
        tracep->declBus(c+255,"logicnet layer2_inst layer2_N13_inst M1", false,-1, 1,0);
        tracep->declBus(c+255,"logicnet layer2_inst layer2_N13_inst M1r", false,-1, 1,0);
        tracep->declBus(c+224,"logicnet layer2_inst layer2_N14_inst M0", false,-1, 5,0);
        tracep->declBus(c+256,"logicnet layer2_inst layer2_N14_inst M1", false,-1, 1,0);
        tracep->declBus(c+256,"logicnet layer2_inst layer2_N14_inst M1r", false,-1, 1,0);
        tracep->declBus(c+225,"logicnet layer2_inst layer2_N15_inst M0", false,-1, 5,0);
        tracep->declBus(c+257,"logicnet layer2_inst layer2_N15_inst M1", false,-1, 1,0);
        tracep->declBus(c+257,"logicnet layer2_inst layer2_N15_inst M1r", false,-1, 1,0);
        tracep->declBus(c+226,"logicnet layer2_inst layer2_N16_inst M0", false,-1, 5,0);
        tracep->declBus(c+258,"logicnet layer2_inst layer2_N16_inst M1", false,-1, 1,0);
        tracep->declBus(c+258,"logicnet layer2_inst layer2_N16_inst M1r", false,-1, 1,0);
        tracep->declBus(c+227,"logicnet layer2_inst layer2_N17_inst M0", false,-1, 5,0);
        tracep->declBus(c+259,"logicnet layer2_inst layer2_N17_inst M1", false,-1, 1,0);
        tracep->declBus(c+259,"logicnet layer2_inst layer2_N17_inst M1r", false,-1, 1,0);
        tracep->declBus(c+228,"logicnet layer2_inst layer2_N18_inst M0", false,-1, 5,0);
        tracep->declBus(c+260,"logicnet layer2_inst layer2_N18_inst M1", false,-1, 1,0);
        tracep->declBus(c+260,"logicnet layer2_inst layer2_N18_inst M1r", false,-1, 1,0);
        tracep->declBus(c+229,"logicnet layer2_inst layer2_N19_inst M0", false,-1, 5,0);
        tracep->declBus(c+261,"logicnet layer2_inst layer2_N19_inst M1", false,-1, 1,0);
        tracep->declBus(c+261,"logicnet layer2_inst layer2_N19_inst M1r", false,-1, 1,0);
        tracep->declBus(c+230,"logicnet layer2_inst layer2_N20_inst M0", false,-1, 5,0);
        tracep->declBus(c+262,"logicnet layer2_inst layer2_N20_inst M1", false,-1, 1,0);
        tracep->declBus(c+262,"logicnet layer2_inst layer2_N20_inst M1r", false,-1, 1,0);
        tracep->declBus(c+231,"logicnet layer2_inst layer2_N21_inst M0", false,-1, 5,0);
        tracep->declBus(c+263,"logicnet layer2_inst layer2_N21_inst M1", false,-1, 1,0);
        tracep->declBus(c+263,"logicnet layer2_inst layer2_N21_inst M1r", false,-1, 1,0);
        tracep->declBus(c+232,"logicnet layer2_inst layer2_N22_inst M0", false,-1, 5,0);
        tracep->declBus(c+264,"logicnet layer2_inst layer2_N22_inst M1", false,-1, 1,0);
        tracep->declBus(c+264,"logicnet layer2_inst layer2_N22_inst M1r", false,-1, 1,0);
        tracep->declBus(c+233,"logicnet layer2_inst layer2_N23_inst M0", false,-1, 5,0);
        tracep->declBus(c+265,"logicnet layer2_inst layer2_N23_inst M1", false,-1, 1,0);
        tracep->declBus(c+265,"logicnet layer2_inst layer2_N23_inst M1r", false,-1, 1,0);
        tracep->declBus(c+234,"logicnet layer2_inst layer2_N24_inst M0", false,-1, 5,0);
        tracep->declBus(c+266,"logicnet layer2_inst layer2_N24_inst M1", false,-1, 1,0);
        tracep->declBus(c+266,"logicnet layer2_inst layer2_N24_inst M1r", false,-1, 1,0);
        tracep->declBus(c+235,"logicnet layer2_inst layer2_N25_inst M0", false,-1, 5,0);
        tracep->declBus(c+267,"logicnet layer2_inst layer2_N25_inst M1", false,-1, 1,0);
        tracep->declBus(c+267,"logicnet layer2_inst layer2_N25_inst M1r", false,-1, 1,0);
        tracep->declBus(c+236,"logicnet layer2_inst layer2_N26_inst M0", false,-1, 5,0);
        tracep->declBus(c+268,"logicnet layer2_inst layer2_N26_inst M1", false,-1, 1,0);
        tracep->declBus(c+268,"logicnet layer2_inst layer2_N26_inst M1r", false,-1, 1,0);
        tracep->declBus(c+237,"logicnet layer2_inst layer2_N27_inst M0", false,-1, 5,0);
        tracep->declBus(c+269,"logicnet layer2_inst layer2_N27_inst M1", false,-1, 1,0);
        tracep->declBus(c+269,"logicnet layer2_inst layer2_N27_inst M1r", false,-1, 1,0);
        tracep->declBus(c+238,"logicnet layer2_inst layer2_N28_inst M0", false,-1, 5,0);
        tracep->declBus(c+270,"logicnet layer2_inst layer2_N28_inst M1", false,-1, 1,0);
        tracep->declBus(c+270,"logicnet layer2_inst layer2_N28_inst M1r", false,-1, 1,0);
        tracep->declBus(c+239,"logicnet layer2_inst layer2_N29_inst M0", false,-1, 5,0);
        tracep->declBus(c+271,"logicnet layer2_inst layer2_N29_inst M1", false,-1, 1,0);
        tracep->declBus(c+271,"logicnet layer2_inst layer2_N29_inst M1r", false,-1, 1,0);
        tracep->declBus(c+240,"logicnet layer2_inst layer2_N30_inst M0", false,-1, 5,0);
        tracep->declBus(c+272,"logicnet layer2_inst layer2_N30_inst M1", false,-1, 1,0);
        tracep->declBus(c+272,"logicnet layer2_inst layer2_N30_inst M1r", false,-1, 1,0);
        tracep->declBus(c+241,"logicnet layer2_inst layer2_N31_inst M0", false,-1, 5,0);
        tracep->declBus(c+273,"logicnet layer2_inst layer2_N31_inst M1", false,-1, 1,0);
        tracep->declBus(c+273,"logicnet layer2_inst layer2_N31_inst M1r", false,-1, 1,0);
        tracep->declBus(c+354,"logicnet layer3_reg DataWidth", false,-1, 31,0);
        tracep->declQuad(c+14,"logicnet layer3_reg data_in", false,-1, 63,0);
        tracep->declBit(c+349,"logicnet layer3_reg clk", false,-1);
        tracep->declBit(c+350,"logicnet layer3_reg rst", false,-1);
        tracep->declQuad(c+16,"logicnet layer3_reg data_out", false,-1, 63,0);
        tracep->declQuad(c+16,"logicnet layer3_inst M0", false,-1, 63,0);
        tracep->declQuad(c+18,"logicnet layer3_inst M1", false,-1, 63,0);
        tracep->declBus(c+274,"logicnet layer3_inst layer3_N0_wire", false,-1, 5,0);
        tracep->declBus(c+275,"logicnet layer3_inst layer3_N1_wire", false,-1, 5,0);
        tracep->declBus(c+276,"logicnet layer3_inst layer3_N2_wire", false,-1, 5,0);
        tracep->declBus(c+277,"logicnet layer3_inst layer3_N3_wire", false,-1, 5,0);
        tracep->declBus(c+278,"logicnet layer3_inst layer3_N4_wire", false,-1, 5,0);
        tracep->declBus(c+279,"logicnet layer3_inst layer3_N5_wire", false,-1, 5,0);
        tracep->declBus(c+280,"logicnet layer3_inst layer3_N6_wire", false,-1, 5,0);
        tracep->declBus(c+281,"logicnet layer3_inst layer3_N7_wire", false,-1, 5,0);
        tracep->declBus(c+282,"logicnet layer3_inst layer3_N8_wire", false,-1, 5,0);
        tracep->declBus(c+283,"logicnet layer3_inst layer3_N9_wire", false,-1, 5,0);
        tracep->declBus(c+284,"logicnet layer3_inst layer3_N10_wire", false,-1, 5,0);
        tracep->declBus(c+285,"logicnet layer3_inst layer3_N11_wire", false,-1, 5,0);
        tracep->declBus(c+286,"logicnet layer3_inst layer3_N12_wire", false,-1, 5,0);
        tracep->declBus(c+287,"logicnet layer3_inst layer3_N13_wire", false,-1, 5,0);
        tracep->declBus(c+288,"logicnet layer3_inst layer3_N14_wire", false,-1, 5,0);
        tracep->declBus(c+289,"logicnet layer3_inst layer3_N15_wire", false,-1, 5,0);
        tracep->declBus(c+290,"logicnet layer3_inst layer3_N16_wire", false,-1, 5,0);
        tracep->declBus(c+291,"logicnet layer3_inst layer3_N17_wire", false,-1, 5,0);
        tracep->declBus(c+292,"logicnet layer3_inst layer3_N18_wire", false,-1, 5,0);
        tracep->declBus(c+293,"logicnet layer3_inst layer3_N19_wire", false,-1, 5,0);
        tracep->declBus(c+294,"logicnet layer3_inst layer3_N20_wire", false,-1, 5,0);
        tracep->declBus(c+295,"logicnet layer3_inst layer3_N21_wire", false,-1, 5,0);
        tracep->declBus(c+296,"logicnet layer3_inst layer3_N22_wire", false,-1, 5,0);
        tracep->declBus(c+297,"logicnet layer3_inst layer3_N23_wire", false,-1, 5,0);
        tracep->declBus(c+298,"logicnet layer3_inst layer3_N24_wire", false,-1, 5,0);
        tracep->declBus(c+299,"logicnet layer3_inst layer3_N25_wire", false,-1, 5,0);
        tracep->declBus(c+300,"logicnet layer3_inst layer3_N26_wire", false,-1, 5,0);
        tracep->declBus(c+301,"logicnet layer3_inst layer3_N27_wire", false,-1, 5,0);
        tracep->declBus(c+302,"logicnet layer3_inst layer3_N28_wire", false,-1, 5,0);
        tracep->declBus(c+303,"logicnet layer3_inst layer3_N29_wire", false,-1, 5,0);
        tracep->declBus(c+304,"logicnet layer3_inst layer3_N30_wire", false,-1, 5,0);
        tracep->declBus(c+305,"logicnet layer3_inst layer3_N31_wire", false,-1, 5,0);
        tracep->declBus(c+274,"logicnet layer3_inst layer3_N0_inst M0", false,-1, 5,0);
        tracep->declBus(c+306,"logicnet layer3_inst layer3_N0_inst M1", false,-1, 1,0);
        tracep->declBus(c+306,"logicnet layer3_inst layer3_N0_inst M1r", false,-1, 1,0);
        tracep->declBus(c+275,"logicnet layer3_inst layer3_N1_inst M0", false,-1, 5,0);
        tracep->declBus(c+307,"logicnet layer3_inst layer3_N1_inst M1", false,-1, 1,0);
        tracep->declBus(c+307,"logicnet layer3_inst layer3_N1_inst M1r", false,-1, 1,0);
        tracep->declBus(c+276,"logicnet layer3_inst layer3_N2_inst M0", false,-1, 5,0);
        tracep->declBus(c+308,"logicnet layer3_inst layer3_N2_inst M1", false,-1, 1,0);
        tracep->declBus(c+308,"logicnet layer3_inst layer3_N2_inst M1r", false,-1, 1,0);
        tracep->declBus(c+277,"logicnet layer3_inst layer3_N3_inst M0", false,-1, 5,0);
        tracep->declBus(c+309,"logicnet layer3_inst layer3_N3_inst M1", false,-1, 1,0);
        tracep->declBus(c+309,"logicnet layer3_inst layer3_N3_inst M1r", false,-1, 1,0);
        tracep->declBus(c+278,"logicnet layer3_inst layer3_N4_inst M0", false,-1, 5,0);
        tracep->declBus(c+310,"logicnet layer3_inst layer3_N4_inst M1", false,-1, 1,0);
        tracep->declBus(c+310,"logicnet layer3_inst layer3_N4_inst M1r", false,-1, 1,0);
        tracep->declBus(c+279,"logicnet layer3_inst layer3_N5_inst M0", false,-1, 5,0);
        tracep->declBus(c+311,"logicnet layer3_inst layer3_N5_inst M1", false,-1, 1,0);
        tracep->declBus(c+311,"logicnet layer3_inst layer3_N5_inst M1r", false,-1, 1,0);
        tracep->declBus(c+280,"logicnet layer3_inst layer3_N6_inst M0", false,-1, 5,0);
        tracep->declBus(c+312,"logicnet layer3_inst layer3_N6_inst M1", false,-1, 1,0);
        tracep->declBus(c+312,"logicnet layer3_inst layer3_N6_inst M1r", false,-1, 1,0);
        tracep->declBus(c+281,"logicnet layer3_inst layer3_N7_inst M0", false,-1, 5,0);
        tracep->declBus(c+313,"logicnet layer3_inst layer3_N7_inst M1", false,-1, 1,0);
        tracep->declBus(c+313,"logicnet layer3_inst layer3_N7_inst M1r", false,-1, 1,0);
        tracep->declBus(c+282,"logicnet layer3_inst layer3_N8_inst M0", false,-1, 5,0);
        tracep->declBus(c+314,"logicnet layer3_inst layer3_N8_inst M1", false,-1, 1,0);
        tracep->declBus(c+314,"logicnet layer3_inst layer3_N8_inst M1r", false,-1, 1,0);
        tracep->declBus(c+283,"logicnet layer3_inst layer3_N9_inst M0", false,-1, 5,0);
        tracep->declBus(c+315,"logicnet layer3_inst layer3_N9_inst M1", false,-1, 1,0);
        tracep->declBus(c+315,"logicnet layer3_inst layer3_N9_inst M1r", false,-1, 1,0);
        tracep->declBus(c+284,"logicnet layer3_inst layer3_N10_inst M0", false,-1, 5,0);
        tracep->declBus(c+316,"logicnet layer3_inst layer3_N10_inst M1", false,-1, 1,0);
        tracep->declBus(c+316,"logicnet layer3_inst layer3_N10_inst M1r", false,-1, 1,0);
        tracep->declBus(c+285,"logicnet layer3_inst layer3_N11_inst M0", false,-1, 5,0);
        tracep->declBus(c+317,"logicnet layer3_inst layer3_N11_inst M1", false,-1, 1,0);
        tracep->declBus(c+317,"logicnet layer3_inst layer3_N11_inst M1r", false,-1, 1,0);
        tracep->declBus(c+286,"logicnet layer3_inst layer3_N12_inst M0", false,-1, 5,0);
        tracep->declBus(c+318,"logicnet layer3_inst layer3_N12_inst M1", false,-1, 1,0);
        tracep->declBus(c+318,"logicnet layer3_inst layer3_N12_inst M1r", false,-1, 1,0);
        tracep->declBus(c+287,"logicnet layer3_inst layer3_N13_inst M0", false,-1, 5,0);
        tracep->declBus(c+319,"logicnet layer3_inst layer3_N13_inst M1", false,-1, 1,0);
        tracep->declBus(c+319,"logicnet layer3_inst layer3_N13_inst M1r", false,-1, 1,0);
        tracep->declBus(c+288,"logicnet layer3_inst layer3_N14_inst M0", false,-1, 5,0);
        tracep->declBus(c+320,"logicnet layer3_inst layer3_N14_inst M1", false,-1, 1,0);
        tracep->declBus(c+320,"logicnet layer3_inst layer3_N14_inst M1r", false,-1, 1,0);
        tracep->declBus(c+289,"logicnet layer3_inst layer3_N15_inst M0", false,-1, 5,0);
        tracep->declBus(c+321,"logicnet layer3_inst layer3_N15_inst M1", false,-1, 1,0);
        tracep->declBus(c+321,"logicnet layer3_inst layer3_N15_inst M1r", false,-1, 1,0);
        tracep->declBus(c+290,"logicnet layer3_inst layer3_N16_inst M0", false,-1, 5,0);
        tracep->declBus(c+322,"logicnet layer3_inst layer3_N16_inst M1", false,-1, 1,0);
        tracep->declBus(c+322,"logicnet layer3_inst layer3_N16_inst M1r", false,-1, 1,0);
        tracep->declBus(c+291,"logicnet layer3_inst layer3_N17_inst M0", false,-1, 5,0);
        tracep->declBus(c+323,"logicnet layer3_inst layer3_N17_inst M1", false,-1, 1,0);
        tracep->declBus(c+323,"logicnet layer3_inst layer3_N17_inst M1r", false,-1, 1,0);
        tracep->declBus(c+292,"logicnet layer3_inst layer3_N18_inst M0", false,-1, 5,0);
        tracep->declBus(c+324,"logicnet layer3_inst layer3_N18_inst M1", false,-1, 1,0);
        tracep->declBus(c+324,"logicnet layer3_inst layer3_N18_inst M1r", false,-1, 1,0);
        tracep->declBus(c+293,"logicnet layer3_inst layer3_N19_inst M0", false,-1, 5,0);
        tracep->declBus(c+325,"logicnet layer3_inst layer3_N19_inst M1", false,-1, 1,0);
        tracep->declBus(c+325,"logicnet layer3_inst layer3_N19_inst M1r", false,-1, 1,0);
        tracep->declBus(c+294,"logicnet layer3_inst layer3_N20_inst M0", false,-1, 5,0);
        tracep->declBus(c+326,"logicnet layer3_inst layer3_N20_inst M1", false,-1, 1,0);
        tracep->declBus(c+326,"logicnet layer3_inst layer3_N20_inst M1r", false,-1, 1,0);
        tracep->declBus(c+295,"logicnet layer3_inst layer3_N21_inst M0", false,-1, 5,0);
        tracep->declBus(c+327,"logicnet layer3_inst layer3_N21_inst M1", false,-1, 1,0);
        tracep->declBus(c+327,"logicnet layer3_inst layer3_N21_inst M1r", false,-1, 1,0);
        tracep->declBus(c+296,"logicnet layer3_inst layer3_N22_inst M0", false,-1, 5,0);
        tracep->declBus(c+328,"logicnet layer3_inst layer3_N22_inst M1", false,-1, 1,0);
        tracep->declBus(c+328,"logicnet layer3_inst layer3_N22_inst M1r", false,-1, 1,0);
        tracep->declBus(c+297,"logicnet layer3_inst layer3_N23_inst M0", false,-1, 5,0);
        tracep->declBus(c+329,"logicnet layer3_inst layer3_N23_inst M1", false,-1, 1,0);
        tracep->declBus(c+329,"logicnet layer3_inst layer3_N23_inst M1r", false,-1, 1,0);
        tracep->declBus(c+298,"logicnet layer3_inst layer3_N24_inst M0", false,-1, 5,0);
        tracep->declBus(c+330,"logicnet layer3_inst layer3_N24_inst M1", false,-1, 1,0);
        tracep->declBus(c+330,"logicnet layer3_inst layer3_N24_inst M1r", false,-1, 1,0);
        tracep->declBus(c+299,"logicnet layer3_inst layer3_N25_inst M0", false,-1, 5,0);
        tracep->declBus(c+331,"logicnet layer3_inst layer3_N25_inst M1", false,-1, 1,0);
        tracep->declBus(c+331,"logicnet layer3_inst layer3_N25_inst M1r", false,-1, 1,0);
        tracep->declBus(c+300,"logicnet layer3_inst layer3_N26_inst M0", false,-1, 5,0);
        tracep->declBus(c+332,"logicnet layer3_inst layer3_N26_inst M1", false,-1, 1,0);
        tracep->declBus(c+332,"logicnet layer3_inst layer3_N26_inst M1r", false,-1, 1,0);
        tracep->declBus(c+301,"logicnet layer3_inst layer3_N27_inst M0", false,-1, 5,0);
        tracep->declBus(c+333,"logicnet layer3_inst layer3_N27_inst M1", false,-1, 1,0);
        tracep->declBus(c+333,"logicnet layer3_inst layer3_N27_inst M1r", false,-1, 1,0);
        tracep->declBus(c+302,"logicnet layer3_inst layer3_N28_inst M0", false,-1, 5,0);
        tracep->declBus(c+334,"logicnet layer3_inst layer3_N28_inst M1", false,-1, 1,0);
        tracep->declBus(c+334,"logicnet layer3_inst layer3_N28_inst M1r", false,-1, 1,0);
        tracep->declBus(c+303,"logicnet layer3_inst layer3_N29_inst M0", false,-1, 5,0);
        tracep->declBus(c+335,"logicnet layer3_inst layer3_N29_inst M1", false,-1, 1,0);
        tracep->declBus(c+335,"logicnet layer3_inst layer3_N29_inst M1r", false,-1, 1,0);
        tracep->declBus(c+304,"logicnet layer3_inst layer3_N30_inst M0", false,-1, 5,0);
        tracep->declBus(c+336,"logicnet layer3_inst layer3_N30_inst M1", false,-1, 1,0);
        tracep->declBus(c+336,"logicnet layer3_inst layer3_N30_inst M1r", false,-1, 1,0);
        tracep->declBus(c+305,"logicnet layer3_inst layer3_N31_inst M0", false,-1, 5,0);
        tracep->declBus(c+337,"logicnet layer3_inst layer3_N31_inst M1", false,-1, 1,0);
        tracep->declBus(c+337,"logicnet layer3_inst layer3_N31_inst M1r", false,-1, 1,0);
        tracep->declBus(c+354,"logicnet layer4_reg DataWidth", false,-1, 31,0);
        tracep->declQuad(c+18,"logicnet layer4_reg data_in", false,-1, 63,0);
        tracep->declBit(c+349,"logicnet layer4_reg clk", false,-1);
        tracep->declBit(c+350,"logicnet layer4_reg rst", false,-1);
        tracep->declQuad(c+20,"logicnet layer4_reg data_out", false,-1, 63,0);
        tracep->declQuad(c+20,"logicnet layer4_inst M0", false,-1, 63,0);
        tracep->declBus(c+351,"logicnet layer4_inst M1", false,-1, 14,0);
        tracep->declBus(c+338,"logicnet layer4_inst layer4_N0_wire", false,-1, 5,0);
        tracep->declBus(c+339,"logicnet layer4_inst layer4_N1_wire", false,-1, 5,0);
        tracep->declBus(c+340,"logicnet layer4_inst layer4_N2_wire", false,-1, 5,0);
        tracep->declBus(c+341,"logicnet layer4_inst layer4_N3_wire", false,-1, 5,0);
        tracep->declBus(c+342,"logicnet layer4_inst layer4_N4_wire", false,-1, 5,0);
        tracep->declBus(c+338,"logicnet layer4_inst layer4_N0_inst M0", false,-1, 5,0);
        tracep->declBus(c+343,"logicnet layer4_inst layer4_N0_inst M1", false,-1, 2,0);
        tracep->declBus(c+343,"logicnet layer4_inst layer4_N0_inst M1r", false,-1, 2,0);
        tracep->declBus(c+339,"logicnet layer4_inst layer4_N1_inst M0", false,-1, 5,0);
        tracep->declBus(c+344,"logicnet layer4_inst layer4_N1_inst M1", false,-1, 2,0);
        tracep->declBus(c+344,"logicnet layer4_inst layer4_N1_inst M1r", false,-1, 2,0);
        tracep->declBus(c+340,"logicnet layer4_inst layer4_N2_inst M0", false,-1, 5,0);
        tracep->declBus(c+345,"logicnet layer4_inst layer4_N2_inst M1", false,-1, 2,0);
        tracep->declBus(c+345,"logicnet layer4_inst layer4_N2_inst M1r", false,-1, 2,0);
        tracep->declBus(c+341,"logicnet layer4_inst layer4_N3_inst M0", false,-1, 5,0);
        tracep->declBus(c+346,"logicnet layer4_inst layer4_N3_inst M1", false,-1, 2,0);
        tracep->declBus(c+346,"logicnet layer4_inst layer4_N3_inst M1r", false,-1, 2,0);
        tracep->declBus(c+342,"logicnet layer4_inst layer4_N4_inst M0", false,-1, 5,0);
        tracep->declBus(c+347,"logicnet layer4_inst layer4_N4_inst M1", false,-1, 2,0);
        tracep->declBus(c+347,"logicnet layer4_inst layer4_N4_inst M1r", false,-1, 2,0);
    }
}

void Vlogicnet::traceRegister(VerilatedVcd* tracep) {
    // Body
    {
        tracep->addFullCb(&traceFullTop0, __VlSymsp);
        tracep->addChgCb(&traceChgTop0, __VlSymsp);
        tracep->addCleanupCb(&traceCleanup, __VlSymsp);
    }
}

void Vlogicnet::traceFullTop0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlTOPp->traceFullSub0(userp, tracep);
    }
}

void Vlogicnet::traceFullSub0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    vluint32_t* const oldp = tracep->oldp(vlSymsp->__Vm_baseCode);
    if (false && oldp) {}  // Prevent unused
    // Body
    {
        tracep->fullIData(oldp+1,(vlTOPp->logicnet__DOT__M0w),32);
        tracep->fullWData(oldp+2,(vlTOPp->logicnet__DOT__M1),128);
        tracep->fullWData(oldp+6,(vlTOPp->logicnet__DOT__M1w),128);
        tracep->fullQData(oldp+10,(vlTOPp->logicnet__DOT__M2),64);
        tracep->fullQData(oldp+12,(vlTOPp->logicnet__DOT__M2w),64);
        tracep->fullQData(oldp+14,(vlTOPp->logicnet__DOT__M3),64);
        tracep->fullQData(oldp+16,(vlTOPp->logicnet__DOT__M3w),64);
        tracep->fullQData(oldp+18,(vlTOPp->logicnet__DOT__M4),64);
        tracep->fullQData(oldp+20,(vlTOPp->logicnet__DOT__M4w),64);
        tracep->fullCData(oldp+22,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+23,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 8U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+24,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xcU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+25,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
        tracep->fullCData(oldp+26,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x14U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x18U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+27,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 8U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
        tracep->fullCData(oldp+28,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xaU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x12U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+29,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xcU)))))),6);
        tracep->fullCData(oldp+30,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x16U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x16U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+31,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x14U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+32,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+33,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+34,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xcU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+35,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xaU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+36,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xaU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xeU)))))),6);
        tracep->fullCData(oldp+37,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x18U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+38,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x14U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+39,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
        tracep->fullCData(oldp+40,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xcU)))))),6);
        tracep->fullCData(oldp+41,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xaU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xeU)))))),6);
        tracep->fullCData(oldp+42,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xcU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+43,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+44,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 8U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x10U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x14U)))))),6);
        tracep->fullCData(oldp+45,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 8U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+46,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+47,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+48,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x14U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+49,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+50,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x14U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+51,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 8U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x12U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+52,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xaU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x12U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+53,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
        tracep->fullCData(oldp+54,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x14U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+55,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
        tracep->fullCData(oldp+56,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x10U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+57,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xcU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+58,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x14U)))))),6);
        tracep->fullCData(oldp+59,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x1aU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x1aU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+60,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x18U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+61,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xaU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x12U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
        tracep->fullCData(oldp+62,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x10U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+63,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+64,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x18U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+65,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((4U & vlTOPp->logicnet__DOT__M0w) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
        tracep->fullCData(oldp+66,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
        tracep->fullCData(oldp+67,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xeU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x14U)))))),6);
        tracep->fullCData(oldp+68,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x16U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x16U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
        tracep->fullCData(oldp+69,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xcU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+70,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xcU)))))),6);
        tracep->fullCData(oldp+71,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((4U & vlTOPp->logicnet__DOT__M0w) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+72,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 6U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x10U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+73,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 8U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xcU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+74,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0xaU)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+75,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 2U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+76,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
        tracep->fullCData(oldp+77,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x10U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
        tracep->fullCData(oldp+78,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              << 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x12U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
        tracep->fullCData(oldp+79,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x10U)))))),6);
        tracep->fullCData(oldp+80,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 0x14U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
        tracep->fullCData(oldp+81,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 4U)) 
                                    | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                              >> 8U)) 
                                       | ((4U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | (3U & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xeU)))))),6);
        tracep->fullCData(oldp+82,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r),2);
        tracep->fullCData(oldp+83,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r),2);
        tracep->fullCData(oldp+84,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r),2);
        tracep->fullCData(oldp+85,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r),2);
        tracep->fullCData(oldp+86,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r),2);
        tracep->fullCData(oldp+87,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r),2);
        tracep->fullCData(oldp+88,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r),2);
        tracep->fullCData(oldp+89,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r),2);
        tracep->fullCData(oldp+90,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r),2);
        tracep->fullCData(oldp+91,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r),2);
        tracep->fullCData(oldp+92,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r),2);
        tracep->fullCData(oldp+93,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r),2);
        tracep->fullCData(oldp+94,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r),2);
        tracep->fullCData(oldp+95,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r),2);
        tracep->fullCData(oldp+96,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r),2);
        tracep->fullCData(oldp+97,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r),2);
        tracep->fullCData(oldp+98,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r),2);
        tracep->fullCData(oldp+99,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r),2);
        tracep->fullCData(oldp+100,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r),2);
        tracep->fullCData(oldp+101,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r),2);
        tracep->fullCData(oldp+102,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r),2);
        tracep->fullCData(oldp+103,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r),2);
        tracep->fullCData(oldp+104,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r),2);
        tracep->fullCData(oldp+105,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r),2);
        tracep->fullCData(oldp+106,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r),2);
        tracep->fullCData(oldp+107,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r),2);
        tracep->fullCData(oldp+108,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r),2);
        tracep->fullCData(oldp+109,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r),2);
        tracep->fullCData(oldp+110,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r),2);
        tracep->fullCData(oldp+111,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r),2);
        tracep->fullCData(oldp+112,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r),2);
        tracep->fullCData(oldp+113,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r),2);
        tracep->fullCData(oldp+114,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r),2);
        tracep->fullCData(oldp+115,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r),2);
        tracep->fullCData(oldp+116,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r),2);
        tracep->fullCData(oldp+117,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r),2);
        tracep->fullCData(oldp+118,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r),2);
        tracep->fullCData(oldp+119,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r),2);
        tracep->fullCData(oldp+120,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r),2);
        tracep->fullCData(oldp+121,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r),2);
        tracep->fullCData(oldp+122,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r),2);
        tracep->fullCData(oldp+123,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r),2);
        tracep->fullCData(oldp+124,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r),2);
        tracep->fullCData(oldp+125,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r),2);
        tracep->fullCData(oldp+126,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r),2);
        tracep->fullCData(oldp+127,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r),2);
        tracep->fullCData(oldp+128,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r),2);
        tracep->fullCData(oldp+129,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r),2);
        tracep->fullCData(oldp+130,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r),2);
        tracep->fullCData(oldp+131,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r),2);
        tracep->fullCData(oldp+132,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r),2);
        tracep->fullCData(oldp+133,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r),2);
        tracep->fullCData(oldp+134,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r),2);
        tracep->fullCData(oldp+135,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r),2);
        tracep->fullCData(oldp+136,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r),2);
        tracep->fullCData(oldp+137,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r),2);
        tracep->fullCData(oldp+138,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r),2);
        tracep->fullCData(oldp+139,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r),2);
        tracep->fullCData(oldp+140,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r),2);
        tracep->fullCData(oldp+141,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r),2);
        tracep->fullCData(oldp+142,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r),2);
        tracep->fullCData(oldp+143,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r),2);
        tracep->fullCData(oldp+144,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r),2);
        tracep->fullCData(oldp+145,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r),2);
        tracep->fullCData(oldp+146,(((0x30U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               << 2U)) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 0x1aU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1aU)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0xaU) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x16U))))))),6);
        tracep->fullCData(oldp+147,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x1aU) 
                                               | (0x3fffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 6U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 0x14U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x14U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0xaU) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x16U))))))),6);
        tracep->fullCData(oldp+148,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0x1aU) 
                                               | (0x3fffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 6U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 0x14U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x14U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x12U)))))),6);
        tracep->fullCData(oldp+149,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0x1aU) 
                                               | (0x3fffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 6U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 0x1cU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1cU)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0x14U) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xcU))))))),6);
        tracep->fullCData(oldp+150,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               << 2U)) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               >> 0xeU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0xeU)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 6U) 
                                               | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x1aU))))))),6);
        tracep->fullCData(oldp+151,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x1cU) 
                                               | (0xffffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 4U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               << 2U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  << 2U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 8U)))))),6);
        tracep->fullCData(oldp+152,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0x1cU) 
                                               | (0xffffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 4U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 0xaU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xaU)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x12U)))))),6);
        tracep->fullCData(oldp+153,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0x1cU) 
                                               | (0xffffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 4U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               >> 8U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 8U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x18U) 
                                               | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 8U))))))),6);
        tracep->fullCData(oldp+154,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0x14U) 
                                               | (0xffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0xcU)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 4U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 4U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 8U)))))),6);
        tracep->fullCData(oldp+155,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 8U) 
                                               | (0xf0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x18U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 0x1aU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1aU)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x1aU)))))),6);
        tracep->fullCData(oldp+156,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x12U) 
                                               | (0x3fff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0xeU)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 0xeU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xeU)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 8U) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x18U))))))),6);
        tracep->fullCData(oldp+157,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x1cU) 
                                               | (0xffffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 4U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 0x10U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x10U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0x12U) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xeU))))))),6);
        tracep->fullCData(oldp+158,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x1cU) 
                                               | (0xffffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 4U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x12U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x12U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x1aU)))))),6);
        tracep->fullCData(oldp+159,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0xaU) 
                                               | (0x3f0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0x16U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 2U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 2U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0xeU)))))),6);
        tracep->fullCData(oldp+160,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0xcU) 
                                               | (0xff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0x14U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 4U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 4U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x1cU)))))),6);
        tracep->fullCData(oldp+161,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0x12U) 
                                               | (0x3fff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0xeU)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               >> 0x1aU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x1aU)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 8U) 
                                               | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x18U))))))),6);
        tracep->fullCData(oldp+162,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0xcU) 
                                               | (0xff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x14U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 6U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 6U)) 
                                           | (3U & 
                                              vlTOPp->logicnet__DOT__M1w[3U]))))),6);
        tracep->fullCData(oldp+163,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x12U) 
                                               | (0x3fff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0xeU)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 0x1cU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1cU)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0xeU)))))),6);
        tracep->fullCData(oldp+164,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x12U) 
                                               | (0x3fff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0xeU)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 0xaU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xaU)) 
                                           | (3U & 
                                              vlTOPp->logicnet__DOT__M1w[3U]))))),6);
        tracep->fullCData(oldp+165,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0x1aU) 
                                               | (0x3fffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 6U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               >> 0x1aU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x1aU)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 8U) 
                                               | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x18U))))))),6);
        tracep->fullCData(oldp+166,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               << 2U)) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 0x12U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x12U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0x12U) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xeU))))))),6);
        tracep->fullCData(oldp+167,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x16U) 
                                               | (0x3ffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0xaU)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x16U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x16U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x1aU)))))),6);
        tracep->fullCData(oldp+168,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0xeU) 
                                               | (0x3ff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x12U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 8U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 8U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0xcU)))))),6);
        tracep->fullCData(oldp+169,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0xaU) 
                                               | (0x3f0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 0x16U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 6U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 6U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x12U)))))),6);
        tracep->fullCData(oldp+170,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0xcU) 
                                               | (0xff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x14U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 0x10U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x10U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 6U) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x1aU))))))),6);
        tracep->fullCData(oldp+171,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               << 4U)) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                               >> 6U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 6U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 8U) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x18U))))))),6);
        tracep->fullCData(oldp+172,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0x1aU) 
                                               | (0x3fffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 6U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               >> 0x14U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x14U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                << 0x16U) 
                                               | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xaU))))))),6);
        tracep->fullCData(oldp+173,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0xaU) 
                                               | (0x3f0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x16U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 0xcU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xcU)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x1eU)))))),6);
        tracep->fullCData(oldp+174,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 0x18U) 
                                               | (0xfffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 8U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 6U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 6U)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x10U)))))),6);
        tracep->fullCData(oldp+175,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 8U) 
                                               | (0xf0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x18U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                               >> 0x1cU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x1cU)) 
                                           | (3U & 
                                              (vlTOPp->logicnet__DOT__M1w[3U] 
                                               >> 0x18U)))))),6);
        tracep->fullCData(oldp+176,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               << 2U)) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               >> 6U)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 6U)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0xcU) 
                                               | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x14U))))))),6);
        tracep->fullCData(oldp+177,(((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                << 0x1aU) 
                                               | (0x3fffff0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 6U)))) 
                                     | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                               >> 0xcU)) 
                                        | ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0xcU)) 
                                           | (3U & 
                                              ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 8U) 
                                               | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x18U))))))),6);
        tracep->fullCData(oldp+178,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r),2);
        tracep->fullCData(oldp+179,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r),2);
        tracep->fullCData(oldp+180,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r),2);
        tracep->fullCData(oldp+181,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r),2);
        tracep->fullCData(oldp+182,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r),2);
        tracep->fullCData(oldp+183,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r),2);
        tracep->fullCData(oldp+184,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r),2);
        tracep->fullCData(oldp+185,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r),2);
        tracep->fullCData(oldp+186,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r),2);
        tracep->fullCData(oldp+187,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r),2);
        tracep->fullCData(oldp+188,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r),2);
        tracep->fullCData(oldp+189,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r),2);
        tracep->fullCData(oldp+190,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r),2);
        tracep->fullCData(oldp+191,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r),2);
        tracep->fullCData(oldp+192,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r),2);
        tracep->fullCData(oldp+193,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r),2);
        tracep->fullCData(oldp+194,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r),2);
        tracep->fullCData(oldp+195,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r),2);
        tracep->fullCData(oldp+196,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r),2);
        tracep->fullCData(oldp+197,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r),2);
        tracep->fullCData(oldp+198,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r),2);
        tracep->fullCData(oldp+199,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r),2);
        tracep->fullCData(oldp+200,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r),2);
        tracep->fullCData(oldp+201,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r),2);
        tracep->fullCData(oldp+202,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r),2);
        tracep->fullCData(oldp+203,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r),2);
        tracep->fullCData(oldp+204,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r),2);
        tracep->fullCData(oldp+205,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r),2);
        tracep->fullCData(oldp+206,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r),2);
        tracep->fullCData(oldp+207,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r),2);
        tracep->fullCData(oldp+208,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r),2);
        tracep->fullCData(oldp+209,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r),2);
        tracep->fullCData(oldp+210,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x20U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x24U))))))),6);
        tracep->fullCData(oldp+211,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x1cU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x2bU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2aU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
        tracep->fullCData(oldp+212,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x35U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x34U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+213,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x18U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x39U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x38U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3aU))))))),6);
        tracep->fullCData(oldp+214,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 9U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 8U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x26U))))))),6);
        tracep->fullCData(oldp+215,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x12U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x1dU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1cU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x20U))))))),6);
        tracep->fullCData(oldp+216,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xaU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xfU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xeU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x1cU))))))),6);
        tracep->fullCData(oldp+217,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x12U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x14U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
        tracep->fullCData(oldp+218,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x17U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x16U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
        tracep->fullCData(oldp+219,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x20U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x25U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x24U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
        tracep->fullCData(oldp+220,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x10U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x13U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x12U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2cU))))))),6);
        tracep->fullCData(oldp+221,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x18U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x2fU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2eU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x36U))))))),6);
        tracep->fullCData(oldp+222,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x38U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x3bU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x3aU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
        tracep->fullCData(oldp+223,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xeU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x1dU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1cU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x1eU))))))),6);
        tracep->fullCData(oldp+224,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x18U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x2bU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2aU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
        tracep->fullCData(oldp+225,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x10U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x1dU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1cU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+226,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 9U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 8U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2eU))))))),6);
        tracep->fullCData(oldp+227,(((0x30U & ((IData)(vlTOPp->logicnet__DOT__M2w) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x38U))))))),6);
        tracep->fullCData(oldp+228,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x16U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x25U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x24U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2eU))))))),6);
        tracep->fullCData(oldp+229,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xeU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x16U))))))),6);
        tracep->fullCData(oldp+230,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 2U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x14U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x36U))))))),6);
        tracep->fullCData(oldp+231,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x25U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x24U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
        tracep->fullCData(oldp+232,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x16U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x29U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x28U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2cU))))))),6);
        tracep->fullCData(oldp+233,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 2U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 9U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 8U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x14U))))))),6);
        tracep->fullCData(oldp+234,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xdU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xcU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
        tracep->fullCData(oldp+235,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 8U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xbU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xaU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x36U))))))),6);
        tracep->fullCData(oldp+236,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 8U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x2bU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2aU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
        tracep->fullCData(oldp+237,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x14U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x29U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x28U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+238,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x18U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x29U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x28U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2cU))))))),6);
        tracep->fullCData(oldp+239,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x1bU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1aU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x30U))))))),6);
        tracep->fullCData(oldp+240,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x1aU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x20U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
        tracep->fullCData(oldp+241,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M2w 
                                                        >> 0xbU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xaU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x1cU))))))),6);
        tracep->fullCData(oldp+242,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r),2);
        tracep->fullCData(oldp+243,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r),2);
        tracep->fullCData(oldp+244,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r),2);
        tracep->fullCData(oldp+245,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r),2);
        tracep->fullCData(oldp+246,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r),2);
        tracep->fullCData(oldp+247,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r),2);
        tracep->fullCData(oldp+248,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r),2);
        tracep->fullCData(oldp+249,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r),2);
        tracep->fullCData(oldp+250,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r),2);
        tracep->fullCData(oldp+251,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r),2);
        tracep->fullCData(oldp+252,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r),2);
        tracep->fullCData(oldp+253,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r),2);
        tracep->fullCData(oldp+254,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r),2);
        tracep->fullCData(oldp+255,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r),2);
        tracep->fullCData(oldp+256,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r),2);
        tracep->fullCData(oldp+257,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r),2);
        tracep->fullCData(oldp+258,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r),2);
        tracep->fullCData(oldp+259,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r),2);
        tracep->fullCData(oldp+260,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r),2);
        tracep->fullCData(oldp+261,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r),2);
        tracep->fullCData(oldp+262,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r),2);
        tracep->fullCData(oldp+263,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r),2);
        tracep->fullCData(oldp+264,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r),2);
        tracep->fullCData(oldp+265,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r),2);
        tracep->fullCData(oldp+266,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r),2);
        tracep->fullCData(oldp+267,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r),2);
        tracep->fullCData(oldp+268,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r),2);
        tracep->fullCData(oldp+269,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r),2);
        tracep->fullCData(oldp+270,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r),2);
        tracep->fullCData(oldp+271,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r),2);
        tracep->fullCData(oldp+272,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r),2);
        tracep->fullCData(oldp+273,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r),2);
        tracep->fullCData(oldp+274,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xeU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1dU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1cU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
        tracep->fullCData(oldp+275,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 8U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1fU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1eU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x32U))))))),6);
        tracep->fullCData(oldp+276,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x14U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x20U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x26U))))))),6);
        tracep->fullCData(oldp+277,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1cU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x29U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x28U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+278,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x12U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x37U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x36U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x38U))))))),6);
        tracep->fullCData(oldp+279,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x27U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x26U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
        tracep->fullCData(oldp+280,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 8U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x14U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x16U))))))),6);
        tracep->fullCData(oldp+281,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 8U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x13U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x12U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
        tracep->fullCData(oldp+282,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+283,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
        tracep->fullCData(oldp+284,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1cU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x20U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+285,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x18U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x29U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x28U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x34U))))))),6);
        tracep->fullCData(oldp+286,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xbU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xaU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
        tracep->fullCData(oldp+287,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x13U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x12U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x16U))))))),6);
        tracep->fullCData(oldp+288,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x12U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x29U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x28U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x36U))))))),6);
        tracep->fullCData(oldp+289,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1dU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1cU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+290,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x16U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x27U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x26U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x38U))))))),6);
        tracep->fullCData(oldp+291,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xaU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x13U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x12U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x26U))))))),6);
        tracep->fullCData(oldp+292,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x33U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x32U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x34U))))))),6);
        tracep->fullCData(oldp+293,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x30U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x39U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x38U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3aU))))))),6);
        tracep->fullCData(oldp+294,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1fU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1eU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x24U))))))),6);
        tracep->fullCData(oldp+295,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x18U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x20U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
        tracep->fullCData(oldp+296,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1fU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1eU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+297,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 2U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x15U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x14U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x1cU))))))),6);
        tracep->fullCData(oldp+298,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x10U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x2bU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x2aU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x36U))))))),6);
        tracep->fullCData(oldp+299,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 2U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xfU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xeU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x2eU))))))),6);
        tracep->fullCData(oldp+300,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3cU))))))),6);
        tracep->fullCData(oldp+301,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 6U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x21U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x20U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
        tracep->fullCData(oldp+302,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1cU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x1fU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1eU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x38U))))))),6);
        tracep->fullCData(oldp+303,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xdU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xcU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x1eU))))))),6);
        tracep->fullCData(oldp+304,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x16U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x2dU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x2cU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
        tracep->fullCData(oldp+305,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M3w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
        tracep->fullCData(oldp+306,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r),2);
        tracep->fullCData(oldp+307,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r),2);
        tracep->fullCData(oldp+308,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r),2);
        tracep->fullCData(oldp+309,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r),2);
        tracep->fullCData(oldp+310,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r),2);
        tracep->fullCData(oldp+311,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r),2);
        tracep->fullCData(oldp+312,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r),2);
        tracep->fullCData(oldp+313,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r),2);
        tracep->fullCData(oldp+314,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r),2);
        tracep->fullCData(oldp+315,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r),2);
        tracep->fullCData(oldp+316,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r),2);
        tracep->fullCData(oldp+317,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r),2);
        tracep->fullCData(oldp+318,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r),2);
        tracep->fullCData(oldp+319,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r),2);
        tracep->fullCData(oldp+320,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r),2);
        tracep->fullCData(oldp+321,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r),2);
        tracep->fullCData(oldp+322,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r),2);
        tracep->fullCData(oldp+323,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r),2);
        tracep->fullCData(oldp+324,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r),2);
        tracep->fullCData(oldp+325,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r),2);
        tracep->fullCData(oldp+326,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r),2);
        tracep->fullCData(oldp+327,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r),2);
        tracep->fullCData(oldp+328,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r),2);
        tracep->fullCData(oldp+329,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r),2);
        tracep->fullCData(oldp+330,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r),2);
        tracep->fullCData(oldp+331,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r),2);
        tracep->fullCData(oldp+332,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r),2);
        tracep->fullCData(oldp+333,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r),2);
        tracep->fullCData(oldp+334,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r),2);
        tracep->fullCData(oldp+335,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r),2);
        tracep->fullCData(oldp+336,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r),2);
        tracep->fullCData(oldp+337,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r),2);
        tracep->fullCData(oldp+338,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 0xdU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0xcU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x24U))))))),6);
        tracep->fullCData(oldp+339,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 4U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 0x29U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x28U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+340,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 0xcU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 0x2dU)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x2cU)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3aU))))))),6);
        tracep->fullCData(oldp+341,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 8U)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+342,(((0x30U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 0xeU)) 
                                               << 4U)) 
                                     | ((8U & ((IData)(
                                                       (vlTOPp->logicnet__DOT__M4w 
                                                        >> 0x11U)) 
                                               << 3U)) 
                                        | ((4U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x10U)) 
                                                  << 2U)) 
                                           | (3U & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3eU))))))),6);
        tracep->fullCData(oldp+343,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r),3);
        tracep->fullCData(oldp+344,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r),3);
        tracep->fullCData(oldp+345,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r),3);
        tracep->fullCData(oldp+346,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r),3);
        tracep->fullCData(oldp+347,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r),3);
        tracep->fullIData(oldp+348,(vlTOPp->M0),32);
        tracep->fullBit(oldp+349,(vlTOPp->clk));
        tracep->fullBit(oldp+350,(vlTOPp->rst));
        tracep->fullSData(oldp+351,(vlTOPp->M5),15);
        tracep->fullIData(oldp+352,(0x20U),32);
        tracep->fullIData(oldp+353,(0x80U),32);
        tracep->fullIData(oldp+354,(0x40U),32);
    }
}
