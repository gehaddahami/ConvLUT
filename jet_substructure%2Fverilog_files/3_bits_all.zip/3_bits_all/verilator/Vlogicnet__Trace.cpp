// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vlogicnet__Syms.h"


void Vlogicnet::traceChgTop0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    {
        vlTOPp->traceChgSub0(userp, tracep);
    }
}

void Vlogicnet::traceChgSub0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    vluint32_t* const oldp = tracep->oldp(vlSymsp->__Vm_baseCode + 1);
    if (false && oldp) {}  // Prevent unused
    // Body
    {
        if (VL_UNLIKELY(vlTOPp->__Vm_traceActivity[1U])) {
            tracep->chgQData(oldp+0,(vlTOPp->logicnet__DOT__M0w),48);
            tracep->chgWData(oldp+2,(vlTOPp->logicnet__DOT__M1),192);
            tracep->chgWData(oldp+8,(vlTOPp->logicnet__DOT__M1w),192);
            tracep->chgWData(oldp+14,(vlTOPp->logicnet__DOT__M2),96);
            tracep->chgWData(oldp+17,(vlTOPp->logicnet__DOT__M2w),96);
            tracep->chgWData(oldp+20,(vlTOPp->logicnet__DOT__M3),96);
            tracep->chgWData(oldp+23,(vlTOPp->logicnet__DOT__M3w),96);
            tracep->chgWData(oldp+26,(vlTOPp->logicnet__DOT__M4),96);
            tracep->chgWData(oldp+29,(vlTOPp->logicnet__DOT__M4w),96);
            tracep->chgSData(oldp+32,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+33,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x11U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x10U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xfU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+34,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x17U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x16U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x15U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+35,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x1bU)))))))),9);
            tracep->chgSData(oldp+36,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x24U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x29U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x28U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x27U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+37,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xcU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x11U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x10U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xfU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x1bU)))))))),9);
            tracep->chgSData(oldp+38,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x15U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x20U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1fU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1eU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+39,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 9U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xeU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xdU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xcU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x12U)))))))),9);
            tracep->chgSData(oldp+40,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xcU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x26U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x25U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x24U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+41,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x23U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x22U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x21U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+42,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xcU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+43,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xeU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xdU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xcU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+44,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x17U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x16U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x15U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+45,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xfU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x14U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x13U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x12U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+46,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xfU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x14U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x13U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x12U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x15U)))))))),9);
            tracep->chgSData(oldp+47,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x29U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x28U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x27U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+48,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xfU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x23U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x22U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x21U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+49,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x21U)))))))),9);
            tracep->chgSData(oldp+50,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xbU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xaU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 9U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x12U)))))))),9);
            tracep->chgSData(oldp+51,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 9U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x14U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x13U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x12U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x15U)))))))),9);
            tracep->chgSData(oldp+52,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x17U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x16U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x15U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+53,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xcU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+54,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1dU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1cU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1bU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x1eU)))))))),9);
            tracep->chgSData(oldp+55,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x11U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x10U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xfU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+56,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xeU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xdU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xcU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+57,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+58,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x23U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x22U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x21U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+59,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xfU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+60,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x23U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x22U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x21U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+61,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x20U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1fU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1eU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+62,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x15U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x20U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1fU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1eU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+63,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 8U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 7U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 6U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x21U)))))))),9);
            tracep->chgSData(oldp+64,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x23U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x22U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x21U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+65,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xeU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xdU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xcU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x21U)))))))),9);
            tracep->chgSData(oldp+66,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1dU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1cU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1bU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+67,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xfU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x17U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x16U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x15U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+68,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x1eU)))))))),9);
            tracep->chgSData(oldp+69,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xfU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x2cU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x2bU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x2aU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+70,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x29U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x28U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x27U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+71,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x15U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x20U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1fU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1eU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x21U)))))))),9);
            tracep->chgSData(oldp+72,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1dU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1cU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1bU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+73,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 3U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 8U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 7U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 6U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+74,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1bU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x29U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x28U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x27U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+75,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 5U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 4U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 3U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x21U)))))))),9);
            tracep->chgSData(oldp+76,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 9U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xeU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xdU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xcU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x1bU)))))))),9);
            tracep->chgSData(oldp+77,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 9U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1aU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x19U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x18U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x1eU)))))))),9);
            tracep->chgSData(oldp+78,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x26U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x25U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x24U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2dU)))))))),9);
            tracep->chgSData(oldp+79,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x17U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x16U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x15U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+80,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 8U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 7U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 6U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x12U)))))))),9);
            tracep->chgSData(oldp+81,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 5U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 4U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 3U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+82,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xfU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1dU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1cU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1bU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+83,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x17U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x16U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x15U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+84,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 9U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x14U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x13U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x12U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+85,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 8U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 7U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 6U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+86,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xbU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xaU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 9U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x1bU)))))))),9);
            tracep->chgSData(oldp+87,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xcU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x1dU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1cU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1bU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x27U)))))))),9);
            tracep->chgSData(oldp+88,(((0x1c0U & ((IData)(vlTOPp->logicnet__DOT__M0w) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x20U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1fU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x1eU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x2aU)))))))),9);
            tracep->chgSData(oldp+89,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xbU)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xaU)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 9U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x18U)))))))),9);
            tracep->chgSData(oldp+90,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 6U)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x23U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x22U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0x21U)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x24U)))))))),9);
            tracep->chgSData(oldp+91,(((0x1c0U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xcU)) 
                                                  << 6U)) 
                                       | ((0x20U & 
                                           ((IData)(
                                                    (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x11U)) 
                                            << 5U)) 
                                          | ((0x10U 
                                              & ((IData)(
                                                         (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x10U)) 
                                                 << 4U)) 
                                             | ((8U 
                                                 & ((IData)(
                                                            (vlTOPp->logicnet__DOT__M0w 
                                                             >> 0xfU)) 
                                                    << 3U)) 
                                                | (7U 
                                                   & (IData)(
                                                             (vlTOPp->logicnet__DOT__M0w 
                                                              >> 0x15U)))))))),9);
            tracep->chgCData(oldp+92,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r),3);
            tracep->chgCData(oldp+93,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r),3);
            tracep->chgCData(oldp+94,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r),3);
            tracep->chgCData(oldp+95,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r),3);
            tracep->chgCData(oldp+96,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r),3);
            tracep->chgCData(oldp+97,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r),3);
            tracep->chgCData(oldp+98,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r),3);
            tracep->chgCData(oldp+99,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r),3);
            tracep->chgCData(oldp+100,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r),3);
            tracep->chgCData(oldp+101,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r),3);
            tracep->chgCData(oldp+102,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r),3);
            tracep->chgCData(oldp+103,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r),3);
            tracep->chgCData(oldp+104,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r),3);
            tracep->chgCData(oldp+105,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r),3);
            tracep->chgCData(oldp+106,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r),3);
            tracep->chgCData(oldp+107,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r),3);
            tracep->chgCData(oldp+108,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r),3);
            tracep->chgCData(oldp+109,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r),3);
            tracep->chgCData(oldp+110,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r),3);
            tracep->chgCData(oldp+111,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r),3);
            tracep->chgCData(oldp+112,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r),3);
            tracep->chgCData(oldp+113,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r),3);
            tracep->chgCData(oldp+114,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r),3);
            tracep->chgCData(oldp+115,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r),3);
            tracep->chgCData(oldp+116,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r),3);
            tracep->chgCData(oldp+117,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r),3);
            tracep->chgCData(oldp+118,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r),3);
            tracep->chgCData(oldp+119,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r),3);
            tracep->chgCData(oldp+120,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r),3);
            tracep->chgCData(oldp+121,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r),3);
            tracep->chgCData(oldp+122,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r),3);
            tracep->chgCData(oldp+123,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r),3);
            tracep->chgCData(oldp+124,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r),3);
            tracep->chgCData(oldp+125,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r),3);
            tracep->chgCData(oldp+126,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r),3);
            tracep->chgCData(oldp+127,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r),3);
            tracep->chgCData(oldp+128,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r),3);
            tracep->chgCData(oldp+129,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r),3);
            tracep->chgCData(oldp+130,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r),3);
            tracep->chgCData(oldp+131,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r),3);
            tracep->chgCData(oldp+132,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r),3);
            tracep->chgCData(oldp+133,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r),3);
            tracep->chgCData(oldp+134,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r),3);
            tracep->chgCData(oldp+135,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r),3);
            tracep->chgCData(oldp+136,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r),3);
            tracep->chgCData(oldp+137,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r),3);
            tracep->chgCData(oldp+138,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r),3);
            tracep->chgCData(oldp+139,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r),3);
            tracep->chgCData(oldp+140,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r),3);
            tracep->chgCData(oldp+141,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r),3);
            tracep->chgCData(oldp+142,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r),3);
            tracep->chgCData(oldp+143,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r),3);
            tracep->chgCData(oldp+144,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r),3);
            tracep->chgCData(oldp+145,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r),3);
            tracep->chgCData(oldp+146,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r),3);
            tracep->chgCData(oldp+147,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r),3);
            tracep->chgCData(oldp+148,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r),3);
            tracep->chgCData(oldp+149,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r),3);
            tracep->chgCData(oldp+150,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r),3);
            tracep->chgCData(oldp+151,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r),3);
            tracep->chgCData(oldp+152,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r),3);
            tracep->chgCData(oldp+153,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r),3);
            tracep->chgCData(oldp+154,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r),3);
            tracep->chgCData(oldp+155,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r),3);
            tracep->chgSData(oldp+156,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 0x13U) 
                                                   | (0x7ffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 0xdU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x17U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 0x17U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 0x1fU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 1U)))))))),9);
            tracep->chgSData(oldp+157,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 7U) 
                                                   | (0x40U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 0x19U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xeU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xeU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 0xeU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 0x1fU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 1U)))))))),9);
            tracep->chgSData(oldp+158,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[4U] 
                                                    << 0x17U) 
                                                   | (0x7fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                         >> 9U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             << 2U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                     << 2U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+159,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[1U] 
                                                    << 0x17U) 
                                                   | (0x7fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 9U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x1aU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 0x1aU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                        << 0xeU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                          >> 0x12U)))))))),9);
            tracep->chgSData(oldp+160,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[0U] 
                                                   << 3U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                        << 0x19U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                          >> 7U)))))))),9);
            tracep->chgSData(oldp+161,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 0xaU) 
                                                   | (0x3c0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 0x16U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             << 3U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  << 3U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 3U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+162,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[4U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0xfU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     >> 0xfU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+163,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[1U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0xcU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0xcU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0xcU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+164,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[1U] 
                                                    << 0xeU) 
                                                   | (0x3fc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 0x12U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 6U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 6U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     >> 6U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+165,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 0x1cU) 
                                                   | (0xfffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 4U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x17U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x17U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 0x17U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0x17U))))))),9);
            tracep->chgSData(oldp+166,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    << 0x1bU) 
                                                   | (0x7ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                         >> 5U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 0x1cU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 4U)))))))),9);
            tracep->chgSData(oldp+167,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 0xaU) 
                                                   | (0x3c0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 0x16U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 8U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 8U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 8U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                        << 0xbU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                          >> 0x15U)))))))),9);
            tracep->chgSData(oldp+168,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 0xaU) 
                                                   | (0x3c0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 0x16U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 0xbU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                  >> 0xbU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                     >> 0xbU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0x17U))))))),9);
            tracep->chgSData(oldp+169,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    << 0xfU) 
                                                   | (0x7fc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                         >> 0x11U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 3U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 3U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     >> 3U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 5U))))))),9);
            tracep->chgSData(oldp+170,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    << 0x12U) 
                                                   | (0x3ffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                         >> 0xeU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x16U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0x16U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                     >> 0x16U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0x1aU))))))),9);
            tracep->chgSData(oldp+171,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[1U] 
                                                    << 0xbU) 
                                                   | (0x7c0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 0x15U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 7U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 7U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 7U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                        << 0xcU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                          >> 0x14U)))))))),9);
            tracep->chgSData(oldp+172,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 0x10U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 0x10U)))))))),9);
            tracep->chgSData(oldp+173,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    << 0x1bU) 
                                                   | (0x7ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                         >> 5U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x1aU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x1aU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 0x1aU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 5U))))))),9);
            tracep->chgSData(oldp+174,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    << 0x1bU) 
                                                   | (0x7ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                         >> 5U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0xfU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0xfU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     >> 0xfU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 0x10U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 0x10U)))))))),9);
            tracep->chgSData(oldp+175,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[1U] 
                                                    << 0x17U) 
                                                   | (0x7fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 9U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 7U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 7U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 7U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                        << 0xcU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                          >> 0x14U)))))))),9);
            tracep->chgSData(oldp+176,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[0U] 
                                                   << 3U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xbU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xbU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                     >> 0xbU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                        << 0xbU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                          >> 0x15U)))))))),9);
            tracep->chgSData(oldp+177,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 1U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[5U] 
                                             >> 0x11U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                  >> 0x11U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                     >> 0x11U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0x17U))))))),9);
            tracep->chgSData(oldp+178,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 5U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[2U] 
                                             << 4U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  << 4U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0x1cU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 2U))))))),9);
            tracep->chgSData(oldp+179,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[5U] 
                                                    << 0x1fU) 
                                                   | (0x7fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                         >> 1U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+180,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x18U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x18U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     >> 0x18U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 0x19U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 7U)))))))),9);
            tracep->chgSData(oldp+181,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[0U] 
                                                   << 6U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[5U] 
                                                        << 0x1cU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[4U] 
                                                          >> 4U)))))))),9);
            tracep->chgSData(oldp+182,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[1U] 
                                                    << 0x17U) 
                                                   | (0x7fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 9U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[1U] 
                                             << 2U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                     << 2U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[4U] 
                                                        << 0x11U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[3U] 
                                                          >> 0xfU)))))))),9);
            tracep->chgSData(oldp+183,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 0x1fU) 
                                                   | (0x7fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 1U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[3U] 
                                             >> 0x12U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x12U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                     >> 0x12U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+184,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 4U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 8U))))))),9);
            tracep->chgSData(oldp+185,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[2U] 
                                                    << 0x1cU) 
                                                   | (0xfffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 4U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[4U] 
                                             >> 0xaU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                  >> 0xaU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[4U] 
                                                     >> 0xaU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M1w[5U] 
                                                       >> 0x14U))))))),9);
            tracep->chgSData(oldp+186,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M1w[0U] 
                                                   << 3U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 9U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 9U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 9U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                        << 2U) 
                                                       | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                          >> 0x1eU)))))))),9);
            tracep->chgSData(oldp+187,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M1w[1U] 
                                                    << 0x17U) 
                                                   | (0x7fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 9U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M1w[0U] 
                                             >> 0x12U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x12U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x12U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                        << 0xcU) 
                                                       | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                          >> 0x14U)))))))),9);
            tracep->chgCData(oldp+188,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r),3);
            tracep->chgCData(oldp+189,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r),3);
            tracep->chgCData(oldp+190,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r),3);
            tracep->chgCData(oldp+191,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r),3);
            tracep->chgCData(oldp+192,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r),3);
            tracep->chgCData(oldp+193,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r),3);
            tracep->chgCData(oldp+194,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r),3);
            tracep->chgCData(oldp+195,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r),3);
            tracep->chgCData(oldp+196,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r),3);
            tracep->chgCData(oldp+197,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r),3);
            tracep->chgCData(oldp+198,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r),3);
            tracep->chgCData(oldp+199,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r),3);
            tracep->chgCData(oldp+200,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r),3);
            tracep->chgCData(oldp+201,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r),3);
            tracep->chgCData(oldp+202,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r),3);
            tracep->chgCData(oldp+203,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r),3);
            tracep->chgCData(oldp+204,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r),3);
            tracep->chgCData(oldp+205,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r),3);
            tracep->chgCData(oldp+206,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r),3);
            tracep->chgCData(oldp+207,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r),3);
            tracep->chgCData(oldp+208,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r),3);
            tracep->chgCData(oldp+209,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r),3);
            tracep->chgCData(oldp+210,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r),3);
            tracep->chgCData(oldp+211,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r),3);
            tracep->chgCData(oldp+212,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r),3);
            tracep->chgCData(oldp+213,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r),3);
            tracep->chgCData(oldp+214,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r),3);
            tracep->chgCData(oldp+215,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r),3);
            tracep->chgCData(oldp+216,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r),3);
            tracep->chgCData(oldp+217,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r),3);
            tracep->chgCData(oldp+218,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r),3);
            tracep->chgCData(oldp+219,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r),3);
            tracep->chgSData(oldp+220,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0xdU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0xdU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0xdU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                        << 0xaU) 
                                                       | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                          >> 0x16U)))))))),9);
            tracep->chgSData(oldp+221,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    << 0x1cU) 
                                                   | (0xfffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                         >> 4U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             << 4U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  << 4U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x1cU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+222,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0xbU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 0xbU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                     >> 0xbU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+223,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0x11U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 0x11U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                     >> 0x11U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x17U))))))),9);
            tracep->chgSData(oldp+224,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 9U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 9U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 9U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                        << 7U) 
                                                       | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                          >> 0x19U)))))))),9);
            tracep->chgSData(oldp+225,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0xbU) 
                                                   | (0x7c0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0x15U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 7U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 7U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 7U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                        << 0x10U) 
                                                       | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                          >> 0x10U)))))))),9);
            tracep->chgSData(oldp+226,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x17U) 
                                                   | (0x7fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 9U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x12U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x12U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0x12U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                        << 0x16U) 
                                                       | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                          >> 0xaU)))))))),9);
            tracep->chgSData(oldp+227,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0xbU) 
                                                   | (0x7c0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0x15U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             << 5U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x1bU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0x1bU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+228,(((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             << 2U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     << 2U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+229,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    << 0x16U) 
                                                   | (0x3fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                         >> 0xaU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x13U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x13U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x13U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+230,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0xeU) 
                                                   | (0x3fc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0x12U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x18U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x18U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0x18U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 2U))))))),9);
            tracep->chgSData(oldp+231,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 2U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 2U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                     >> 2U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x11U))))))),9);
            tracep->chgSData(oldp+232,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[2U] 
                                                   >> 0xeU)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             >> 0x14U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  >> 0x14U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                     >> 0x14U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x1aU))))))),9);
            tracep->chgSData(oldp+233,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x11U) 
                                                   | (0x1ffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0xfU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 7U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 7U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 7U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                        << 0x13U) 
                                                       | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                          >> 0xdU)))))))),9);
            tracep->chgSData(oldp+234,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             << 4U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  << 4U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x1cU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+235,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0xeU) 
                                                   | (0x3fc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0x12U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 7U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 7U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 7U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+236,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 9U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 9U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 9U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 5U))))))),9);
            tracep->chgSData(oldp+237,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[0U] 
                                                   << 6U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x14U))))))),9);
            tracep->chgSData(oldp+238,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[1U] 
                                                   << 5U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x13U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x13U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x13U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 5U))))))),9);
            tracep->chgSData(oldp+239,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x11U) 
                                                   | (0x1ffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0xfU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                        << 0x1fU) 
                                                       | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                          >> 1U)))))))),9);
            tracep->chgSData(oldp+240,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[0U] 
                                                   << 3U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             << 5U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0x1bU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0x1bU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x11U))))))),9);
            tracep->chgSData(oldp+241,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x13U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x13U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x13U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x1aU))))))),9);
            tracep->chgSData(oldp+242,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[1U] 
                                                   << 5U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 2U))))))),9);
            tracep->chgSData(oldp+243,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[0U] 
                                                   << 3U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 9U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 9U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 9U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[1U] 
                                                        << 2U) 
                                                       | (vlTOPp->logicnet__DOT__M2w[0U] 
                                                          >> 0x1eU)))))))),9);
            tracep->chgSData(oldp+244,(((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0xfU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0xfU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0xfU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x1aU))))))),9);
            tracep->chgSData(oldp+245,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0xcU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0xcU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0xcU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x11U))))))),9);
            tracep->chgSData(oldp+246,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[2U] 
                                             << 4U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                  << 4U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x1cU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+247,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 8U) 
                                                   | (0xc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 0x18U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+248,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M2w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 2U))))))),9);
            tracep->chgSData(oldp+249,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 4U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 4U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 4U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 8U))))))),9);
            tracep->chgSData(oldp+250,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M2w[2U] 
                                                    << 0x1fU) 
                                                   | (0x7fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                         >> 1U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[1U] 
                                             >> 0xdU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                  >> 0xdU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[1U] 
                                                     >> 0xdU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M2w[2U] 
                                                       >> 0x1aU))))))),9);
            tracep->chgSData(oldp+251,(((0x1c0U & vlTOPp->logicnet__DOT__M2w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M2w[0U] 
                                             >> 0xcU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                  >> 0xcU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M2w[0U] 
                                                     >> 0xcU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M2w[2U] 
                                                        << 0x16U) 
                                                       | (vlTOPp->logicnet__DOT__M2w[1U] 
                                                          >> 0xaU)))))))),9);
            tracep->chgCData(oldp+252,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r),3);
            tracep->chgCData(oldp+253,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r),3);
            tracep->chgCData(oldp+254,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r),3);
            tracep->chgCData(oldp+255,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r),3);
            tracep->chgCData(oldp+256,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r),3);
            tracep->chgCData(oldp+257,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r),3);
            tracep->chgCData(oldp+258,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r),3);
            tracep->chgCData(oldp+259,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r),3);
            tracep->chgCData(oldp+260,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r),3);
            tracep->chgCData(oldp+261,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r),3);
            tracep->chgCData(oldp+262,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r),3);
            tracep->chgCData(oldp+263,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r),3);
            tracep->chgCData(oldp+264,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r),3);
            tracep->chgCData(oldp+265,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r),3);
            tracep->chgCData(oldp+266,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r),3);
            tracep->chgCData(oldp+267,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r),3);
            tracep->chgCData(oldp+268,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r),3);
            tracep->chgCData(oldp+269,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r),3);
            tracep->chgCData(oldp+270,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r),3);
            tracep->chgCData(oldp+271,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r),3);
            tracep->chgCData(oldp+272,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r),3);
            tracep->chgCData(oldp+273,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r),3);
            tracep->chgCData(oldp+274,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r),3);
            tracep->chgCData(oldp+275,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r),3);
            tracep->chgCData(oldp+276,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r),3);
            tracep->chgCData(oldp+277,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r),3);
            tracep->chgCData(oldp+278,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r),3);
            tracep->chgCData(oldp+279,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r),3);
            tracep->chgCData(oldp+280,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r),3);
            tracep->chgCData(oldp+281,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r),3);
            tracep->chgCData(oldp+282,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r),3);
            tracep->chgCData(oldp+283,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r),3);
            tracep->chgSData(oldp+284,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x11U) 
                                                   | (0x1ffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0xfU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 7U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 7U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 7U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+285,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xaU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0xbU))))))),9);
            tracep->chgSData(oldp+286,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 8U) 
                                                   | (0xc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0x18U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xdU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 7U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x19U)))))))),9);
            tracep->chgSData(oldp+287,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    << 0x1cU) 
                                                   | (0xfffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                         >> 4U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+288,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0xbU) 
                                                   | (0x7c0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0x15U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             >> 0xeU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  >> 0xeU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                     >> 0xeU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x14U))))))),9);
            tracep->chgSData(oldp+289,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x16U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x16U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0x16U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+290,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             << 5U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x1bU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x1bU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 0x1fU) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 1U)))))))),9);
            tracep->chgSData(oldp+291,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x18U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x18U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x18U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+292,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+293,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 8U))))))),9);
            tracep->chgSData(oldp+294,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    << 0x1cU) 
                                                   | (0xfffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                         >> 4U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xdU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+295,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M3w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0xeU))))))),9);
            tracep->chgSData(oldp+296,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0xcU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0xcU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0xcU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+297,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x18U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x18U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x18U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 0x1fU) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 1U)))))))),9);
            tracep->chgSData(oldp+298,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0xbU) 
                                                   | (0x7c0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0x15U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x11U))))))),9);
            tracep->chgSData(oldp+299,(((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 7U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 7U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 7U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+300,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M3w[1U] 
                                                   << 5U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0x16U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0x16U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0x16U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x14U))))))),9);
            tracep->chgSData(oldp+301,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x17U) 
                                                   | (0x7fffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 9U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x18U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x18U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x18U)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 7U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x19U)))))))),9);
            tracep->chgSData(oldp+302,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             >> 8U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  >> 8U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                     >> 8U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0xeU))))))),9);
            tracep->chgSData(oldp+303,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M3w[2U] 
                                                   >> 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             >> 0x11U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  >> 0x11U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                     >> 0x11U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x17U))))))),9);
            tracep->chgSData(oldp+304,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xaU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 0xaU) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x16U)))))))),9);
            tracep->chgSData(oldp+305,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M3w[1U] 
                                                   << 2U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xdU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 8U))))))),9);
            tracep->chgSData(oldp+306,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xaU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+307,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M3w[0U] 
                                                   << 3U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             << 5U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x1bU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x1bU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 0x16U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0xaU)))))))),9);
            tracep->chgSData(oldp+308,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0xeU) 
                                                   | (0x3fc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0x12U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             << 4U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  << 4U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0x1cU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x11U))))))),9);
            tracep->chgSData(oldp+309,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M3w[0U] 
                                                   << 3U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x12U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x12U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x12U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 5U))))))),9);
            tracep->chgSData(oldp+310,(((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x1aU))))))),9);
            tracep->chgSData(oldp+311,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x1dU) 
                                                   | (0x1fffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 3U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xdU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xdU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xdU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 4U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0x1cU)))))))),9);
            tracep->chgSData(oldp+312,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[2U] 
                                                    << 0x1cU) 
                                                   | (0xfffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                         >> 4U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[1U] 
                                             >> 0xaU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                  >> 0xaU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[1U] 
                                                     >> 0xaU)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 0x14U))))))),9);
            tracep->chgSData(oldp+313,(((0x1c0U & vlTOPp->logicnet__DOT__M3w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0xfU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0xfU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0xfU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M3w[2U] 
                                                        << 0x13U) 
                                                       | (vlTOPp->logicnet__DOT__M3w[1U] 
                                                          >> 0xdU)))))))),9);
            tracep->chgSData(oldp+314,(((0x1c0U & (
                                                   vlTOPp->logicnet__DOT__M3w[1U] 
                                                   << 5U)) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[2U] 
                                             << 1U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                  << 1U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                     << 1U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 8U))))))),9);
            tracep->chgSData(oldp+315,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M3w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M3w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M3w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M3w[2U] 
                                                       >> 8U))))))),9);
            tracep->chgCData(oldp+316,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r),3);
            tracep->chgCData(oldp+317,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r),3);
            tracep->chgCData(oldp+318,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r),3);
            tracep->chgCData(oldp+319,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r),3);
            tracep->chgCData(oldp+320,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r),3);
            tracep->chgCData(oldp+321,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r),3);
            tracep->chgCData(oldp+322,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r),3);
            tracep->chgCData(oldp+323,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r),3);
            tracep->chgCData(oldp+324,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r),3);
            tracep->chgCData(oldp+325,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r),3);
            tracep->chgCData(oldp+326,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r),3);
            tracep->chgCData(oldp+327,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r),3);
            tracep->chgCData(oldp+328,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r),3);
            tracep->chgCData(oldp+329,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r),3);
            tracep->chgCData(oldp+330,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r),3);
            tracep->chgCData(oldp+331,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r),3);
            tracep->chgCData(oldp+332,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r),3);
            tracep->chgCData(oldp+333,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r),3);
            tracep->chgCData(oldp+334,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r),3);
            tracep->chgCData(oldp+335,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r),3);
            tracep->chgCData(oldp+336,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r),3);
            tracep->chgCData(oldp+337,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r),3);
            tracep->chgCData(oldp+338,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r),3);
            tracep->chgCData(oldp+339,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r),3);
            tracep->chgCData(oldp+340,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r),3);
            tracep->chgCData(oldp+341,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r),3);
            tracep->chgCData(oldp+342,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r),3);
            tracep->chgCData(oldp+343,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r),3);
            tracep->chgCData(oldp+344,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r),3);
            tracep->chgCData(oldp+345,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r),3);
            tracep->chgCData(oldp+346,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r),3);
            tracep->chgCData(oldp+347,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r),3);
            tracep->chgSData(oldp+348,(((0x1c0U & vlTOPp->logicnet__DOT__M4w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M4w[0U] 
                                             >> 0xfU)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                  >> 0xfU)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                     >> 0xfU)) 
                                                 | (7U 
                                                    & ((vlTOPp->logicnet__DOT__M4w[2U] 
                                                        << 0xaU) 
                                                       | (vlTOPp->logicnet__DOT__M4w[1U] 
                                                          >> 0x16U)))))))),9);
            tracep->chgSData(oldp+349,(((0x1c0U & vlTOPp->logicnet__DOT__M4w[0U]) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M4w[1U] 
                                             >> 0x19U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M4w[1U] 
                                                  >> 0x19U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M4w[1U] 
                                                     >> 0x19U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+350,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M4w[1U] 
                                                    << 0x14U) 
                                                   | (0xfffc0U 
                                                      & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                         >> 0xcU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M4w[2U] 
                                             << 1U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                  << 1U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                     << 1U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                       >> 0x17U))))))),9);
            tracep->chgSData(oldp+351,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M4w[1U] 
                                                    << 0x1aU) 
                                                   | (0x3ffffc0U 
                                                      & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                         >> 6U)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M4w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgSData(oldp+352,(((0x1c0U & (
                                                   (vlTOPp->logicnet__DOT__M4w[1U] 
                                                    << 0x11U) 
                                                   | (0x1ffc0U 
                                                      & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                         >> 0xfU)))) 
                                        | ((0x20U & 
                                            (vlTOPp->logicnet__DOT__M4w[0U] 
                                             >> 0x15U)) 
                                           | ((0x10U 
                                               & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                  >> 0x15U)) 
                                              | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M4w[0U] 
                                                     >> 0x15U)) 
                                                 | (7U 
                                                    & (vlTOPp->logicnet__DOT__M4w[2U] 
                                                       >> 0x1dU))))))),9);
            tracep->chgCData(oldp+353,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r),3);
            tracep->chgCData(oldp+354,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r),3);
            tracep->chgCData(oldp+355,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r),3);
            tracep->chgCData(oldp+356,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r),3);
            tracep->chgCData(oldp+357,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r),3);
        }
        tracep->chgQData(oldp+358,(vlTOPp->M0),48);
        tracep->chgBit(oldp+360,(vlTOPp->clk));
        tracep->chgBit(oldp+361,(vlTOPp->rst));
        tracep->chgSData(oldp+362,(vlTOPp->M5),15);
    }
}

void Vlogicnet::traceCleanup(void* userp, VerilatedVcd* /*unused*/) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlSymsp->__Vm_activity = false;
        vlTOPp->__Vm_traceActivity[0U] = 0U;
        vlTOPp->__Vm_traceActivity[1U] = 0U;
    }
}
