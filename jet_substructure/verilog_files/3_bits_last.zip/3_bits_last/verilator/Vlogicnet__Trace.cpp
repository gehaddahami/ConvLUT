// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vlogicnet__Syms.h"


void Vlogicnet::traceChgTop0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    {
        vlTOPp->traceChgSub0(userp, tracep);
    }
}

void Vlogicnet::traceChgSub0(void* userp, VerilatedVcd* tracep) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    vluint32_t* const oldp = tracep->oldp(vlSymsp->__Vm_baseCode + 1);
    if (false && oldp) {}  // Prevent unused
    // Body
    {
        if (VL_UNLIKELY(vlTOPp->__Vm_traceActivity[1U])) {
            tracep->chgIData(oldp+0,(vlTOPp->logicnet__DOT__M0w),32);
            tracep->chgWData(oldp+1,(vlTOPp->logicnet__DOT__M1),128);
            tracep->chgWData(oldp+5,(vlTOPp->logicnet__DOT__M1w),128);
            tracep->chgQData(oldp+9,(vlTOPp->logicnet__DOT__M2),64);
            tracep->chgQData(oldp+11,(vlTOPp->logicnet__DOT__M2w),64);
            tracep->chgQData(oldp+13,(vlTOPp->logicnet__DOT__M3),64);
            tracep->chgQData(oldp+15,(vlTOPp->logicnet__DOT__M3w),64);
            tracep->chgQData(oldp+17,(vlTOPp->logicnet__DOT__M4),64);
            tracep->chgQData(oldp+19,(vlTOPp->logicnet__DOT__M4w),64);
            tracep->chgCData(oldp+21,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+22,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 8U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+23,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xcU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+24,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
            tracep->chgCData(oldp+25,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x18U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+26,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 8U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
            tracep->chgCData(oldp+27,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x12U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+28,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 6U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xcU)))))),6);
            tracep->chgCData(oldp+29,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x16U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x16U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+30,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x14U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+31,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+32,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 6U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+33,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xcU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+34,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xaU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+35,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xaU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xeU)))))),6);
            tracep->chgCData(oldp+36,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x18U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+37,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x14U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+38,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
            tracep->chgCData(oldp+39,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 4U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xcU)))))),6);
            tracep->chgCData(oldp+40,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xaU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xeU)))))),6);
            tracep->chgCData(oldp+41,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xcU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+42,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+43,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x10U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x14U)))))),6);
            tracep->chgCData(oldp+44,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 8U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+45,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 6U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+46,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+47,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x14U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+48,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+49,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x14U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+50,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x12U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+51,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x12U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+52,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 2U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
            tracep->chgCData(oldp+53,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x14U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+54,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 6U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
            tracep->chgCData(oldp+55,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x10U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+56,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xcU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+57,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x14U)))))),6);
            tracep->chgCData(oldp+58,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x1aU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x1aU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+59,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x18U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+60,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x12U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
            tracep->chgCData(oldp+61,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x10U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+62,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 2U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+63,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x18U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x18U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+64,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & vlTOPp->logicnet__DOT__M0w) 
                                          | ((4U & vlTOPp->logicnet__DOT__M0w) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x16U)))))),6);
            tracep->chgCData(oldp+65,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 6U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
            tracep->chgCData(oldp+66,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xeU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xeU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x14U)))))),6);
            tracep->chgCData(oldp+67,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x16U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x16U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1eU)))))),6);
            tracep->chgCData(oldp+68,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xcU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+69,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 2U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xcU)))))),6);
            tracep->chgCData(oldp+70,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & vlTOPp->logicnet__DOT__M0w) 
                                          | ((4U & vlTOPp->logicnet__DOT__M0w) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+71,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 6U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x10U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+72,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xcU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xcU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+73,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0xaU)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0xaU)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+74,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 2U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 2U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+75,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 4U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x12U)))))),6);
            tracep->chgCData(oldp+76,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x10U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x10U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1aU)))))),6);
            tracep->chgCData(oldp+77,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 << 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x12U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x12U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x1cU)))))),6);
            tracep->chgCData(oldp+78,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 4U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x10U)))))),6);
            tracep->chgCData(oldp+79,(((0x30U & vlTOPp->logicnet__DOT__M0w) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 0x14U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 0x14U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0x18U)))))),6);
            tracep->chgCData(oldp+80,(((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 4U)) 
                                       | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                                 >> 8U)) 
                                          | ((4U & 
                                              (vlTOPp->logicnet__DOT__M0w 
                                               >> 8U)) 
                                             | (3U 
                                                & (vlTOPp->logicnet__DOT__M0w 
                                                   >> 0xeU)))))),6);
            tracep->chgCData(oldp+81,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r),2);
            tracep->chgCData(oldp+82,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r),2);
            tracep->chgCData(oldp+83,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r),2);
            tracep->chgCData(oldp+84,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r),2);
            tracep->chgCData(oldp+85,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r),2);
            tracep->chgCData(oldp+86,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r),2);
            tracep->chgCData(oldp+87,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r),2);
            tracep->chgCData(oldp+88,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r),2);
            tracep->chgCData(oldp+89,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r),2);
            tracep->chgCData(oldp+90,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r),2);
            tracep->chgCData(oldp+91,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r),2);
            tracep->chgCData(oldp+92,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r),2);
            tracep->chgCData(oldp+93,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r),2);
            tracep->chgCData(oldp+94,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r),2);
            tracep->chgCData(oldp+95,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r),2);
            tracep->chgCData(oldp+96,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r),2);
            tracep->chgCData(oldp+97,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r),2);
            tracep->chgCData(oldp+98,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r),2);
            tracep->chgCData(oldp+99,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r),2);
            tracep->chgCData(oldp+100,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r),2);
            tracep->chgCData(oldp+101,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r),2);
            tracep->chgCData(oldp+102,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r),2);
            tracep->chgCData(oldp+103,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r),2);
            tracep->chgCData(oldp+104,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r),2);
            tracep->chgCData(oldp+105,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r),2);
            tracep->chgCData(oldp+106,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r),2);
            tracep->chgCData(oldp+107,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r),2);
            tracep->chgCData(oldp+108,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r),2);
            tracep->chgCData(oldp+109,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r),2);
            tracep->chgCData(oldp+110,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r),2);
            tracep->chgCData(oldp+111,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r),2);
            tracep->chgCData(oldp+112,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r),2);
            tracep->chgCData(oldp+113,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r),2);
            tracep->chgCData(oldp+114,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r),2);
            tracep->chgCData(oldp+115,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r),2);
            tracep->chgCData(oldp+116,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r),2);
            tracep->chgCData(oldp+117,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r),2);
            tracep->chgCData(oldp+118,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r),2);
            tracep->chgCData(oldp+119,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r),2);
            tracep->chgCData(oldp+120,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r),2);
            tracep->chgCData(oldp+121,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r),2);
            tracep->chgCData(oldp+122,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r),2);
            tracep->chgCData(oldp+123,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r),2);
            tracep->chgCData(oldp+124,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r),2);
            tracep->chgCData(oldp+125,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r),2);
            tracep->chgCData(oldp+126,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r),2);
            tracep->chgCData(oldp+127,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r),2);
            tracep->chgCData(oldp+128,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r),2);
            tracep->chgCData(oldp+129,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r),2);
            tracep->chgCData(oldp+130,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r),2);
            tracep->chgCData(oldp+131,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r),2);
            tracep->chgCData(oldp+132,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r),2);
            tracep->chgCData(oldp+133,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r),2);
            tracep->chgCData(oldp+134,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r),2);
            tracep->chgCData(oldp+135,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r),2);
            tracep->chgCData(oldp+136,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r),2);
            tracep->chgCData(oldp+137,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r),2);
            tracep->chgCData(oldp+138,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r),2);
            tracep->chgCData(oldp+139,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r),2);
            tracep->chgCData(oldp+140,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r),2);
            tracep->chgCData(oldp+141,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r),2);
            tracep->chgCData(oldp+142,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r),2);
            tracep->chgCData(oldp+143,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r),2);
            tracep->chgCData(oldp+144,(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r),2);
            tracep->chgCData(oldp+145,(((0x30U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  << 2U)) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1aU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x1aU)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0xaU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x16U))))))),6);
            tracep->chgCData(oldp+146,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x1aU) 
                                                  | (0x3fffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 6U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x14U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x14U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0xaU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x16U))))))),6);
            tracep->chgCData(oldp+147,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[3U] 
                                                   << 0x1aU) 
                                                  | (0x3fffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                        >> 6U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x14U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x14U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x12U)))))),6);
            tracep->chgCData(oldp+148,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0x1aU) 
                                                  | (0x3fffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 6U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1cU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x1cU)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0x14U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0xcU))))))),6);
            tracep->chgCData(oldp+149,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  << 2U)) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0xeU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0xeU)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                     << 6U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                       >> 0x1aU))))))),6);
            tracep->chgCData(oldp+150,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x1cU) 
                                                  | (0xffffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 4U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  << 2U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                << 2U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 8U)))))),6);
            tracep->chgCData(oldp+151,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[3U] 
                                                   << 0x1cU) 
                                                  | (0xffffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                        >> 4U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xaU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0xaU)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x12U)))))),6);
            tracep->chgCData(oldp+152,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0x1cU) 
                                                  | (0xffffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 4U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 8U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 8U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                     << 0x18U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 8U))))))),6);
            tracep->chgCData(oldp+153,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0x14U) 
                                                  | (0xffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0xcU)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 4U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 4U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 8U)))))),6);
            tracep->chgCData(oldp+154,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 8U) 
                                                  | (0xf0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0x18U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1aU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x1aU)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x1aU)))))),6);
            tracep->chgCData(oldp+155,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x12U) 
                                                  | (0x3fff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 0xeU)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xeU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0xeU)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 8U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x18U))))))),6);
            tracep->chgCData(oldp+156,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x1cU) 
                                                  | (0xffffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 4U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x10U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x10U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0x12U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0xeU))))))),6);
            tracep->chgCData(oldp+157,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x1cU) 
                                                  | (0xffffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 4U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x12U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0x12U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x1aU)))))),6);
            tracep->chgCData(oldp+158,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0xaU) 
                                                  | (0x3f0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 0x16U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 2U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 2U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0xeU)))))),6);
            tracep->chgCData(oldp+159,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0xcU) 
                                                  | (0xff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 0x14U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 4U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 4U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x1cU)))))),6);
            tracep->chgCData(oldp+160,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0x12U) 
                                                  | (0x3fff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0xeU)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x1aU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0x1aU)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                     << 8U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 0x18U))))))),6);
            tracep->chgCData(oldp+161,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0xcU) 
                                                  | (0xff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0x14U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 6U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 6U)) 
                                              | (3U 
                                                 & vlTOPp->logicnet__DOT__M1w[3U]))))),6);
            tracep->chgCData(oldp+162,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x12U) 
                                                  | (0x3fff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 0xeU)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x1cU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x1cU)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0xeU)))))),6);
            tracep->chgCData(oldp+163,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x12U) 
                                                  | (0x3fff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 0xeU)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xaU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0xaU)) 
                                              | (3U 
                                                 & vlTOPp->logicnet__DOT__M1w[3U]))))),6);
            tracep->chgCData(oldp+164,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0x1aU) 
                                                  | (0x3fffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 6U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x1aU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0x1aU)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                     << 8U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 0x18U))))))),6);
            tracep->chgCData(oldp+165,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  << 2U)) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x12U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 0x12U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0x12U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0xeU))))))),6);
            tracep->chgCData(oldp+166,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x16U) 
                                                  | (0x3ffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 0xaU)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 0x16U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 0x16U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x1aU)))))),6);
            tracep->chgCData(oldp+167,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0xeU) 
                                                  | (0x3ff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0x12U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 8U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 8U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0xcU)))))),6);
            tracep->chgCData(oldp+168,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[3U] 
                                                   << 0xaU) 
                                                  | (0x3f0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                        >> 0x16U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 6U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 6U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x12U)))))),6);
            tracep->chgCData(oldp+169,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0xcU) 
                                                  | (0xff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0x14U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x10U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x10U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 6U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x1aU))))))),6);
            tracep->chgCData(oldp+170,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  << 4U)) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 6U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[1U] 
                                                >> 6U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 8U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0x18U))))))),6);
            tracep->chgCData(oldp+171,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0x1aU) 
                                                  | (0x3fffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 6U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x14U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0x14U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                     << 0x16U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                       >> 0xaU))))))),6);
            tracep->chgCData(oldp+172,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0xaU) 
                                                  | (0x3f0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0x16U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0xcU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0xcU)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x1eU)))))),6);
            tracep->chgCData(oldp+173,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   << 0x18U) 
                                                  | (0xfffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                        >> 8U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                  >> 6U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[3U] 
                                                >> 6U)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x10U)))))),6);
            tracep->chgCData(oldp+174,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 8U) 
                                                  | (0xf0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 0x18U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x1cU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[2U] 
                                                >> 0x1cU)) 
                                              | (3U 
                                                 & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                    >> 0x18U)))))),6);
            tracep->chgCData(oldp+175,(((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  << 2U)) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 6U)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 6U)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                     << 0xcU) 
                                                    | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                       >> 0x14U))))))),6);
            tracep->chgCData(oldp+176,(((0x30U & ((
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   << 0x1aU) 
                                                  | (0x3fffff0U 
                                                     & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                        >> 6U)))) 
                                        | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0xcU)) 
                                           | ((4U & 
                                               (vlTOPp->logicnet__DOT__M1w[0U] 
                                                >> 0xcU)) 
                                              | (3U 
                                                 & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                     << 8U) 
                                                    | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                       >> 0x18U))))))),6);
            tracep->chgCData(oldp+177,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r),2);
            tracep->chgCData(oldp+178,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r),2);
            tracep->chgCData(oldp+179,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r),2);
            tracep->chgCData(oldp+180,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r),2);
            tracep->chgCData(oldp+181,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r),2);
            tracep->chgCData(oldp+182,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r),2);
            tracep->chgCData(oldp+183,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r),2);
            tracep->chgCData(oldp+184,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r),2);
            tracep->chgCData(oldp+185,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r),2);
            tracep->chgCData(oldp+186,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r),2);
            tracep->chgCData(oldp+187,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r),2);
            tracep->chgCData(oldp+188,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r),2);
            tracep->chgCData(oldp+189,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r),2);
            tracep->chgCData(oldp+190,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r),2);
            tracep->chgCData(oldp+191,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r),2);
            tracep->chgCData(oldp+192,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r),2);
            tracep->chgCData(oldp+193,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r),2);
            tracep->chgCData(oldp+194,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r),2);
            tracep->chgCData(oldp+195,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r),2);
            tracep->chgCData(oldp+196,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r),2);
            tracep->chgCData(oldp+197,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r),2);
            tracep->chgCData(oldp+198,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r),2);
            tracep->chgCData(oldp+199,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r),2);
            tracep->chgCData(oldp+200,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r),2);
            tracep->chgCData(oldp+201,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r),2);
            tracep->chgCData(oldp+202,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r),2);
            tracep->chgCData(oldp+203,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r),2);
            tracep->chgCData(oldp+204,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r),2);
            tracep->chgCData(oldp+205,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r),2);
            tracep->chgCData(oldp+206,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r),2);
            tracep->chgCData(oldp+207,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r),2);
            tracep->chgCData(oldp+208,(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r),2);
            tracep->chgCData(oldp+209,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x21U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x20U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x24U))))))),6);
            tracep->chgCData(oldp+210,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1cU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2bU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x2aU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
            tracep->chgCData(oldp+211,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x35U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x34U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+212,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x18U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x39U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x38U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3aU))))))),6);
            tracep->chgCData(oldp+213,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 9U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 8U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x26U))))))),6);
            tracep->chgCData(oldp+214,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x12U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1dU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x1cU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x20U))))))),6);
            tracep->chgCData(oldp+215,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xaU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xfU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0xeU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x1cU))))))),6);
            tracep->chgCData(oldp+216,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x12U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x15U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x14U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
            tracep->chgCData(oldp+217,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x17U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x16U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
            tracep->chgCData(oldp+218,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x20U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x25U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x24U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
            tracep->chgCData(oldp+219,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x10U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x13U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x12U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2cU))))))),6);
            tracep->chgCData(oldp+220,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x18U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2fU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x2eU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x36U))))))),6);
            tracep->chgCData(oldp+221,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x38U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x3bU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x3aU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
            tracep->chgCData(oldp+222,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xeU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1dU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x1cU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x1eU))))))),6);
            tracep->chgCData(oldp+223,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x18U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2bU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x2aU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
            tracep->chgCData(oldp+224,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x10U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1dU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x1cU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+225,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 9U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 8U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2eU))))))),6);
            tracep->chgCData(oldp+226,(((0x30U & ((IData)(vlTOPp->logicnet__DOT__M2w) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x38U))))))),6);
            tracep->chgCData(oldp+227,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x16U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x25U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x24U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2eU))))))),6);
            tracep->chgCData(oldp+228,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xeU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x16U))))))),6);
            tracep->chgCData(oldp+229,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 2U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x15U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x14U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x36U))))))),6);
            tracep->chgCData(oldp+230,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x25U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x24U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
            tracep->chgCData(oldp+231,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x16U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x29U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x28U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2cU))))))),6);
            tracep->chgCData(oldp+232,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 2U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 9U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 8U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x14U))))))),6);
            tracep->chgCData(oldp+233,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xdU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0xcU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
            tracep->chgCData(oldp+234,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 8U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xbU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0xaU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x36U))))))),6);
            tracep->chgCData(oldp+235,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 8U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x2bU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x2aU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x32U))))))),6);
            tracep->chgCData(oldp+236,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x14U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x29U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x28U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+237,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x18U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x29U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x28U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x2cU))))))),6);
            tracep->chgCData(oldp+238,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1bU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x1aU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x30U))))))),6);
            tracep->chgCData(oldp+239,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x1aU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0x21U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0x20U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x3cU))))))),6);
            tracep->chgCData(oldp+240,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M2w 
                                                           >> 0xbU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M2w 
                                                         >> 0xaU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M2w 
                                                            >> 0x1cU))))))),6);
            tracep->chgCData(oldp+241,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r),2);
            tracep->chgCData(oldp+242,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r),2);
            tracep->chgCData(oldp+243,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r),2);
            tracep->chgCData(oldp+244,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r),2);
            tracep->chgCData(oldp+245,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r),2);
            tracep->chgCData(oldp+246,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r),2);
            tracep->chgCData(oldp+247,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r),2);
            tracep->chgCData(oldp+248,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r),2);
            tracep->chgCData(oldp+249,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r),2);
            tracep->chgCData(oldp+250,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r),2);
            tracep->chgCData(oldp+251,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r),2);
            tracep->chgCData(oldp+252,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r),2);
            tracep->chgCData(oldp+253,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r),2);
            tracep->chgCData(oldp+254,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r),2);
            tracep->chgCData(oldp+255,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r),2);
            tracep->chgCData(oldp+256,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r),2);
            tracep->chgCData(oldp+257,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r),2);
            tracep->chgCData(oldp+258,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r),2);
            tracep->chgCData(oldp+259,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r),2);
            tracep->chgCData(oldp+260,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r),2);
            tracep->chgCData(oldp+261,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r),2);
            tracep->chgCData(oldp+262,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r),2);
            tracep->chgCData(oldp+263,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r),2);
            tracep->chgCData(oldp+264,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r),2);
            tracep->chgCData(oldp+265,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r),2);
            tracep->chgCData(oldp+266,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r),2);
            tracep->chgCData(oldp+267,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r),2);
            tracep->chgCData(oldp+268,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r),2);
            tracep->chgCData(oldp+269,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r),2);
            tracep->chgCData(oldp+270,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r),2);
            tracep->chgCData(oldp+271,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r),2);
            tracep->chgCData(oldp+272,(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r),2);
            tracep->chgCData(oldp+273,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xeU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1dU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x1cU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
            tracep->chgCData(oldp+274,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 8U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1fU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x1eU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x32U))))))),6);
            tracep->chgCData(oldp+275,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x14U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x21U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x20U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x26U))))))),6);
            tracep->chgCData(oldp+276,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1cU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x29U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x28U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+277,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x12U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x37U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x36U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x38U))))))),6);
            tracep->chgCData(oldp+278,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x27U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x26U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
            tracep->chgCData(oldp+279,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 8U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x15U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x14U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x16U))))))),6);
            tracep->chgCData(oldp+280,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 8U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x13U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x12U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
            tracep->chgCData(oldp+281,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+282,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
            tracep->chgCData(oldp+283,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1cU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x21U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x20U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+284,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x18U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x29U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x28U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x34U))))))),6);
            tracep->chgCData(oldp+285,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xbU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0xaU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
            tracep->chgCData(oldp+286,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x13U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x12U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x16U))))))),6);
            tracep->chgCData(oldp+287,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x12U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x29U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x28U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x36U))))))),6);
            tracep->chgCData(oldp+288,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1dU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x1cU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+289,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x16U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x27U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x26U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x38U))))))),6);
            tracep->chgCData(oldp+290,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xaU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x13U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x12U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x26U))))))),6);
            tracep->chgCData(oldp+291,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x33U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x32U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x34U))))))),6);
            tracep->chgCData(oldp+292,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x30U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x39U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x38U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3aU))))))),6);
            tracep->chgCData(oldp+293,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1fU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x1eU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x24U))))))),6);
            tracep->chgCData(oldp+294,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x18U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x21U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x20U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
            tracep->chgCData(oldp+295,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1fU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x1eU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+296,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 2U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x15U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x14U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x1cU))))))),6);
            tracep->chgCData(oldp+297,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x10U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x2bU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x2aU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x36U))))))),6);
            tracep->chgCData(oldp+298,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 2U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xfU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0xeU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x2eU))))))),6);
            tracep->chgCData(oldp+299,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x3cU))))))),6);
            tracep->chgCData(oldp+300,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 6U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x21U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x20U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x28U))))))),6);
            tracep->chgCData(oldp+301,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1cU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x1fU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x1eU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x38U))))))),6);
            tracep->chgCData(oldp+302,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xdU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0xcU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x1eU))))))),6);
            tracep->chgCData(oldp+303,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x16U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x2dU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x2cU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
            tracep->chgCData(oldp+304,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M3w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M3w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M3w 
                                                            >> 0x30U))))))),6);
            tracep->chgCData(oldp+305,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r),2);
            tracep->chgCData(oldp+306,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r),2);
            tracep->chgCData(oldp+307,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r),2);
            tracep->chgCData(oldp+308,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r),2);
            tracep->chgCData(oldp+309,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r),2);
            tracep->chgCData(oldp+310,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r),2);
            tracep->chgCData(oldp+311,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r),2);
            tracep->chgCData(oldp+312,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r),2);
            tracep->chgCData(oldp+313,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r),2);
            tracep->chgCData(oldp+314,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r),2);
            tracep->chgCData(oldp+315,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r),2);
            tracep->chgCData(oldp+316,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r),2);
            tracep->chgCData(oldp+317,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r),2);
            tracep->chgCData(oldp+318,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r),2);
            tracep->chgCData(oldp+319,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r),2);
            tracep->chgCData(oldp+320,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r),2);
            tracep->chgCData(oldp+321,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r),2);
            tracep->chgCData(oldp+322,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r),2);
            tracep->chgCData(oldp+323,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r),2);
            tracep->chgCData(oldp+324,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r),2);
            tracep->chgCData(oldp+325,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r),2);
            tracep->chgCData(oldp+326,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r),2);
            tracep->chgCData(oldp+327,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r),2);
            tracep->chgCData(oldp+328,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r),2);
            tracep->chgCData(oldp+329,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r),2);
            tracep->chgCData(oldp+330,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r),2);
            tracep->chgCData(oldp+331,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r),2);
            tracep->chgCData(oldp+332,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r),2);
            tracep->chgCData(oldp+333,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r),2);
            tracep->chgCData(oldp+334,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r),2);
            tracep->chgCData(oldp+335,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r),2);
            tracep->chgCData(oldp+336,(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r),2);
            tracep->chgCData(oldp+337,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0xdU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M4w 
                                                         >> 0xcU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x24U))))))),6);
            tracep->chgCData(oldp+338,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 4U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x29U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M4w 
                                                         >> 0x28U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+339,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0xcU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x2dU)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M4w 
                                                         >> 0x2cU)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3aU))))))),6);
            tracep->chgCData(oldp+340,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 8U)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M4w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+341,(((0x30U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0xeU)) 
                                                  << 4U)) 
                                        | ((8U & ((IData)(
                                                          (vlTOPp->logicnet__DOT__M4w 
                                                           >> 0x11U)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(
                                                        (vlTOPp->logicnet__DOT__M4w 
                                                         >> 0x10U)) 
                                                << 2U)) 
                                              | (3U 
                                                 & (IData)(
                                                           (vlTOPp->logicnet__DOT__M4w 
                                                            >> 0x3eU))))))),6);
            tracep->chgCData(oldp+342,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r),3);
            tracep->chgCData(oldp+343,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r),3);
            tracep->chgCData(oldp+344,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r),3);
            tracep->chgCData(oldp+345,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r),3);
            tracep->chgCData(oldp+346,(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r),3);
        }
        tracep->chgIData(oldp+347,(vlTOPp->M0),32);
        tracep->chgBit(oldp+348,(vlTOPp->clk));
        tracep->chgBit(oldp+349,(vlTOPp->rst));
        tracep->chgSData(oldp+350,(vlTOPp->M5),15);
    }
}

void Vlogicnet::traceCleanup(void* userp, VerilatedVcd* /*unused*/) {
    Vlogicnet__Syms* __restrict vlSymsp = static_cast<Vlogicnet__Syms*>(userp);
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlSymsp->__Vm_activity = false;
        vlTOPp->__Vm_traceActivity[0U] = 0U;
        vlTOPp->__Vm_traceActivity[1U] = 0U;
    }
}
