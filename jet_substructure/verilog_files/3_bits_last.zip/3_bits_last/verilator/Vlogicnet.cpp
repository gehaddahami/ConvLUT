// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vlogicnet.h for the primary calling header

#include "Vlogicnet.h"
#include "Vlogicnet__Syms.h"

//==========

void Vlogicnet::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vlogicnet::eval\n"); );
    Vlogicnet__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        vlSymsp->__Vm_activity = true;
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/student/CNN_LogicNets/jet_substructure/jsc_s/3_bits_last/logicnet.v", 1, "",
                "Verilated model didn't converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

void Vlogicnet::_eval_initial_loop(Vlogicnet__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        _eval_settle(vlSymsp);
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/student/CNN_LogicNets/jet_substructure/jsc_s/3_bits_last/logicnet.v", 1, "",
                "Verilated model didn't DC converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

VL_INLINE_OPT void Vlogicnet::_sequent__TOP__1(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_sequent__TOP__1\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->rst) {
        vlTOPp->logicnet__DOT__M4w = 0ULL;
        vlTOPp->logicnet__DOT__M3w = 0ULL;
        vlTOPp->logicnet__DOT__M2w = 0ULL;
        vlTOPp->logicnet__DOT__M1w[0U] = 0U;
        vlTOPp->logicnet__DOT__M1w[1U] = 0U;
        vlTOPp->logicnet__DOT__M1w[2U] = 0U;
        vlTOPp->logicnet__DOT__M1w[3U] = 0U;
        vlTOPp->logicnet__DOT__M0w = 0U;
    } else {
        vlTOPp->logicnet__DOT__M4w = vlTOPp->logicnet__DOT__M4;
        vlTOPp->logicnet__DOT__M3w = vlTOPp->logicnet__DOT__M3;
        vlTOPp->logicnet__DOT__M2w = vlTOPp->logicnet__DOT__M2;
        vlTOPp->logicnet__DOT__M1w[0U] = vlTOPp->logicnet__DOT__M1[0U];
        vlTOPp->logicnet__DOT__M1w[1U] = vlTOPp->logicnet__DOT__M1[1U];
        vlTOPp->logicnet__DOT__M1w[2U] = vlTOPp->logicnet__DOT__M1[2U];
        vlTOPp->logicnet__DOT__M1w[3U] = vlTOPp->logicnet__DOT__M1[3U];
        vlTOPp->logicnet__DOT__M0w = vlTOPp->M0;
    }
    vlTOPp->__Vtableidx161 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M4w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M4w 
                                                                >> 0xdU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M4w 
                                                                   >> 0xcU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M4w 
                                                                    >> 0x24U))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable161_logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx161];
    vlTOPp->__Vtableidx162 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M4w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M4w 
                                                                >> 0x29U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M4w 
                                                                   >> 0x28U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M4w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable162_logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx162];
    vlTOPp->__Vtableidx163 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M4w 
                                                 >> 0xcU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M4w 
                                                                >> 0x2dU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M4w 
                                                                   >> 0x2cU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M4w 
                                                                    >> 0x3aU))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable163_logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx163];
    vlTOPp->__Vtableidx164 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M4w 
                                                 >> 8U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M4w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M4w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M4w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable164_logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx164];
    vlTOPp->__Vtableidx165 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M4w 
                                                 >> 0xeU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M4w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M4w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M4w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable165_logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx165];
    vlTOPp->__Vtableidx129 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0xeU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x1dU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x1cU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x28U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable129_logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx129];
    vlTOPp->__Vtableidx130 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 8U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x1fU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x1eU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x32U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable130_logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx130];
    vlTOPp->__Vtableidx131 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x14U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x21U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x20U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x26U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable131_logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx131];
    vlTOPp->__Vtableidx132 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x1cU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x29U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x28U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable132_logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx132];
    vlTOPp->__Vtableidx133 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x12U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x37U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x36U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x38U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable133_logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx133];
    vlTOPp->__Vtableidx134 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0xcU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x27U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x26U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x28U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable134_logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx134];
    vlTOPp->__Vtableidx135 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 8U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x15U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x14U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x16U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable135_logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx135];
    vlTOPp->__Vtableidx136 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 8U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x13U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x12U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x28U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable136_logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx136];
    vlTOPp->__Vtableidx137 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable137_logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx137];
    vlTOPp->__Vtableidx138 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x30U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable138_logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx138];
    vlTOPp->__Vtableidx139 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x1cU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x21U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x20U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable139_logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx139];
    vlTOPp->__Vtableidx140 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x18U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x29U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x28U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x34U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable140_logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx140];
    vlTOPp->__Vtableidx141 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0xbU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0xaU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x28U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable141_logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx141];
    vlTOPp->__Vtableidx142 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0xcU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x13U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x12U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x16U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable142_logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx142];
    vlTOPp->__Vtableidx143 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x12U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x29U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x28U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x36U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable143_logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx143];
    vlTOPp->__Vtableidx144 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x1dU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x1cU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable144_logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx144];
    vlTOPp->__Vtableidx145 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x16U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x27U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x26U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x38U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable145_logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx145];
    vlTOPp->__Vtableidx146 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0xaU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x13U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x12U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x26U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable146_logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx146];
    vlTOPp->__Vtableidx147 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x33U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x32U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x34U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable147_logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx147];
    vlTOPp->__Vtableidx148 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x30U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x39U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x38U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x3aU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable148_logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx148];
    vlTOPp->__Vtableidx149 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0xcU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x1fU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x1eU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x24U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable149_logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx149];
    vlTOPp->__Vtableidx150 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x18U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x21U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x20U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x30U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable150_logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx150];
    vlTOPp->__Vtableidx151 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0xcU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x1fU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x1eU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable151_logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx151];
    vlTOPp->__Vtableidx152 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 2U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x15U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x14U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x1cU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable152_logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx152];
    vlTOPp->__Vtableidx153 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x10U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x2bU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x2aU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x36U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable153_logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx153];
    vlTOPp->__Vtableidx154 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 2U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0xfU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0xeU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x2eU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable154_logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx154];
    vlTOPp->__Vtableidx155 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x3cU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable155_logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx155];
    vlTOPp->__Vtableidx156 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x21U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x20U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x28U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable156_logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx156];
    vlTOPp->__Vtableidx157 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x1cU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x1fU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x1eU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x38U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable157_logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx157];
    vlTOPp->__Vtableidx158 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0xdU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0xcU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x1eU))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable158_logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx158];
    vlTOPp->__Vtableidx159 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0x16U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x2dU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x2cU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x30U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable159_logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx159];
    vlTOPp->__Vtableidx160 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M3w 
                                                 >> 0xcU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M3w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M3w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M3w 
                                                                    >> 0x30U))))));
    vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable160_logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx160];
    vlTOPp->__Vtableidx97 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                >> 0xcU)) 
                                       << 4U)) | ((8U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M2w 
                                                               >> 0x21U)) 
                                                      << 3U)) 
                                                  | ((4U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M2w 
                                                                  >> 0x20U)) 
                                                         << 2U)) 
                                                     | (3U 
                                                        & (IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x24U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable97_logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx97];
    vlTOPp->__Vtableidx98 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                >> 0x1cU)) 
                                       << 4U)) | ((8U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M2w 
                                                               >> 0x2bU)) 
                                                      << 3U)) 
                                                  | ((4U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M2w 
                                                                  >> 0x2aU)) 
                                                         << 2U)) 
                                                     | (3U 
                                                        & (IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x32U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable98_logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx98];
    vlTOPp->__Vtableidx99 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                >> 6U)) 
                                       << 4U)) | ((8U 
                                                   & ((IData)(
                                                              (vlTOPp->logicnet__DOT__M2w 
                                                               >> 0x35U)) 
                                                      << 3U)) 
                                                  | ((4U 
                                                      & ((IData)(
                                                                 (vlTOPp->logicnet__DOT__M2w 
                                                                  >> 0x34U)) 
                                                         << 2U)) 
                                                     | (3U 
                                                        & (IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable99_logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx99];
    vlTOPp->__Vtableidx100 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x18U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x39U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x38U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x3aU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable100_logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx100];
    vlTOPp->__Vtableidx101 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 9U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 8U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x26U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable101_logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx101];
    vlTOPp->__Vtableidx102 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x12U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x1dU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x1cU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x20U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable102_logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx102];
    vlTOPp->__Vtableidx103 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0xaU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0xfU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0xeU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x1cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable103_logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx103];
    vlTOPp->__Vtableidx104 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x12U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x15U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x14U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x32U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable104_logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx104];
    vlTOPp->__Vtableidx105 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x17U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x16U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x32U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable105_logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx105];
    vlTOPp->__Vtableidx106 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x20U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x25U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x24U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x32U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable106_logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx106];
    vlTOPp->__Vtableidx107 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x10U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x13U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x12U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x2cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable107_logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx107];
    vlTOPp->__Vtableidx108 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x18U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x2fU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x2eU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x36U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable108_logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx108];
    vlTOPp->__Vtableidx109 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x38U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x3bU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x3aU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x3cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable109_logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx109];
    vlTOPp->__Vtableidx110 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0xeU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x1dU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x1cU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x1eU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable110_logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx110];
    vlTOPp->__Vtableidx111 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x18U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x2bU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x2aU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x32U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable111_logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx111];
    vlTOPp->__Vtableidx112 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x10U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x1dU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x1cU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable112_logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx112];
    vlTOPp->__Vtableidx113 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 9U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 8U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x2eU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable113_logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx113];
    vlTOPp->__Vtableidx114 = ((0x30U & ((IData)(vlTOPp->logicnet__DOT__M2w) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x38U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable114_logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx114];
    vlTOPp->__Vtableidx115 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x16U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x25U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x24U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x2eU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable115_logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx115];
    vlTOPp->__Vtableidx116 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0xeU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x11U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x10U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x16U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable116_logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx116];
    vlTOPp->__Vtableidx117 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 2U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x15U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x14U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x36U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable117_logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx117];
    vlTOPp->__Vtableidx118 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0xcU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x25U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x24U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x3cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable118_logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx118];
    vlTOPp->__Vtableidx119 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x16U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x29U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x28U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x2cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable119_logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx119];
    vlTOPp->__Vtableidx120 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 2U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 9U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 8U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x14U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable120_logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx120];
    vlTOPp->__Vtableidx121 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0xdU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0xcU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x3cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable121_logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx121];
    vlTOPp->__Vtableidx122 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 8U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0xbU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0xaU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x36U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable122_logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx122];
    vlTOPp->__Vtableidx123 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 8U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x2bU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x2aU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x32U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable123_logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx123];
    vlTOPp->__Vtableidx124 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x14U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x29U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x28U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x3eU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable124_logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx124];
    vlTOPp->__Vtableidx125 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x18U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x29U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x28U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x2cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable125_logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx125];
    vlTOPp->__Vtableidx126 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 6U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x1bU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x1aU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x30U))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable126_logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx126];
    vlTOPp->__Vtableidx127 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 0x1aU)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0x21U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0x20U)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x3cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable127_logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx127];
    vlTOPp->__Vtableidx128 = ((0x30U & ((IData)((vlTOPp->logicnet__DOT__M2w 
                                                 >> 4U)) 
                                        << 4U)) | (
                                                   (8U 
                                                    & ((IData)(
                                                               (vlTOPp->logicnet__DOT__M2w 
                                                                >> 0xbU)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (vlTOPp->logicnet__DOT__M2w 
                                                                   >> 0xaU)) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (IData)(
                                                                   (vlTOPp->logicnet__DOT__M2w 
                                                                    >> 0x1cU))))));
    vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable128_logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx128];
    vlTOPp->__Vtableidx65 = ((0x30U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0x1aU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 0x1aU)) 
                                                     | (3U 
                                                        & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                            << 0xaU) 
                                                           | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                              >> 0x16U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable65_logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx65];
    vlTOPp->__Vtableidx66 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x1aU) | 
                                       (0x3fffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 6U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       >> 0x14U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        >> 0x14U)) 
                                 | (3U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                           << 0xaU) 
                                          | (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0x16U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable66_logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx66];
    vlTOPp->__Vtableidx67 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                        << 0x1aU) | 
                                       (0x3fffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[2U] 
                                           >> 6U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 0x14U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        >> 0x14U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable67_logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx67];
    vlTOPp->__Vtableidx68 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0x1aU) | 
                                       (0x3fffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[0U] 
                                           >> 6U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       >> 0x1cU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        >> 0x1cU)) 
                                 | (3U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                           << 0x14U) 
                                          | (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xcU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable68_logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx68];
    vlTOPp->__Vtableidx69 = ((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                            << 6U) 
                                                           | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                              >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable69_logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx69];
    vlTOPp->__Vtableidx70 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x1cU) | 
                                       (0xffffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 4U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       << 2U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      << 2U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                        >> 8U)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable70_logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx70];
    vlTOPp->__Vtableidx71 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                        << 0x1cU) | 
                                       (0xffffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[2U] 
                                           >> 4U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 0xaU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        >> 0xaU)) | 
                                 (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                        >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable71_logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx71];
    vlTOPp->__Vtableidx72 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0x1cU) | 
                                       (0xffffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[0U] 
                                           >> 4U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       >> 8U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 8U)) 
                                                  | (3U 
                                                     & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                                         << 0x18U) 
                                                        | (vlTOPp->logicnet__DOT__M1w[1U] 
                                                           >> 8U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable72_logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx72];
    vlTOPp->__Vtableidx73 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0x14U) | 
                                       (0xffff0U & 
                                        (vlTOPp->logicnet__DOT__M1w[0U] 
                                         >> 0xcU)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 4U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      >> 4U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                        >> 8U)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable73_logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx73];
    vlTOPp->__Vtableidx74 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 8U) | (0xf0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x18U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       >> 0x1aU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        >> 0x1aU)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable74_logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx74];
    vlTOPp->__Vtableidx75 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x12U) | 
                                       (0x3fff0U & 
                                        (vlTOPp->logicnet__DOT__M1w[1U] 
                                         >> 0xeU)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 0xeU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        >> 0xeU)) | 
                                 (3U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                         << 8U) | (
                                                   vlTOPp->logicnet__DOT__M1w[2U] 
                                                   >> 0x18U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable75_logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx75];
    vlTOPp->__Vtableidx76 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x1cU) | 
                                       (0xffffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 4U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       >> 0x10U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        >> 0x10U)) 
                                 | (3U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                           << 0x12U) 
                                          | (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xeU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable76_logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx76];
    vlTOPp->__Vtableidx77 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x1cU) | 
                                       (0xffffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 4U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                       >> 0x12U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                        >> 0x12U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable77_logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx77];
    vlTOPp->__Vtableidx78 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0xaU) | 
                                       (0x3f0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x16U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 2U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                      >> 2U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                        >> 0xeU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable78_logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx78];
    vlTOPp->__Vtableidx79 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0xcU) | 
                                       (0xff0U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                  >> 0x14U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                       >> 4U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                      >> 4U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                        >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable79_logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx79];
    vlTOPp->__Vtableidx80 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0x12U) | 
                                       (0x3fff0U & 
                                        (vlTOPp->logicnet__DOT__M1w[0U] 
                                         >> 0xeU)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       >> 0x1aU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        >> 0x1aU)) 
                                 | (3U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                           << 8U) | 
                                          (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 0x18U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable80_logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx80];
    vlTOPp->__Vtableidx81 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0xcU) | 
                                       (0xff0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x14U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       >> 6U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 6U)) 
                                                  | (3U 
                                                     & vlTOPp->logicnet__DOT__M1w[3U]))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable81_logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx81];
    vlTOPp->__Vtableidx82 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x12U) | 
                                       (0x3fff0U & 
                                        (vlTOPp->logicnet__DOT__M1w[1U] 
                                         >> 0xeU)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       >> 0x1cU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                        >> 0x1cU)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0xeU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable82_logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx82];
    vlTOPp->__Vtableidx83 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x12U) | 
                                       (0x3fff0U & 
                                        (vlTOPp->logicnet__DOT__M1w[1U] 
                                         >> 0xeU)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 0xaU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        >> 0xaU)) | 
                                 (3U & vlTOPp->logicnet__DOT__M1w[3U]))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable83_logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx83];
    vlTOPp->__Vtableidx84 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0x1aU) | 
                                       (0x3fffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[0U] 
                                           >> 6U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       >> 0x1aU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        >> 0x1aU)) 
                                 | (3U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                           << 8U) | 
                                          (vlTOPp->logicnet__DOT__M1w[1U] 
                                           >> 0x18U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable84_logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx84];
    vlTOPp->__Vtableidx85 = ((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 0x12U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 0x12U)) 
                                                     | (3U 
                                                        & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                            << 0x12U) 
                                                           | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                              >> 0xeU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable85_logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx85];
    vlTOPp->__Vtableidx86 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x16U) | 
                                       (0x3ffff0U & 
                                        (vlTOPp->logicnet__DOT__M1w[1U] 
                                         >> 0xaU)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                       >> 0x16U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                        >> 0x16U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable86_logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx86];
    vlTOPp->__Vtableidx87 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0xeU) | 
                                       (0x3ff0U & (
                                                   vlTOPp->logicnet__DOT__M1w[0U] 
                                                   >> 0x12U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[1U] 
                                       >> 8U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 8U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                        >> 0xcU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable87_logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx87];
    vlTOPp->__Vtableidx88 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                        << 0xaU) | 
                                       (0x3f0U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                                  >> 0x16U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                       >> 6U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                      >> 6U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                        >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable88_logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx88];
    vlTOPp->__Vtableidx89 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0xcU) | 
                                       (0xff0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x14U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 0x10U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        >> 0x10U)) 
                                 | (3U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                           << 6U) | 
                                          (vlTOPp->logicnet__DOT__M1w[2U] 
                                           >> 0x1aU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable89_logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx89];
    vlTOPp->__Vtableidx90 = ((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                      >> 6U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M1w[1U] 
                                                         >> 6U)) 
                                                     | (3U 
                                                        & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                                            << 8U) 
                                                           | (vlTOPp->logicnet__DOT__M1w[2U] 
                                                              >> 0x18U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable90_logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx90];
    vlTOPp->__Vtableidx91 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0x1aU) | 
                                       (0x3fffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[0U] 
                                           >> 6U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       >> 0x14U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        >> 0x14U)) 
                                 | (3U & ((vlTOPp->logicnet__DOT__M1w[3U] 
                                           << 0x16U) 
                                          | (vlTOPp->logicnet__DOT__M1w[2U] 
                                             >> 0xaU))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable91_logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx91];
    vlTOPp->__Vtableidx92 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0xaU) | 
                                       (0x3f0U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                  >> 0x16U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 0xcU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        >> 0xcU)) | 
                                 (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                        >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable92_logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx92];
    vlTOPp->__Vtableidx93 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                        << 0x18U) | 
                                       (0xfffff0U & 
                                        (vlTOPp->logicnet__DOT__M1w[1U] 
                                         >> 8U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                       >> 6U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                      >> 6U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M1w[3U] 
                                                        >> 0x10U)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable93_logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx93];
    vlTOPp->__Vtableidx94 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 8U) | (0xf0U 
                                                  & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                     >> 0x18U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                       >> 0x1cU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[2U] 
                                        >> 0x1cU)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M1w[3U] 
                                          >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable94_logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx94];
    vlTOPp->__Vtableidx95 = ((0x30U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                      >> 6U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M1w[0U] 
                                                         >> 6U)) 
                                                     | (3U 
                                                        & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                                            << 0xcU) 
                                                           | (vlTOPp->logicnet__DOT__M1w[0U] 
                                                              >> 0x14U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable95_logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx95];
    vlTOPp->__Vtableidx96 = ((0x30U & ((vlTOPp->logicnet__DOT__M1w[1U] 
                                        << 0x1aU) | 
                                       (0x3fffff0U 
                                        & (vlTOPp->logicnet__DOT__M1w[0U] 
                                           >> 6U)))) 
                             | ((8U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                       >> 0xcU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M1w[0U] 
                                        >> 0xcU)) | 
                                 (3U & ((vlTOPp->logicnet__DOT__M1w[2U] 
                                         << 8U) | (
                                                   vlTOPp->logicnet__DOT__M1w[1U] 
                                                   >> 0x18U))))));
    vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable96_logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx96];
    vlTOPp->__Vtableidx1 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      << 2U)) | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xeU)) 
                                                 | ((4U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xeU)) 
                                                    | (3U 
                                                       & (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r 
        = vlTOPp->__Vtable1_logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r
        [vlTOPp->__Vtableidx1];
    vlTOPp->__Vtableidx2 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      << 2U)) | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M0w 
                                                     >> 8U)) 
                                                 | ((4U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 8U)) 
                                                    | (3U 
                                                       & (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r 
        = vlTOPp->__Vtable2_logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r
        [vlTOPp->__Vtableidx2];
    vlTOPp->__Vtableidx3 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      << 2U)) | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0xcU)) 
                                                 | ((4U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)) 
                                                    | (3U 
                                                       & (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r 
        = vlTOPp->__Vtable3_logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r
        [vlTOPp->__Vtableidx3];
    vlTOPp->__Vtableidx4 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                            | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                      >> 0xeU)) | (
                                                   (4U 
                                                    & (vlTOPp->logicnet__DOT__M0w 
                                                       >> 0xeU)) 
                                                   | (3U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r 
        = vlTOPp->__Vtable4_logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r
        [vlTOPp->__Vtableidx4];
    vlTOPp->__Vtableidx5 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      >> 0x14U)) | 
                            ((8U & (vlTOPp->logicnet__DOT__M0w 
                                    >> 0x18U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x18U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r 
        = vlTOPp->__Vtable5_logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r
        [vlTOPp->__Vtableidx5];
    vlTOPp->__Vtableidx6 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      >> 4U)) | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M0w 
                                                     >> 8U)) 
                                                 | ((4U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 8U)) 
                                                    | (3U 
                                                       & (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r 
        = vlTOPp->__Vtable6_logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r
        [vlTOPp->__Vtableidx6];
    vlTOPp->__Vtableidx7 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      >> 0xaU)) | (
                                                   (8U 
                                                    & (vlTOPp->logicnet__DOT__M0w 
                                                       >> 0x12U)) 
                                                   | ((4U 
                                                       & (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x12U)) 
                                                      | (3U 
                                                         & (vlTOPp->logicnet__DOT__M0w 
                                                            >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r 
        = vlTOPp->__Vtable7_logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r
        [vlTOPp->__Vtableidx7];
    vlTOPp->__Vtableidx8 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      >> 2U)) | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M0w 
                                                     >> 6U)) 
                                                 | ((4U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 6U)) 
                                                    | (3U 
                                                       & (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0xcU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r 
        = vlTOPp->__Vtable8_logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r
        [vlTOPp->__Vtableidx8];
    vlTOPp->__Vtableidx9 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                      >> 4U)) | ((8U 
                                                  & (vlTOPp->logicnet__DOT__M0w 
                                                     >> 0x16U)) 
                                                 | ((4U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x16U)) 
                                                    | (3U 
                                                       & (vlTOPp->logicnet__DOT__M0w 
                                                          >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r 
        = vlTOPp->__Vtable9_logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r
        [vlTOPp->__Vtableidx9];
    vlTOPp->__Vtableidx10 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x14U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x14U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r 
        = vlTOPp->__Vtable10_logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r
        [vlTOPp->__Vtableidx10];
    vlTOPp->__Vtableidx11 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r 
        = vlTOPp->__Vtable11_logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r
        [vlTOPp->__Vtableidx11];
    vlTOPp->__Vtableidx12 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 6U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 6U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r 
        = vlTOPp->__Vtable12_logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r
        [vlTOPp->__Vtableidx12];
    vlTOPp->__Vtableidx13 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0xcU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0xcU)) | 
                                 (3U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r 
        = vlTOPp->__Vtable13_logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r
        [vlTOPp->__Vtableidx13];
    vlTOPp->__Vtableidx14 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 6U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xaU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xaU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r 
        = vlTOPp->__Vtable14_logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r
        [vlTOPp->__Vtableidx14];
    vlTOPp->__Vtableidx15 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 6U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xaU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xaU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xeU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r 
        = vlTOPp->__Vtable15_logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r
        [vlTOPp->__Vtableidx15];
    vlTOPp->__Vtableidx16 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x18U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x18U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r 
        = vlTOPp->__Vtable16_logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r
        [vlTOPp->__Vtableidx16];
    vlTOPp->__Vtableidx17 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 6U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x14U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x14U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r 
        = vlTOPp->__Vtable17_logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r
        [vlTOPp->__Vtableidx17];
    vlTOPp->__Vtableidx18 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x16U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r 
        = vlTOPp->__Vtable18_logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r
        [vlTOPp->__Vtableidx18];
    vlTOPp->__Vtableidx19 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 4U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 4U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0xcU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r 
        = vlTOPp->__Vtable19_logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r
        [vlTOPp->__Vtableidx19];
    vlTOPp->__Vtableidx20 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xaU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xaU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xeU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r 
        = vlTOPp->__Vtable20_logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r
        [vlTOPp->__Vtableidx20];
    vlTOPp->__Vtableidx21 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xcU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xcU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r 
        = vlTOPp->__Vtable21_logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r
        [vlTOPp->__Vtableidx21];
    vlTOPp->__Vtableidx22 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r 
        = vlTOPp->__Vtable22_logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r
        [vlTOPp->__Vtableidx22];
    vlTOPp->__Vtableidx23 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 8U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x10U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x10U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x14U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r 
        = vlTOPp->__Vtable23_logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r
        [vlTOPp->__Vtableidx23];
    vlTOPp->__Vtableidx24 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 8U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 8U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r 
        = vlTOPp->__Vtable24_logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r
        [vlTOPp->__Vtableidx24];
    vlTOPp->__Vtableidx25 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 6U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 6U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r 
        = vlTOPp->__Vtable25_logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r
        [vlTOPp->__Vtableidx25];
    vlTOPp->__Vtableidx26 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0xeU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0xeU)) | 
                                 (3U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r 
        = vlTOPp->__Vtable26_logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r
        [vlTOPp->__Vtableidx26];
    vlTOPp->__Vtableidx27 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0x14U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x14U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M0w 
                                          >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r 
        = vlTOPp->__Vtable27_logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r
        [vlTOPp->__Vtableidx27];
    vlTOPp->__Vtableidx28 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 6U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r 
        = vlTOPp->__Vtable28_logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r
        [vlTOPp->__Vtableidx28];
    vlTOPp->__Vtableidx29 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x14U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x14U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r 
        = vlTOPp->__Vtable29_logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r
        [vlTOPp->__Vtableidx29];
    vlTOPp->__Vtableidx30 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 8U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x12U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x12U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r 
        = vlTOPp->__Vtable30_logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r
        [vlTOPp->__Vtableidx30];
    vlTOPp->__Vtableidx31 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0xaU)) | 
                             ((8U & (vlTOPp->logicnet__DOT__M0w 
                                     >> 0x12U)) | (
                                                   (4U 
                                                    & (vlTOPp->logicnet__DOT__M0w 
                                                       >> 0x12U)) 
                                                   | (3U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r 
        = vlTOPp->__Vtable31_logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r
        [vlTOPp->__Vtableidx31];
    vlTOPp->__Vtableidx32 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 2U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 2U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x16U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r 
        = vlTOPp->__Vtable32_logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r
        [vlTOPp->__Vtableidx32];
    vlTOPp->__Vtableidx33 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0x14U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x14U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M0w 
                                          >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r 
        = vlTOPp->__Vtable33_logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r
        [vlTOPp->__Vtableidx33];
    vlTOPp->__Vtableidx34 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 6U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 6U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x16U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r 
        = vlTOPp->__Vtable34_logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r
        [vlTOPp->__Vtableidx34];
    vlTOPp->__Vtableidx35 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x10U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x10U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r 
        = vlTOPp->__Vtable35_logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r
        [vlTOPp->__Vtableidx35];
    vlTOPp->__Vtableidx36 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 6U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xcU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xcU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r 
        = vlTOPp->__Vtable36_logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r
        [vlTOPp->__Vtableidx36];
    vlTOPp->__Vtableidx37 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x14U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r 
        = vlTOPp->__Vtable37_logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r
        [vlTOPp->__Vtableidx37];
    vlTOPp->__Vtableidx38 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 6U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x1aU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x1aU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r 
        = vlTOPp->__Vtable38_logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r
        [vlTOPp->__Vtableidx38];
    vlTOPp->__Vtableidx39 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0x18U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x18U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M0w 
                                          >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r 
        = vlTOPp->__Vtable39_logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r
        [vlTOPp->__Vtableidx39];
    vlTOPp->__Vtableidx40 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0xaU)) | 
                             ((8U & (vlTOPp->logicnet__DOT__M0w 
                                     >> 0x12U)) | (
                                                   (4U 
                                                    & (vlTOPp->logicnet__DOT__M0w 
                                                       >> 0x12U)) 
                                                   | (3U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x16U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r 
        = vlTOPp->__Vtable40_logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r
        [vlTOPp->__Vtableidx40];
    vlTOPp->__Vtableidx41 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0x10U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x10U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M0w 
                                          >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r 
        = vlTOPp->__Vtable41_logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r
        [vlTOPp->__Vtableidx41];
    vlTOPp->__Vtableidx42 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 2U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 2U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r 
        = vlTOPp->__Vtable42_logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r
        [vlTOPp->__Vtableidx42];
    vlTOPp->__Vtableidx43 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0xeU)) | 
                             ((8U & (vlTOPp->logicnet__DOT__M0w 
                                     >> 0x18U)) | (
                                                   (4U 
                                                    & (vlTOPp->logicnet__DOT__M0w 
                                                       >> 0x18U)) 
                                                   | (3U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r 
        = vlTOPp->__Vtable43_logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r
        [vlTOPp->__Vtableidx43];
    vlTOPp->__Vtableidx44 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x10U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x10U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r 
        = vlTOPp->__Vtable44_logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r
        [vlTOPp->__Vtableidx44];
    vlTOPp->__Vtableidx45 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & vlTOPp->logicnet__DOT__M0w) 
                                                  | ((4U 
                                                      & vlTOPp->logicnet__DOT__M0w) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x16U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r 
        = vlTOPp->__Vtable45_logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r
        [vlTOPp->__Vtableidx45];
    vlTOPp->__Vtableidx46 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & vlTOPp->logicnet__DOT__M0w) 
                                                  | ((4U 
                                                      & vlTOPp->logicnet__DOT__M0w) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x16U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r 
        = vlTOPp->__Vtable46_logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r
        [vlTOPp->__Vtableidx46];
    vlTOPp->__Vtableidx47 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 6U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 6U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r 
        = vlTOPp->__Vtable47_logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r
        [vlTOPp->__Vtableidx47];
    vlTOPp->__Vtableidx48 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x14U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r 
        = vlTOPp->__Vtable48_logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r
        [vlTOPp->__Vtableidx48];
    vlTOPp->__Vtableidx49 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0x16U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x16U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M0w 
                                          >> 0x1eU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r 
        = vlTOPp->__Vtable49_logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r
        [vlTOPp->__Vtableidx49];
    vlTOPp->__Vtableidx50 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xcU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xcU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r 
        = vlTOPp->__Vtable50_logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r
        [vlTOPp->__Vtableidx50];
    vlTOPp->__Vtableidx51 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 2U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 2U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xcU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r 
        = vlTOPp->__Vtable51_logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r
        [vlTOPp->__Vtableidx51];
    vlTOPp->__Vtableidx52 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & vlTOPp->logicnet__DOT__M0w) 
                                                  | ((4U 
                                                      & vlTOPp->logicnet__DOT__M0w) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r 
        = vlTOPp->__Vtable52_logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r
        [vlTOPp->__Vtableidx52];
    vlTOPp->__Vtableidx53 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 6U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x10U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x10U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r 
        = vlTOPp->__Vtable53_logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r
        [vlTOPp->__Vtableidx53];
    vlTOPp->__Vtableidx54 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 8U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xcU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xcU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r 
        = vlTOPp->__Vtable54_logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r
        [vlTOPp->__Vtableidx54];
    vlTOPp->__Vtableidx55 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xaU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xaU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r 
        = vlTOPp->__Vtable55_logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r
        [vlTOPp->__Vtableidx55];
    vlTOPp->__Vtableidx56 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 2U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 2U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r 
        = vlTOPp->__Vtable56_logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r
        [vlTOPp->__Vtableidx56];
    vlTOPp->__Vtableidx57 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 4U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 4U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r 
        = vlTOPp->__Vtable57_logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r
        [vlTOPp->__Vtableidx57];
    vlTOPp->__Vtableidx58 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x10U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x10U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r 
        = vlTOPp->__Vtable58_logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r
        [vlTOPp->__Vtableidx58];
    vlTOPp->__Vtableidx59 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0x12U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0x12U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1cU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r 
        = vlTOPp->__Vtable59_logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r
        [vlTOPp->__Vtableidx59];
    vlTOPp->__Vtableidx60 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 4U)) | ((4U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 4U)) 
                                                  | (3U 
                                                     & (vlTOPp->logicnet__DOT__M0w 
                                                        >> 0x10U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r 
        = vlTOPp->__Vtable60_logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r
        [vlTOPp->__Vtableidx60];
    vlTOPp->__Vtableidx61 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0xeU)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0xeU)) | 
                                 (3U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x12U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r 
        = vlTOPp->__Vtable61_logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r
        [vlTOPp->__Vtableidx61];
    vlTOPp->__Vtableidx62 = ((0x30U & vlTOPp->logicnet__DOT__M0w) 
                             | ((8U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 0x14U)) | 
                                ((4U & (vlTOPp->logicnet__DOT__M0w 
                                        >> 0x14U)) 
                                 | (3U & (vlTOPp->logicnet__DOT__M0w 
                                          >> 0x18U)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r 
        = vlTOPp->__Vtable62_logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r
        [vlTOPp->__Vtableidx62];
    vlTOPp->__Vtableidx63 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       >> 4U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 8U)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 8U)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0xeU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r 
        = vlTOPp->__Vtable63_logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r
        [vlTOPp->__Vtableidx63];
    vlTOPp->__Vtableidx64 = ((0x30U & (vlTOPp->logicnet__DOT__M0w 
                                       << 2U)) | ((8U 
                                                   & (vlTOPp->logicnet__DOT__M0w 
                                                      >> 0xeU)) 
                                                  | ((4U 
                                                      & (vlTOPp->logicnet__DOT__M0w 
                                                         >> 0xeU)) 
                                                     | (3U 
                                                        & (vlTOPp->logicnet__DOT__M0w 
                                                           >> 0x1aU)))));
    vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r 
        = vlTOPp->__Vtable64_logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r
        [vlTOPp->__Vtableidx64];
    vlTOPp->M5 = ((0x7ff8U & (IData)(vlTOPp->M5)) | (IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r));
    vlTOPp->M5 = ((0x7fc7U & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r) 
                   << 3U));
    vlTOPp->M5 = ((0x7e3fU & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r) 
                   << 6U));
    vlTOPp->M5 = ((0x71ffU & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r) 
                   << 9U));
    vlTOPp->M5 = ((0xfffU & (IData)(vlTOPp->M5)) | 
                  ((IData)(vlTOPp->logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r) 
                   << 0xcU));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffffffffffcULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | (IData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r)));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffffffffff3ULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r)) 
                                    << 2U));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffffffffffcfULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r)) 
                                    << 4U));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffffffffff3fULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r)) 
                                    << 6U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffffffffcffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r)) 
                                    << 8U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffffffff3ffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r)) 
                                    << 0xaU));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffffffffcfffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r)) 
                                    << 0xcU));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffffffff3fffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r)) 
                                    << 0xeU));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffffffcffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r)) 
                                    << 0x10U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffffff3ffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r)) 
                                    << 0x12U));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffffffcfffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r)) 
                                    << 0x14U));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffffff3fffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r)) 
                                    << 0x16U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffffcffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r)) 
                                    << 0x18U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffff3ffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r)) 
                                    << 0x1aU));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffffcfffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r)) 
                                    << 0x1cU));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffff3fffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r)) 
                                    << 0x1eU));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffffcffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r)) 
                                    << 0x20U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffff3ffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r)) 
                                    << 0x22U));
    vlTOPp->logicnet__DOT__M4 = ((0xffffffcfffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r)) 
                                    << 0x24U));
    vlTOPp->logicnet__DOT__M4 = ((0xffffff3fffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r)) 
                                    << 0x26U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffffcffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r)) 
                                    << 0x28U));
    vlTOPp->logicnet__DOT__M4 = ((0xfffff3ffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r)) 
                                    << 0x2aU));
    vlTOPp->logicnet__DOT__M4 = ((0xffffcfffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r)) 
                                    << 0x2cU));
    vlTOPp->logicnet__DOT__M4 = ((0xffff3fffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r)) 
                                    << 0x2eU));
    vlTOPp->logicnet__DOT__M4 = ((0xfffcffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r)) 
                                    << 0x30U));
    vlTOPp->logicnet__DOT__M4 = ((0xfff3ffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r)) 
                                    << 0x32U));
    vlTOPp->logicnet__DOT__M4 = ((0xffcfffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r)) 
                                    << 0x34U));
    vlTOPp->logicnet__DOT__M4 = ((0xff3fffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r)) 
                                    << 0x36U));
    vlTOPp->logicnet__DOT__M4 = ((0xfcffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r)) 
                                    << 0x38U));
    vlTOPp->logicnet__DOT__M4 = ((0xf3ffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r)) 
                                    << 0x3aU));
    vlTOPp->logicnet__DOT__M4 = ((0xcfffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r)) 
                                    << 0x3cU));
    vlTOPp->logicnet__DOT__M4 = ((0x3fffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M4) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r)) 
                                    << 0x3eU));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffffffffffcULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | (IData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r)));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffffffffff3ULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r)) 
                                    << 2U));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffffffffffcfULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r)) 
                                    << 4U));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffffffffff3fULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r)) 
                                    << 6U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffffffffcffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r)) 
                                    << 8U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffffffff3ffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r)) 
                                    << 0xaU));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffffffffcfffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r)) 
                                    << 0xcU));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffffffff3fffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r)) 
                                    << 0xeU));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffffffcffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r)) 
                                    << 0x10U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffffff3ffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r)) 
                                    << 0x12U));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffffffcfffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r)) 
                                    << 0x14U));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffffff3fffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r)) 
                                    << 0x16U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffffcffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r)) 
                                    << 0x18U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffff3ffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r)) 
                                    << 0x1aU));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffffcfffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r)) 
                                    << 0x1cU));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffff3fffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r)) 
                                    << 0x1eU));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffffcffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r)) 
                                    << 0x20U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffff3ffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r)) 
                                    << 0x22U));
    vlTOPp->logicnet__DOT__M3 = ((0xffffffcfffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r)) 
                                    << 0x24U));
    vlTOPp->logicnet__DOT__M3 = ((0xffffff3fffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r)) 
                                    << 0x26U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffffcffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r)) 
                                    << 0x28U));
    vlTOPp->logicnet__DOT__M3 = ((0xfffff3ffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r)) 
                                    << 0x2aU));
    vlTOPp->logicnet__DOT__M3 = ((0xffffcfffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r)) 
                                    << 0x2cU));
    vlTOPp->logicnet__DOT__M3 = ((0xffff3fffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r)) 
                                    << 0x2eU));
    vlTOPp->logicnet__DOT__M3 = ((0xfffcffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r)) 
                                    << 0x30U));
    vlTOPp->logicnet__DOT__M3 = ((0xfff3ffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r)) 
                                    << 0x32U));
    vlTOPp->logicnet__DOT__M3 = ((0xffcfffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r)) 
                                    << 0x34U));
    vlTOPp->logicnet__DOT__M3 = ((0xff3fffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r)) 
                                    << 0x36U));
    vlTOPp->logicnet__DOT__M3 = ((0xfcffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r)) 
                                    << 0x38U));
    vlTOPp->logicnet__DOT__M3 = ((0xf3ffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r)) 
                                    << 0x3aU));
    vlTOPp->logicnet__DOT__M3 = ((0xcfffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r)) 
                                    << 0x3cU));
    vlTOPp->logicnet__DOT__M3 = ((0x3fffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M3) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r)) 
                                    << 0x3eU));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffffffffffcULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | (IData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r)));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffffffffff3ULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r)) 
                                    << 2U));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffffffffffcfULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r)) 
                                    << 4U));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffffffffff3fULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r)) 
                                    << 6U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffffffffcffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r)) 
                                    << 8U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffffffff3ffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r)) 
                                    << 0xaU));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffffffffcfffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r)) 
                                    << 0xcU));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffffffff3fffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r)) 
                                    << 0xeU));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffffffcffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r)) 
                                    << 0x10U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffffff3ffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r)) 
                                    << 0x12U));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffffffcfffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r)) 
                                    << 0x14U));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffffff3fffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r)) 
                                    << 0x16U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffffcffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r)) 
                                    << 0x18U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffff3ffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r)) 
                                    << 0x1aU));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffffcfffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r)) 
                                    << 0x1cU));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffff3fffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r)) 
                                    << 0x1eU));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffffcffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r)) 
                                    << 0x20U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffff3ffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r)) 
                                    << 0x22U));
    vlTOPp->logicnet__DOT__M2 = ((0xffffffcfffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r)) 
                                    << 0x24U));
    vlTOPp->logicnet__DOT__M2 = ((0xffffff3fffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r)) 
                                    << 0x26U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffffcffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r)) 
                                    << 0x28U));
    vlTOPp->logicnet__DOT__M2 = ((0xfffff3ffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r)) 
                                    << 0x2aU));
    vlTOPp->logicnet__DOT__M2 = ((0xffffcfffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r)) 
                                    << 0x2cU));
    vlTOPp->logicnet__DOT__M2 = ((0xffff3fffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r)) 
                                    << 0x2eU));
    vlTOPp->logicnet__DOT__M2 = ((0xfffcffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r)) 
                                    << 0x30U));
    vlTOPp->logicnet__DOT__M2 = ((0xfff3ffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r)) 
                                    << 0x32U));
    vlTOPp->logicnet__DOT__M2 = ((0xffcfffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r)) 
                                    << 0x34U));
    vlTOPp->logicnet__DOT__M2 = ((0xff3fffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r)) 
                                    << 0x36U));
    vlTOPp->logicnet__DOT__M2 = ((0xfcffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r)) 
                                    << 0x38U));
    vlTOPp->logicnet__DOT__M2 = ((0xf3ffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r)) 
                                    << 0x3aU));
    vlTOPp->logicnet__DOT__M2 = ((0xcfffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r)) 
                                    << 0x3cU));
    vlTOPp->logicnet__DOT__M2 = ((0x3fffffffffffffffULL 
                                  & vlTOPp->logicnet__DOT__M2) 
                                 | ((QData)((IData)(vlTOPp->logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r)) 
                                    << 0x3eU));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffffff3U & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffffffcfU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffffff3fU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffffcffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffff3ffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffffcfffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffff3fffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfffcffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfff3ffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xffcfffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xff3fffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xfcffffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xf3ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0xcfffffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M1[0U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[0U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffffff3U & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffffffcfU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffffff3fU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffffcffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffff3ffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffffcfffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffff3fffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfffcffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfff3ffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xffcfffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xff3fffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xfcffffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xf3ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0xcfffffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M1[1U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[1U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffffff3U & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffffffcfU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffffff3fU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffffcffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffff3ffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffffcfffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffff3fffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfffcffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfff3ffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xffcfffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xff3fffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xfcffffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xf3ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0xcfffffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M1[2U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[2U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r) 
                                           << 0x1eU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffffffcU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffffff3U & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffffffcU 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r) 
                                           << 2U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffffffcfU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffffff0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r) 
                                           << 4U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffffff3fU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffffffc0U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r) 
                                           << 6U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffffcffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffffff00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r) 
                                           << 8U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffff3ffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffffc00U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r) 
                                           << 0xaU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffffcfffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffff000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r) 
                                           << 0xcU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffff3fffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffffc000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r) 
                                           << 0xeU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfffcffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffff0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r) 
                                           << 0x10U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfff3ffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfffc0000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r) 
                                           << 0x12U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xffcfffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfff00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r) 
                                           << 0x14U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xff3fffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xffc00000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r) 
                                           << 0x16U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xfcffffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xff000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r) 
                                           << 0x18U)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xf3ffffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xfc000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r) 
                                           << 0x1aU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0xcfffffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xf0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r) 
                                           << 0x1cU)));
    vlTOPp->logicnet__DOT__M1[3U] = ((0x3fffffffU & 
                                      vlTOPp->logicnet__DOT__M1[3U]) 
                                     | (0xc0000000U 
                                        & ((IData)(vlTOPp->logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r) 
                                           << 0x1eU)));
}

void Vlogicnet::_eval(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_eval\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (((IData)(vlTOPp->clk) & (~ (IData)(vlTOPp->__Vclklast__TOP__clk)))) {
        vlTOPp->_sequent__TOP__1(vlSymsp);
        vlTOPp->__Vm_traceActivity[1U] = 1U;
    }
    // Final
    vlTOPp->__Vclklast__TOP__clk = vlTOPp->clk;
}

VL_INLINE_OPT QData Vlogicnet::_change_request(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_change_request\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    return (vlTOPp->_change_request_1(vlSymsp));
}

VL_INLINE_OPT QData Vlogicnet::_change_request_1(Vlogicnet__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_change_request_1\n"); );
    Vlogicnet* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vlogicnet::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vlogicnet::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((clk & 0xfeU))) {
        Verilated::overWidthError("clk");}
    if (VL_UNLIKELY((rst & 0xfeU))) {
        Verilated::overWidthError("rst");}
}
#endif  // VL_DEBUG
