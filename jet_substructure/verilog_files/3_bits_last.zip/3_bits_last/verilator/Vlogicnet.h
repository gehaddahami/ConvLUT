// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary design header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef _VLOGICNET_H_
#define _VLOGICNET_H_  // guard

#include "verilated.h"

//==========

class Vlogicnet__Syms;
class Vlogicnet_VerilatedVcd;


//----------

VL_MODULE(Vlogicnet) {
  public:
    
    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    VL_IN8(clk,0,0);
    VL_IN8(rst,0,0);
    VL_OUT16(M5,14,0);
    VL_IN(M0,31,0);
    
    // LOCAL SIGNALS
    // Internals; generally not touched by application code
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r;
    };
    struct {
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r;
    };
    struct {
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r;
        CData/*1:0*/ logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r;
        CData/*2:0*/ logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r;
        CData/*2:0*/ logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r;
        CData/*2:0*/ logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r;
        CData/*2:0*/ logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r;
        CData/*2:0*/ logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r;
        IData/*31:0*/ logicnet__DOT__M0w;
        WData/*127:0*/ logicnet__DOT__M1[4];
        WData/*127:0*/ logicnet__DOT__M1w[4];
        QData/*63:0*/ logicnet__DOT__M2;
        QData/*63:0*/ logicnet__DOT__M2w;
        QData/*63:0*/ logicnet__DOT__M3;
        QData/*63:0*/ logicnet__DOT__M3w;
        QData/*63:0*/ logicnet__DOT__M4;
        QData/*63:0*/ logicnet__DOT__M4w;
    };
    
    // LOCAL VARIABLES
    // Internals; generally not touched by application code
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*5:0*/ __Vtableidx1;
        CData/*5:0*/ __Vtableidx2;
        CData/*5:0*/ __Vtableidx3;
        CData/*5:0*/ __Vtableidx4;
        CData/*5:0*/ __Vtableidx5;
        CData/*5:0*/ __Vtableidx6;
        CData/*5:0*/ __Vtableidx7;
        CData/*5:0*/ __Vtableidx8;
        CData/*5:0*/ __Vtableidx9;
        CData/*5:0*/ __Vtableidx10;
        CData/*5:0*/ __Vtableidx11;
        CData/*5:0*/ __Vtableidx12;
        CData/*5:0*/ __Vtableidx13;
        CData/*5:0*/ __Vtableidx14;
        CData/*5:0*/ __Vtableidx15;
        CData/*5:0*/ __Vtableidx16;
        CData/*5:0*/ __Vtableidx17;
        CData/*5:0*/ __Vtableidx18;
        CData/*5:0*/ __Vtableidx19;
        CData/*5:0*/ __Vtableidx20;
        CData/*5:0*/ __Vtableidx21;
        CData/*5:0*/ __Vtableidx22;
        CData/*5:0*/ __Vtableidx23;
        CData/*5:0*/ __Vtableidx24;
        CData/*5:0*/ __Vtableidx25;
        CData/*5:0*/ __Vtableidx26;
        CData/*5:0*/ __Vtableidx27;
        CData/*5:0*/ __Vtableidx28;
        CData/*5:0*/ __Vtableidx29;
        CData/*5:0*/ __Vtableidx30;
        CData/*5:0*/ __Vtableidx31;
        CData/*5:0*/ __Vtableidx32;
        CData/*5:0*/ __Vtableidx33;
        CData/*5:0*/ __Vtableidx34;
        CData/*5:0*/ __Vtableidx35;
        CData/*5:0*/ __Vtableidx36;
        CData/*5:0*/ __Vtableidx37;
        CData/*5:0*/ __Vtableidx38;
        CData/*5:0*/ __Vtableidx39;
        CData/*5:0*/ __Vtableidx40;
        CData/*5:0*/ __Vtableidx41;
        CData/*5:0*/ __Vtableidx42;
        CData/*5:0*/ __Vtableidx43;
        CData/*5:0*/ __Vtableidx44;
        CData/*5:0*/ __Vtableidx45;
        CData/*5:0*/ __Vtableidx46;
        CData/*5:0*/ __Vtableidx47;
        CData/*5:0*/ __Vtableidx48;
        CData/*5:0*/ __Vtableidx49;
        CData/*5:0*/ __Vtableidx50;
        CData/*5:0*/ __Vtableidx51;
        CData/*5:0*/ __Vtableidx52;
        CData/*5:0*/ __Vtableidx53;
        CData/*5:0*/ __Vtableidx54;
        CData/*5:0*/ __Vtableidx55;
        CData/*5:0*/ __Vtableidx56;
        CData/*5:0*/ __Vtableidx57;
        CData/*5:0*/ __Vtableidx58;
        CData/*5:0*/ __Vtableidx59;
        CData/*5:0*/ __Vtableidx60;
        CData/*5:0*/ __Vtableidx61;
        CData/*5:0*/ __Vtableidx62;
        CData/*5:0*/ __Vtableidx63;
        CData/*5:0*/ __Vtableidx64;
    };
    struct {
        CData/*5:0*/ __Vtableidx65;
        CData/*5:0*/ __Vtableidx66;
        CData/*5:0*/ __Vtableidx67;
        CData/*5:0*/ __Vtableidx68;
        CData/*5:0*/ __Vtableidx69;
        CData/*5:0*/ __Vtableidx70;
        CData/*5:0*/ __Vtableidx71;
        CData/*5:0*/ __Vtableidx72;
        CData/*5:0*/ __Vtableidx73;
        CData/*5:0*/ __Vtableidx74;
        CData/*5:0*/ __Vtableidx75;
        CData/*5:0*/ __Vtableidx76;
        CData/*5:0*/ __Vtableidx77;
        CData/*5:0*/ __Vtableidx78;
        CData/*5:0*/ __Vtableidx79;
        CData/*5:0*/ __Vtableidx80;
        CData/*5:0*/ __Vtableidx81;
        CData/*5:0*/ __Vtableidx82;
        CData/*5:0*/ __Vtableidx83;
        CData/*5:0*/ __Vtableidx84;
        CData/*5:0*/ __Vtableidx85;
        CData/*5:0*/ __Vtableidx86;
        CData/*5:0*/ __Vtableidx87;
        CData/*5:0*/ __Vtableidx88;
        CData/*5:0*/ __Vtableidx89;
        CData/*5:0*/ __Vtableidx90;
        CData/*5:0*/ __Vtableidx91;
        CData/*5:0*/ __Vtableidx92;
        CData/*5:0*/ __Vtableidx93;
        CData/*5:0*/ __Vtableidx94;
        CData/*5:0*/ __Vtableidx95;
        CData/*5:0*/ __Vtableidx96;
        CData/*5:0*/ __Vtableidx97;
        CData/*5:0*/ __Vtableidx98;
        CData/*5:0*/ __Vtableidx99;
        CData/*5:0*/ __Vtableidx100;
        CData/*5:0*/ __Vtableidx101;
        CData/*5:0*/ __Vtableidx102;
        CData/*5:0*/ __Vtableidx103;
        CData/*5:0*/ __Vtableidx104;
        CData/*5:0*/ __Vtableidx105;
        CData/*5:0*/ __Vtableidx106;
        CData/*5:0*/ __Vtableidx107;
        CData/*5:0*/ __Vtableidx108;
        CData/*5:0*/ __Vtableidx109;
        CData/*5:0*/ __Vtableidx110;
        CData/*5:0*/ __Vtableidx111;
        CData/*5:0*/ __Vtableidx112;
        CData/*5:0*/ __Vtableidx113;
        CData/*5:0*/ __Vtableidx114;
        CData/*5:0*/ __Vtableidx115;
        CData/*5:0*/ __Vtableidx116;
        CData/*5:0*/ __Vtableidx117;
        CData/*5:0*/ __Vtableidx118;
        CData/*5:0*/ __Vtableidx119;
        CData/*5:0*/ __Vtableidx120;
        CData/*5:0*/ __Vtableidx121;
        CData/*5:0*/ __Vtableidx122;
        CData/*5:0*/ __Vtableidx123;
        CData/*5:0*/ __Vtableidx124;
        CData/*5:0*/ __Vtableidx125;
        CData/*5:0*/ __Vtableidx126;
        CData/*5:0*/ __Vtableidx127;
        CData/*5:0*/ __Vtableidx128;
    };
    struct {
        CData/*5:0*/ __Vtableidx129;
        CData/*5:0*/ __Vtableidx130;
        CData/*5:0*/ __Vtableidx131;
        CData/*5:0*/ __Vtableidx132;
        CData/*5:0*/ __Vtableidx133;
        CData/*5:0*/ __Vtableidx134;
        CData/*5:0*/ __Vtableidx135;
        CData/*5:0*/ __Vtableidx136;
        CData/*5:0*/ __Vtableidx137;
        CData/*5:0*/ __Vtableidx138;
        CData/*5:0*/ __Vtableidx139;
        CData/*5:0*/ __Vtableidx140;
        CData/*5:0*/ __Vtableidx141;
        CData/*5:0*/ __Vtableidx142;
        CData/*5:0*/ __Vtableidx143;
        CData/*5:0*/ __Vtableidx144;
        CData/*5:0*/ __Vtableidx145;
        CData/*5:0*/ __Vtableidx146;
        CData/*5:0*/ __Vtableidx147;
        CData/*5:0*/ __Vtableidx148;
        CData/*5:0*/ __Vtableidx149;
        CData/*5:0*/ __Vtableidx150;
        CData/*5:0*/ __Vtableidx151;
        CData/*5:0*/ __Vtableidx152;
        CData/*5:0*/ __Vtableidx153;
        CData/*5:0*/ __Vtableidx154;
        CData/*5:0*/ __Vtableidx155;
        CData/*5:0*/ __Vtableidx156;
        CData/*5:0*/ __Vtableidx157;
        CData/*5:0*/ __Vtableidx158;
        CData/*5:0*/ __Vtableidx159;
        CData/*5:0*/ __Vtableidx160;
        CData/*5:0*/ __Vtableidx161;
        CData/*5:0*/ __Vtableidx162;
        CData/*5:0*/ __Vtableidx163;
        CData/*5:0*/ __Vtableidx164;
        CData/*5:0*/ __Vtableidx165;
        CData/*0:0*/ __Vclklast__TOP__clk;
        CData/*0:0*/ __Vm_traceActivity[2];
    };
    static CData/*1:0*/ __Vtable1_logicnet__DOT__layer0_inst__DOT__layer0_N0_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable2_logicnet__DOT__layer0_inst__DOT__layer0_N1_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable3_logicnet__DOT__layer0_inst__DOT__layer0_N2_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable4_logicnet__DOT__layer0_inst__DOT__layer0_N3_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable5_logicnet__DOT__layer0_inst__DOT__layer0_N4_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable6_logicnet__DOT__layer0_inst__DOT__layer0_N5_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable7_logicnet__DOT__layer0_inst__DOT__layer0_N6_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable8_logicnet__DOT__layer0_inst__DOT__layer0_N7_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable9_logicnet__DOT__layer0_inst__DOT__layer0_N8_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable10_logicnet__DOT__layer0_inst__DOT__layer0_N9_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable11_logicnet__DOT__layer0_inst__DOT__layer0_N10_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable12_logicnet__DOT__layer0_inst__DOT__layer0_N11_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable13_logicnet__DOT__layer0_inst__DOT__layer0_N12_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable14_logicnet__DOT__layer0_inst__DOT__layer0_N13_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable15_logicnet__DOT__layer0_inst__DOT__layer0_N14_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable16_logicnet__DOT__layer0_inst__DOT__layer0_N15_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable17_logicnet__DOT__layer0_inst__DOT__layer0_N16_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable18_logicnet__DOT__layer0_inst__DOT__layer0_N17_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable19_logicnet__DOT__layer0_inst__DOT__layer0_N18_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable20_logicnet__DOT__layer0_inst__DOT__layer0_N19_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable21_logicnet__DOT__layer0_inst__DOT__layer0_N20_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable22_logicnet__DOT__layer0_inst__DOT__layer0_N21_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable23_logicnet__DOT__layer0_inst__DOT__layer0_N22_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable24_logicnet__DOT__layer0_inst__DOT__layer0_N23_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable25_logicnet__DOT__layer0_inst__DOT__layer0_N24_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable26_logicnet__DOT__layer0_inst__DOT__layer0_N25_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable27_logicnet__DOT__layer0_inst__DOT__layer0_N26_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable28_logicnet__DOT__layer0_inst__DOT__layer0_N27_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable29_logicnet__DOT__layer0_inst__DOT__layer0_N28_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable30_logicnet__DOT__layer0_inst__DOT__layer0_N29_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable31_logicnet__DOT__layer0_inst__DOT__layer0_N30_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable32_logicnet__DOT__layer0_inst__DOT__layer0_N31_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable33_logicnet__DOT__layer0_inst__DOT__layer0_N32_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable34_logicnet__DOT__layer0_inst__DOT__layer0_N33_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable35_logicnet__DOT__layer0_inst__DOT__layer0_N34_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable36_logicnet__DOT__layer0_inst__DOT__layer0_N35_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable37_logicnet__DOT__layer0_inst__DOT__layer0_N36_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable38_logicnet__DOT__layer0_inst__DOT__layer0_N37_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable39_logicnet__DOT__layer0_inst__DOT__layer0_N38_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable40_logicnet__DOT__layer0_inst__DOT__layer0_N39_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable41_logicnet__DOT__layer0_inst__DOT__layer0_N40_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable42_logicnet__DOT__layer0_inst__DOT__layer0_N41_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable43_logicnet__DOT__layer0_inst__DOT__layer0_N42_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable44_logicnet__DOT__layer0_inst__DOT__layer0_N43_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable45_logicnet__DOT__layer0_inst__DOT__layer0_N44_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable46_logicnet__DOT__layer0_inst__DOT__layer0_N45_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable47_logicnet__DOT__layer0_inst__DOT__layer0_N46_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable48_logicnet__DOT__layer0_inst__DOT__layer0_N47_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable49_logicnet__DOT__layer0_inst__DOT__layer0_N48_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable50_logicnet__DOT__layer0_inst__DOT__layer0_N49_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable51_logicnet__DOT__layer0_inst__DOT__layer0_N50_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable52_logicnet__DOT__layer0_inst__DOT__layer0_N51_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable53_logicnet__DOT__layer0_inst__DOT__layer0_N52_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable54_logicnet__DOT__layer0_inst__DOT__layer0_N53_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable55_logicnet__DOT__layer0_inst__DOT__layer0_N54_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable56_logicnet__DOT__layer0_inst__DOT__layer0_N55_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable57_logicnet__DOT__layer0_inst__DOT__layer0_N56_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable58_logicnet__DOT__layer0_inst__DOT__layer0_N57_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable59_logicnet__DOT__layer0_inst__DOT__layer0_N58_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable60_logicnet__DOT__layer0_inst__DOT__layer0_N59_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable61_logicnet__DOT__layer0_inst__DOT__layer0_N60_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable62_logicnet__DOT__layer0_inst__DOT__layer0_N61_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable63_logicnet__DOT__layer0_inst__DOT__layer0_N62_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable64_logicnet__DOT__layer0_inst__DOT__layer0_N63_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable65_logicnet__DOT__layer1_inst__DOT__layer1_N0_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable66_logicnet__DOT__layer1_inst__DOT__layer1_N1_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable67_logicnet__DOT__layer1_inst__DOT__layer1_N2_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable68_logicnet__DOT__layer1_inst__DOT__layer1_N3_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable69_logicnet__DOT__layer1_inst__DOT__layer1_N4_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable70_logicnet__DOT__layer1_inst__DOT__layer1_N5_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable71_logicnet__DOT__layer1_inst__DOT__layer1_N6_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable72_logicnet__DOT__layer1_inst__DOT__layer1_N7_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable73_logicnet__DOT__layer1_inst__DOT__layer1_N8_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable74_logicnet__DOT__layer1_inst__DOT__layer1_N9_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable75_logicnet__DOT__layer1_inst__DOT__layer1_N10_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable76_logicnet__DOT__layer1_inst__DOT__layer1_N11_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable77_logicnet__DOT__layer1_inst__DOT__layer1_N12_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable78_logicnet__DOT__layer1_inst__DOT__layer1_N13_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable79_logicnet__DOT__layer1_inst__DOT__layer1_N14_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable80_logicnet__DOT__layer1_inst__DOT__layer1_N15_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable81_logicnet__DOT__layer1_inst__DOT__layer1_N16_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable82_logicnet__DOT__layer1_inst__DOT__layer1_N17_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable83_logicnet__DOT__layer1_inst__DOT__layer1_N18_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable84_logicnet__DOT__layer1_inst__DOT__layer1_N19_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable85_logicnet__DOT__layer1_inst__DOT__layer1_N20_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable86_logicnet__DOT__layer1_inst__DOT__layer1_N21_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable87_logicnet__DOT__layer1_inst__DOT__layer1_N22_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable88_logicnet__DOT__layer1_inst__DOT__layer1_N23_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable89_logicnet__DOT__layer1_inst__DOT__layer1_N24_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable90_logicnet__DOT__layer1_inst__DOT__layer1_N25_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable91_logicnet__DOT__layer1_inst__DOT__layer1_N26_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable92_logicnet__DOT__layer1_inst__DOT__layer1_N27_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable93_logicnet__DOT__layer1_inst__DOT__layer1_N28_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable94_logicnet__DOT__layer1_inst__DOT__layer1_N29_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable95_logicnet__DOT__layer1_inst__DOT__layer1_N30_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable96_logicnet__DOT__layer1_inst__DOT__layer1_N31_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable97_logicnet__DOT__layer2_inst__DOT__layer2_N0_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable98_logicnet__DOT__layer2_inst__DOT__layer2_N1_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable99_logicnet__DOT__layer2_inst__DOT__layer2_N2_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable100_logicnet__DOT__layer2_inst__DOT__layer2_N3_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable101_logicnet__DOT__layer2_inst__DOT__layer2_N4_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable102_logicnet__DOT__layer2_inst__DOT__layer2_N5_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable103_logicnet__DOT__layer2_inst__DOT__layer2_N6_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable104_logicnet__DOT__layer2_inst__DOT__layer2_N7_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable105_logicnet__DOT__layer2_inst__DOT__layer2_N8_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable106_logicnet__DOT__layer2_inst__DOT__layer2_N9_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable107_logicnet__DOT__layer2_inst__DOT__layer2_N10_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable108_logicnet__DOT__layer2_inst__DOT__layer2_N11_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable109_logicnet__DOT__layer2_inst__DOT__layer2_N12_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable110_logicnet__DOT__layer2_inst__DOT__layer2_N13_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable111_logicnet__DOT__layer2_inst__DOT__layer2_N14_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable112_logicnet__DOT__layer2_inst__DOT__layer2_N15_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable113_logicnet__DOT__layer2_inst__DOT__layer2_N16_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable114_logicnet__DOT__layer2_inst__DOT__layer2_N17_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable115_logicnet__DOT__layer2_inst__DOT__layer2_N18_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable116_logicnet__DOT__layer2_inst__DOT__layer2_N19_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable117_logicnet__DOT__layer2_inst__DOT__layer2_N20_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable118_logicnet__DOT__layer2_inst__DOT__layer2_N21_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable119_logicnet__DOT__layer2_inst__DOT__layer2_N22_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable120_logicnet__DOT__layer2_inst__DOT__layer2_N23_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable121_logicnet__DOT__layer2_inst__DOT__layer2_N24_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable122_logicnet__DOT__layer2_inst__DOT__layer2_N25_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable123_logicnet__DOT__layer2_inst__DOT__layer2_N26_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable124_logicnet__DOT__layer2_inst__DOT__layer2_N27_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable125_logicnet__DOT__layer2_inst__DOT__layer2_N28_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable126_logicnet__DOT__layer2_inst__DOT__layer2_N29_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable127_logicnet__DOT__layer2_inst__DOT__layer2_N30_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable128_logicnet__DOT__layer2_inst__DOT__layer2_N31_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable129_logicnet__DOT__layer3_inst__DOT__layer3_N0_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable130_logicnet__DOT__layer3_inst__DOT__layer3_N1_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable131_logicnet__DOT__layer3_inst__DOT__layer3_N2_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable132_logicnet__DOT__layer3_inst__DOT__layer3_N3_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable133_logicnet__DOT__layer3_inst__DOT__layer3_N4_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable134_logicnet__DOT__layer3_inst__DOT__layer3_N5_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable135_logicnet__DOT__layer3_inst__DOT__layer3_N6_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable136_logicnet__DOT__layer3_inst__DOT__layer3_N7_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable137_logicnet__DOT__layer3_inst__DOT__layer3_N8_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable138_logicnet__DOT__layer3_inst__DOT__layer3_N9_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable139_logicnet__DOT__layer3_inst__DOT__layer3_N10_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable140_logicnet__DOT__layer3_inst__DOT__layer3_N11_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable141_logicnet__DOT__layer3_inst__DOT__layer3_N12_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable142_logicnet__DOT__layer3_inst__DOT__layer3_N13_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable143_logicnet__DOT__layer3_inst__DOT__layer3_N14_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable144_logicnet__DOT__layer3_inst__DOT__layer3_N15_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable145_logicnet__DOT__layer3_inst__DOT__layer3_N16_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable146_logicnet__DOT__layer3_inst__DOT__layer3_N17_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable147_logicnet__DOT__layer3_inst__DOT__layer3_N18_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable148_logicnet__DOT__layer3_inst__DOT__layer3_N19_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable149_logicnet__DOT__layer3_inst__DOT__layer3_N20_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable150_logicnet__DOT__layer3_inst__DOT__layer3_N21_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable151_logicnet__DOT__layer3_inst__DOT__layer3_N22_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable152_logicnet__DOT__layer3_inst__DOT__layer3_N23_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable153_logicnet__DOT__layer3_inst__DOT__layer3_N24_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable154_logicnet__DOT__layer3_inst__DOT__layer3_N25_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable155_logicnet__DOT__layer3_inst__DOT__layer3_N26_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable156_logicnet__DOT__layer3_inst__DOT__layer3_N27_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable157_logicnet__DOT__layer3_inst__DOT__layer3_N28_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable158_logicnet__DOT__layer3_inst__DOT__layer3_N29_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable159_logicnet__DOT__layer3_inst__DOT__layer3_N30_inst__DOT__M1r[64];
    static CData/*1:0*/ __Vtable160_logicnet__DOT__layer3_inst__DOT__layer3_N31_inst__DOT__M1r[64];
    static CData/*2:0*/ __Vtable161_logicnet__DOT__layer4_inst__DOT__layer4_N0_inst__DOT__M1r[64];
    static CData/*2:0*/ __Vtable162_logicnet__DOT__layer4_inst__DOT__layer4_N1_inst__DOT__M1r[64];
    static CData/*2:0*/ __Vtable163_logicnet__DOT__layer4_inst__DOT__layer4_N2_inst__DOT__M1r[64];
    static CData/*2:0*/ __Vtable164_logicnet__DOT__layer4_inst__DOT__layer4_N3_inst__DOT__M1r[64];
    static CData/*2:0*/ __Vtable165_logicnet__DOT__layer4_inst__DOT__layer4_N4_inst__DOT__M1r[64];
    
    // INTERNAL VARIABLES
    // Internals; generally not touched by application code
    Vlogicnet__Syms* __VlSymsp;  // Symbol table
    
    // CONSTRUCTORS
  private:
    VL_UNCOPYABLE(Vlogicnet);  ///< Copying not allowed
  public:
    /// Construct the model; called by application code
    /// The special name  may be used to make a wrapper with a
    /// single model invisible with respect to DPI scope names.
    Vlogicnet(const char* name = "TOP");
    /// Destroy the model; called (often implicitly) by application code
    ~Vlogicnet();
    /// Trace signals in the model; called by application code
    void trace(VerilatedVcdC* tfp, int levels, int options = 0);
    
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval() { eval_step(); }
    /// Evaluate when calling multiple units/models per time step.
    void eval_step();
    /// Evaluate at end of a timestep for tracing, when using eval_step().
    /// Application must call after all eval() and before time changes.
    void eval_end_step() {}
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    
    // INTERNAL METHODS
  private:
    static void _eval_initial_loop(Vlogicnet__Syms* __restrict vlSymsp);
  public:
    void __Vconfigure(Vlogicnet__Syms* symsp, bool first);
  private:
    static QData _change_request(Vlogicnet__Syms* __restrict vlSymsp);
    static QData _change_request_1(Vlogicnet__Syms* __restrict vlSymsp);
    void _ctor_var_reset() VL_ATTR_COLD;
  public:
    static void _eval(Vlogicnet__Syms* __restrict vlSymsp);
  private:
#ifdef VL_DEBUG
    void _eval_debug_assertions();
#endif  // VL_DEBUG
  public:
    static void _eval_initial(Vlogicnet__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _eval_settle(Vlogicnet__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _sequent__TOP__1(Vlogicnet__Syms* __restrict vlSymsp);
    static void _settle__TOP__2(Vlogicnet__Syms* __restrict vlSymsp) VL_ATTR_COLD;
  private:
    static void traceChgSub0(void* userp, VerilatedVcd* tracep);
    static void traceChgTop0(void* userp, VerilatedVcd* tracep);
    static void traceCleanup(void* userp, VerilatedVcd* /*unused*/);
    static void traceFullSub0(void* userp, VerilatedVcd* tracep) VL_ATTR_COLD;
    static void traceFullTop0(void* userp, VerilatedVcd* tracep) VL_ATTR_COLD;
    static void traceInitSub0(void* userp, VerilatedVcd* tracep) VL_ATTR_COLD;
    static void traceInitTop(void* userp, VerilatedVcd* tracep) VL_ATTR_COLD;
    void traceRegister(VerilatedVcd* tracep) VL_ATTR_COLD;
    static void traceInit(void* userp, VerilatedVcd* tracep, uint32_t code) VL_ATTR_COLD;
} VL_ATTR_ALIGNED(VL_CACHE_LINE_BYTES);

//----------


#endif  // guard
